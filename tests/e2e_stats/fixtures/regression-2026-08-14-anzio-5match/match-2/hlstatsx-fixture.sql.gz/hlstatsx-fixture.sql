-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: hlstatsx_test
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `geoLiteCity_Blocks`
--

DROP TABLE IF EXISTS `geoLiteCity_Blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geoLiteCity_Blocks` (
  `startIpNum` bigint unsigned NOT NULL DEFAULT '0',
  `endIpNum` bigint unsigned NOT NULL DEFAULT '0',
  `locId` bigint unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geoLiteCity_Blocks`
--

LOCK TABLES `geoLiteCity_Blocks` WRITE;
/*!40000 ALTER TABLE `geoLiteCity_Blocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `geoLiteCity_Blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `geoLiteCity_Location`
--

DROP TABLE IF EXISTS `geoLiteCity_Location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `geoLiteCity_Location` (
  `locId` bigint unsigned NOT NULL DEFAULT '0',
  `country` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `region` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` decimal(14,4) DEFAULT NULL,
  `longitude` decimal(14,4) DEFAULT NULL,
  PRIMARY KEY (`locId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `geoLiteCity_Location`
--

LOCK TABLES `geoLiteCity_Location` WRITE;
/*!40000 ALTER TABLE `geoLiteCity_Location` DISABLE KEYS */;
/*!40000 ALTER TABLE `geoLiteCity_Location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Actions`
--

DROP TABLE IF EXISTS `hlstats_Actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Actions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'valve',
  `code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `reward_player` int NOT NULL DEFAULT '10',
  `reward_team` int NOT NULL DEFAULT '0',
  `team` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `for_PlayerActions` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `for_PlayerPlayerActions` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `for_TeamActions` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `for_WorldActions` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gamecode` (`code`,`game`,`team`),
  KEY `code` (`code`)
) ENGINE=MyISAM AUTO_INCREMENT=726 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Actions`
--

LOCK TABLES `hlstats_Actions` WRITE;
/*!40000 ALTER TABLE `hlstats_Actions` DISABLE KEYS */;
INSERT INTO `hlstats_Actions` (`id`, `game`, `code`, `reward_player`, `reward_team`, `team`, `description`, `for_PlayerActions`, `for_PlayerPlayerActions`, `for_TeamActions`, `for_WorldActions`, `count`) VALUES (724,'dod','assist',0,0,'','Assists','0','1','0','0',14);
INSERT INTO `hlstats_Actions` (`id`, `game`, `code`, `reward_player`, `reward_team`, `team`, `description`, `for_PlayerActions`, `for_PlayerPlayerActions`, `for_TeamActions`, `for_WorldActions`, `count`) VALUES (725,'dod','cap_break',0,0,'','Cap Breaks','1','0','0','0',3);
/*!40000 ALTER TABLE `hlstats_Actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Awards`
--

DROP TABLE IF EXISTS `hlstats_Awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Awards` (
  `awardId` int unsigned NOT NULL AUTO_INCREMENT,
  `awardType` char(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'W',
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'valve',
  `code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `verb` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `d_winner_id` int unsigned DEFAULT NULL,
  `d_winner_count` int unsigned DEFAULT NULL,
  `g_winner_id` int unsigned DEFAULT NULL,
  `g_winner_count` int unsigned DEFAULT NULL,
  PRIMARY KEY (`awardId`),
  UNIQUE KEY `code` (`game`,`awardType`,`code`)
) ENGINE=MyISAM AUTO_INCREMENT=956 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Awards`
--

LOCK TABLES `hlstats_Awards` WRITE;
/*!40000 ALTER TABLE `hlstats_Awards` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_ClanTags`
--

DROP TABLE IF EXISTS `hlstats_ClanTags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_ClanTags` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `pattern` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` enum('EITHER','START','END') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'EITHER',
  PRIMARY KEY (`id`),
  UNIQUE KEY `pattern` (`pattern`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_ClanTags`
--

LOCK TABLES `hlstats_ClanTags` WRITE;
/*!40000 ALTER TABLE `hlstats_ClanTags` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_ClanTags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Clans`
--

DROP TABLE IF EXISTS `hlstats_Clans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Clans` (
  `clanId` int unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `homepage` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hidden` tinyint unsigned NOT NULL DEFAULT '0',
  `mapregion` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`clanId`),
  UNIQUE KEY `tag` (`game`,`tag`),
  KEY `game` (`game`)
) ENGINE=MyISAM AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Clans`
--

LOCK TABLES `hlstats_Clans` WRITE;
/*!40000 ALTER TABLE `hlstats_Clans` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Clans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Countries`
--

DROP TABLE IF EXISTS `hlstats_Countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Countries` (
  `flag` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`flag`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Countries`
--

LOCK TABLES `hlstats_Countries` WRITE;
/*!40000 ALTER TABLE `hlstats_Countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Admin`
--

DROP TABLE IF EXISTS `hlstats_Events_Admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Admin` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Unknown',
  `message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerName` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=618 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Admin`
--

LOCK TABLES `hlstats_Events_Admin` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Admin` DISABLE KEYS */;
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (161,'2026-08-14 15:30:58',2,'','AMXX (ktp_file)','[KTP File Checker] Loaded 0 file consistency checks from ktp_file.ini','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (162,'2026-08-14 15:30:59',2,'','AMXX (stats_logging)','[KTP-STATS] controlpoints_init fired, dodx_objectives_get_num()=5','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (163,'2026-08-14 15:30:59',2,'','AMXX (ktp_cvar)','[KTP Cvar Checker] Pre-converted 44 cvar values to floats','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (164,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=TEAMSCORE_MSG_REGISTERED msgid=69','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (165,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=ROUNDSTATE_MSG_REGISTERED msgid=66','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (166,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] Registered RH_PF_changelevel_I hook (KTP-ReHLDS mode)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (167,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] Registered RH_Host_Changelevel_f hook (KTP-ReHLDS mode)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (168,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=CHANGELEVEL_HOOKS_REGISTERED pfn=1 host=1','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (169,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] Registered RH_SV_UpdatePausedHUD hook (KTP-ReHLDS mode)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (170,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=HOSTNAME_CACHED full=\'Half-Life\' base=\'Half-Life\'','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (171,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP-TEST-MODE] test-mode RCON commands registered (KTP_TEST_MODE build)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (172,'2026-08-14 15:30:59',2,'','AMXX (KTPGrenadeLoadout)','[KTPGrenadeLoadout] Loaded 0 class grenade settings from config','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (173,'2026-08-14 15:30:59',2,'','AMXX (KTPBreakDrive)','[BD] loaded — NOT FOR PRODUCTION','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (174,'2026-08-14 15:30:59',2,'','AMXX (KTPAdminAudit)','[KTP Discord] Missing required config (url=0, auth=0, channel=0)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (175,'2026-08-14 15:30:59',2,'','AMXX (KTPAdminAudit)','[KTP] Loaded 6 maps from addons/ktpamx/configs/ktp_maps.ini','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (176,'2026-08-14 15:30:59',2,'','AMXX (ktp_cvar)','[KTP Discord] Missing required config (url=0, auth=0, channel=0)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (177,'2026-08-14 15:30:59',2,'','AMXX (ktp_file)','[KTP Discord] Missing required config (url=0, auth=0, channel=0)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (178,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=PLUGIN_ENABLED name=\'KTP Match Handler\' version=0.10.158 author=\'Nein_\'','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (179,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=HOSTNAME_CACHED full=\'Half-Life\' base=\'Half-Life\'','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (180,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=KTP_CONFIG_LOAD status=ok loaded=2 season=INACTIVE password_set=yes path=\'addons/ktpamx/configs/ktp.ini\'','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (181,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=MAPS_LOAD status=ok count=32 path=\'addons/ktpamx/configs/ktp_maps.ini\'','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (182,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=DISCORD_CONFIG_LOAD status=ok loaded=0 path=\'addons/ktpamx/configs/discord.ini\'','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (183,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP Discord] Missing required config (url=0, auth=0, channel=0)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (184,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=AC_CONFIG_LOAD status=skip reason=\'file_not_found\' path=\'addons/ktpamx/configs/ac.ini\' (AC integration disabled)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (185,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=AC_SERVER_ENDPOINT endpoint=127.0.0.1:27015','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (186,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=DODX_STATS_NATIVES status=available','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (187,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=CONTEXT_CHECK mode=\'\' current_map=dod_anzio','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (188,'2026-08-14 15:30:59',2,'','AMXX (KTPMatchHandler)','[KTP] event=TEAM_NAMES_RESET reason=no_pending_mode','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (189,'2026-08-14 15:30:59',2,'','AMXX (KTPHLTVRecorder)','[KTP Discord] Missing required config (url=0, auth=0, channel=0)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (190,'2026-08-14 15:30:59',2,'','AMXX (KTPGrenadeLoadout)','[KTPGrenadeLoadout] Loaded 0 class grenade settings from config','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (191,'2026-08-14 15:30:59',2,'','AMXX (KTPAdminAudit)','[KTP Admin Audit] v2.7.20 initialized (changelevel hook active)','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (192,'2026-08-14 15:31:00',2,'','AMXX (KTPMatchHandler)','[KTP] event=HOSTNAME_CACHED_DELAYED full=\'KTP Smoke Test\' base=\'KTP Smoke Test\'','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (193,'2026-08-14 15:31:00',2,'','AMXX (KTPPracticeMode)','[KTPPracticeMode] Hostname cached (delayed): KTP Smoke Test','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (194,'2026-08-14 15:32:40',2,'','AMXX (KTPMatchHandler)','[KTP] event=TEST_SETUP matchType=0 map=dod_anzio match_id=1786721560-TEST','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (195,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=TEST_ADVANCE_PENDING match_id=1786721560-TEST map=dod_anzio','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (196,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=PENDING_BEGIN map=dod_anzio need=6','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (197,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=PENDING_ENFORCE initiator=\'test_harness\' map=dod_anzio paused=0 pending=1 live=0','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (198,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=TEST_ADVANCE_LIVE match_id=1786721560-TEST half=1 map=dod_anzio matchType=0','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (199,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=DEFERRED_FWD_SCHEDULED src=test_advance_live frame=103.561 match_id=1786721560-TEST','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (200,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=DEFERRED_FWD_FIRED match_id=1786721560-TEST src=test_advance_live frame=103.811','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (201,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=ROSTER_SNAPSHOT team1=0 team2=0','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (202,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=HOSTNAME_UPDATE hostname=\'KTP Smoke Test - KTP - PENDING\'','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (203,'2026-08-14 15:32:41',2,'','AMXX (KTPHLTVRecorder)','[KTP HLTV] MATCH_WINDOW_OPEN match_id=1786721560-TEST half=h1 match_type=ktp map=dod_anzio hltv_port=27020 wall_time=1786721561 enabled=0','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (204,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=FWD_MATCH_START match_id=1786721560-TEST map=dod_anzio type=0 half=1','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (205,'2026-08-14 15:32:41',2,'','AMXX (KTPMatchHandler)','[KTP] event=PROACTIVE_CONTEXT_SAVE match_id=1786721560-TEST map=dod_anzio half=1','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (206,'2026-08-14 15:32:41',2,'dod_anzio','AMXX (KTPMatchHandler)','[KTP] event=ROUNDLIVE_MATCH_START_LOG matchid=1786721560-TEST map=dod_anzio half=1st','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (207,'2026-08-14 15:36:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (208,'2026-08-14 15:36:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (209,'2026-08-14 15:36:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (210,'2026-08-14 15:36:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=2 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (211,'2026-08-14 15:36:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (212,'2026-08-14 15:36:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (213,'2026-08-14 15:36:50',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (214,'2026-08-14 15:36:50',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (215,'2026-08-14 15:36:50',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (216,'2026-08-14 15:36:50',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=2 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (217,'2026-08-14 15:36:50',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (218,'2026-08-14 15:36:50',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (219,'2026-08-14 15:36:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (220,'2026-08-14 15:36:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (221,'2026-08-14 15:36:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (222,'2026-08-14 15:36:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (223,'2026-08-14 15:36:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (224,'2026-08-14 15:36:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (225,'2026-08-14 15:36:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (226,'2026-08-14 15:36:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (227,'2026-08-14 15:36:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (228,'2026-08-14 15:36:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=1 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (229,'2026-08-14 15:36:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (230,'2026-08-14 15:36:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (231,'2026-08-14 15:36:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (232,'2026-08-14 15:36:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=1 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (233,'2026-08-14 15:36:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (234,'2026-08-14 15:36:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=1 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (235,'2026-08-14 15:36:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (236,'2026-08-14 15:36:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (237,'2026-08-14 15:37:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (238,'2026-08-14 15:37:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=1 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (239,'2026-08-14 15:37:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (240,'2026-08-14 15:37:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=1 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (241,'2026-08-14 15:37:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (242,'2026-08-14 15:37:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (243,'2026-08-14 15:37:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (244,'2026-08-14 15:37:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (245,'2026-08-14 15:37:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (246,'2026-08-14 15:37:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (247,'2026-08-14 15:37:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (248,'2026-08-14 15:37:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (249,'2026-08-14 15:37:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (250,'2026-08-14 15:37:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (251,'2026-08-14 15:37:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (252,'2026-08-14 15:37:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (253,'2026-08-14 15:37:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (254,'2026-08-14 15:37:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (255,'2026-08-14 15:37:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (256,'2026-08-14 15:37:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (257,'2026-08-14 15:37:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (258,'2026-08-14 15:37:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (259,'2026-08-14 15:37:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (260,'2026-08-14 15:37:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (261,'2026-08-14 15:37:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (262,'2026-08-14 15:37:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (263,'2026-08-14 15:37:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (264,'2026-08-14 15:37:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (265,'2026-08-14 15:37:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (266,'2026-08-14 15:37:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (267,'2026-08-14 15:37:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (268,'2026-08-14 15:37:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (269,'2026-08-14 15:37:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (270,'2026-08-14 15:37:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (271,'2026-08-14 15:37:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (272,'2026-08-14 15:37:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (273,'2026-08-14 15:37:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (274,'2026-08-14 15:37:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=1 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (275,'2026-08-14 15:37:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (276,'2026-08-14 15:37:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=1 capteam=2 allies=0 axis=2 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (277,'2026-08-14 15:37:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (278,'2026-08-14 15:37:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (279,'2026-08-14 15:37:20',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] kill flag=3 capteam=2 mode=far victim=11 vname=Master killer=1 kname=Jill dist=3621 count_before=2 owner_before=1','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (280,'2026-08-14 15:37:22',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] after flag=3 allies=0 axis=2 capping=1 owner=1','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (281,'2026-08-14 15:37:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (282,'2026-08-14 15:37:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=1 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (283,'2026-08-14 15:37:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (284,'2026-08-14 15:37:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=2 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (285,'2026-08-14 15:37:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (286,'2026-08-14 15:37:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (287,'2026-08-14 15:37:29',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (288,'2026-08-14 15:37:29',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=1 capteam=2 allies=0 axis=2 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (289,'2026-08-14 15:37:29',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (290,'2026-08-14 15:37:29',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=3 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (291,'2026-08-14 15:37:29',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (292,'2026-08-14 15:37:29',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (293,'2026-08-14 15:37:31',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] walkoff ABORT flag=-1 no flag is capturing right now','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (294,'2026-08-14 15:37:33',2,'dod_anzio','AMXX (stats_logging)','performance issue. Function ksc_flush_task executed more than 1.4ms.','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (295,'2026-08-14 15:37:41',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (296,'2026-08-14 15:37:41',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=2 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (297,'2026-08-14 15:37:41',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (298,'2026-08-14 15:37:41',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=1 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (299,'2026-08-14 15:37:41',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (300,'2026-08-14 15:37:41',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (301,'2026-08-14 15:37:44',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (302,'2026-08-14 15:37:44',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=2 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (303,'2026-08-14 15:37:44',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (304,'2026-08-14 15:37:44',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=1 capteam=1 allies=2 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (305,'2026-08-14 15:37:44',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (306,'2026-08-14 15:37:44',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (307,'2026-08-14 15:37:46',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] walkoff flag=3 mover=7 mname=Banjo anchor=15 capteam=1 count_before=2','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (308,'2026-08-14 15:37:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] after flag=3 allies=1 axis=0 capping=0 owner=2','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (309,'2026-08-14 15:37:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (310,'2026-08-14 15:37:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=2 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (311,'2026-08-14 15:37:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (312,'2026-08-14 15:37:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=2 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (313,'2026-08-14 15:37:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (314,'2026-08-14 15:37:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (315,'2026-08-14 15:37:59',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (316,'2026-08-14 15:37:59',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=1 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (317,'2026-08-14 15:37:59',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (318,'2026-08-14 15:37:59',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=3 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (319,'2026-08-14 15:37:59',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (320,'2026-08-14 15:37:59',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (321,'2026-08-14 15:38:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (322,'2026-08-14 15:38:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (323,'2026-08-14 15:38:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (324,'2026-08-14 15:38:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=3 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (325,'2026-08-14 15:38:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (326,'2026-08-14 15:38:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (327,'2026-08-14 15:38:05',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (328,'2026-08-14 15:38:05',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (329,'2026-08-14 15:38:05',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (330,'2026-08-14 15:38:05',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=2 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (331,'2026-08-14 15:38:05',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (332,'2026-08-14 15:38:05',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (333,'2026-08-14 15:38:08',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (334,'2026-08-14 15:38:08',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (335,'2026-08-14 15:38:08',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (336,'2026-08-14 15:38:08',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=1 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (337,'2026-08-14 15:38:08',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (338,'2026-08-14 15:38:08',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (339,'2026-08-14 15:38:11',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (340,'2026-08-14 15:38:11',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (341,'2026-08-14 15:38:11',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (342,'2026-08-14 15:38:11',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=1 allies=1 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (343,'2026-08-14 15:38:11',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (344,'2026-08-14 15:38:11',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (345,'2026-08-14 15:38:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (346,'2026-08-14 15:38:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (347,'2026-08-14 15:38:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (348,'2026-08-14 15:38:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=1 capteam=2 allies=0 axis=2 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (349,'2026-08-14 15:38:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (350,'2026-08-14 15:38:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (351,'2026-08-14 15:38:15',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] walkoff flag=3 mover=11 mname=Master anchor=16 capteam=2 count_before=2','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (352,'2026-08-14 15:38:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] after flag=3 allies=0 axis=1 capping=0 owner=1','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (353,'2026-08-14 15:38:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (354,'2026-08-14 15:38:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (355,'2026-08-14 15:38:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (356,'2026-08-14 15:38:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=2 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (357,'2026-08-14 15:38:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (358,'2026-08-14 15:38:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (359,'2026-08-14 15:38:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (360,'2026-08-14 15:38:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (361,'2026-08-14 15:38:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (362,'2026-08-14 15:38:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=2 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (363,'2026-08-14 15:38:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (364,'2026-08-14 15:38:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (365,'2026-08-14 15:38:40',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (366,'2026-08-14 15:38:40',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (367,'2026-08-14 15:38:40',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (368,'2026-08-14 15:38:40',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=2 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (369,'2026-08-14 15:38:40',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (370,'2026-08-14 15:38:40',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (371,'2026-08-14 15:38:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (372,'2026-08-14 15:38:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (373,'2026-08-14 15:38:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (374,'2026-08-14 15:38:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=2 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (375,'2026-08-14 15:38:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (376,'2026-08-14 15:38:47',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (377,'2026-08-14 15:38:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (378,'2026-08-14 15:38:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=1 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (379,'2026-08-14 15:38:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (380,'2026-08-14 15:38:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=2 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (381,'2026-08-14 15:38:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (382,'2026-08-14 15:38:55',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (383,'2026-08-14 15:39:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (384,'2026-08-14 15:39:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (385,'2026-08-14 15:39:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (386,'2026-08-14 15:39:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=0 capteam=2 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (387,'2026-08-14 15:39:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (388,'2026-08-14 15:39:02',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (389,'2026-08-14 15:39:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (390,'2026-08-14 15:39:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (391,'2026-08-14 15:39:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (392,'2026-08-14 15:39:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=1 capping=1 capteam=2 allies=0 axis=2 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (393,'2026-08-14 15:39:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (394,'2026-08-14 15:39:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (395,'2026-08-14 15:39:17',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (396,'2026-08-14 15:39:17',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (397,'2026-08-14 15:39:17',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (398,'2026-08-14 15:39:17',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (399,'2026-08-14 15:39:17',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (400,'2026-08-14 15:39:17',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (401,'2026-08-14 15:39:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (402,'2026-08-14 15:39:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (403,'2026-08-14 15:39:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (404,'2026-08-14 15:39:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=2 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (405,'2026-08-14 15:39:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (406,'2026-08-14 15:39:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (407,'2026-08-14 15:39:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (408,'2026-08-14 15:39:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (409,'2026-08-14 15:39:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (410,'2026-08-14 15:39:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (411,'2026-08-14 15:39:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (412,'2026-08-14 15:39:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (413,'2026-08-14 15:39:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (414,'2026-08-14 15:39:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (415,'2026-08-14 15:39:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (416,'2026-08-14 15:39:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (417,'2026-08-14 15:39:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (418,'2026-08-14 15:39:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (419,'2026-08-14 15:39:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (420,'2026-08-14 15:39:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (421,'2026-08-14 15:39:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (422,'2026-08-14 15:39:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (423,'2026-08-14 15:39:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (424,'2026-08-14 15:39:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (425,'2026-08-14 15:39:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (426,'2026-08-14 15:39:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (427,'2026-08-14 15:39:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (428,'2026-08-14 15:39:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (429,'2026-08-14 15:39:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (430,'2026-08-14 15:39:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (431,'2026-08-14 15:39:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (432,'2026-08-14 15:39:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (433,'2026-08-14 15:39:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (434,'2026-08-14 15:39:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (435,'2026-08-14 15:39:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (436,'2026-08-14 15:39:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (437,'2026-08-14 15:39:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (438,'2026-08-14 15:39:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (439,'2026-08-14 15:39:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (440,'2026-08-14 15:39:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=2 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (441,'2026-08-14 15:39:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (442,'2026-08-14 15:39:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (443,'2026-08-14 15:39:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (444,'2026-08-14 15:39:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (445,'2026-08-14 15:39:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (446,'2026-08-14 15:39:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=1 capteam=1 allies=2 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (447,'2026-08-14 15:39:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (448,'2026-08-14 15:39:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (449,'2026-08-14 15:39:46',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] kill flag=3 capteam=1 mode=near victim=10 vname=Redfield killer=2 kname=Bowser dist=132 count_before=2 owner_before=2','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (450,'2026-08-14 15:39:48',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] after flag=3 allies=1 axis=0 capping=0 owner=2','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (451,'2026-08-14 15:39:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (452,'2026-08-14 15:39:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=1 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (453,'2026-08-14 15:39:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (454,'2026-08-14 15:39:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (455,'2026-08-14 15:39:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (456,'2026-08-14 15:39:53',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (457,'2026-08-14 15:39:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (458,'2026-08-14 15:39:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (459,'2026-08-14 15:39:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (460,'2026-08-14 15:39:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (461,'2026-08-14 15:39:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (462,'2026-08-14 15:39:56',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (463,'2026-08-14 15:39:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (464,'2026-08-14 15:39:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (465,'2026-08-14 15:39:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (466,'2026-08-14 15:39:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (467,'2026-08-14 15:39:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (468,'2026-08-14 15:39:58',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (469,'2026-08-14 15:40:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (470,'2026-08-14 15:40:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (471,'2026-08-14 15:40:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (472,'2026-08-14 15:40:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (473,'2026-08-14 15:40:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (474,'2026-08-14 15:40:01',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (475,'2026-08-14 15:40:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (476,'2026-08-14 15:40:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (477,'2026-08-14 15:40:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (478,'2026-08-14 15:40:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (479,'2026-08-14 15:40:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (480,'2026-08-14 15:40:04',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (481,'2026-08-14 15:40:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (482,'2026-08-14 15:40:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (483,'2026-08-14 15:40:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (484,'2026-08-14 15:40:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (485,'2026-08-14 15:40:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (486,'2026-08-14 15:40:07',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (487,'2026-08-14 15:40:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (488,'2026-08-14 15:40:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (489,'2026-08-14 15:40:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (490,'2026-08-14 15:40:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (491,'2026-08-14 15:40:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (492,'2026-08-14 15:40:10',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (493,'2026-08-14 15:40:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (494,'2026-08-14 15:40:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (495,'2026-08-14 15:40:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (496,'2026-08-14 15:40:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (497,'2026-08-14 15:40:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (498,'2026-08-14 15:40:13',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (499,'2026-08-14 15:40:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (500,'2026-08-14 15:40:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (501,'2026-08-14 15:40:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (502,'2026-08-14 15:40:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (503,'2026-08-14 15:40:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (504,'2026-08-14 15:40:16',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (505,'2026-08-14 15:40:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (506,'2026-08-14 15:40:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (507,'2026-08-14 15:40:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (508,'2026-08-14 15:40:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (509,'2026-08-14 15:40:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (510,'2026-08-14 15:40:19',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (511,'2026-08-14 15:40:22',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (512,'2026-08-14 15:40:22',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (513,'2026-08-14 15:40:22',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (514,'2026-08-14 15:40:22',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (515,'2026-08-14 15:40:22',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (516,'2026-08-14 15:40:22',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (517,'2026-08-14 15:40:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (518,'2026-08-14 15:40:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (519,'2026-08-14 15:40:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (520,'2026-08-14 15:40:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (521,'2026-08-14 15:40:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (522,'2026-08-14 15:40:25',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (523,'2026-08-14 15:40:28',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (524,'2026-08-14 15:40:28',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (525,'2026-08-14 15:40:28',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (526,'2026-08-14 15:40:28',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (527,'2026-08-14 15:40:28',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (528,'2026-08-14 15:40:28',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (529,'2026-08-14 15:40:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (530,'2026-08-14 15:40:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (531,'2026-08-14 15:40:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (532,'2026-08-14 15:40:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (533,'2026-08-14 15:40:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (534,'2026-08-14 15:40:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (535,'2026-08-14 15:40:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (536,'2026-08-14 15:40:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (537,'2026-08-14 15:40:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (538,'2026-08-14 15:40:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (539,'2026-08-14 15:40:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (540,'2026-08-14 15:40:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (541,'2026-08-14 15:40:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (542,'2026-08-14 15:40:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (543,'2026-08-14 15:40:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (544,'2026-08-14 15:40:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (545,'2026-08-14 15:40:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (546,'2026-08-14 15:40:36',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (547,'2026-08-14 15:40:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (548,'2026-08-14 15:40:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (549,'2026-08-14 15:40:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (550,'2026-08-14 15:40:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (551,'2026-08-14 15:40:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (552,'2026-08-14 15:40:39',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (553,'2026-08-14 15:40:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (554,'2026-08-14 15:40:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (555,'2026-08-14 15:40:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (556,'2026-08-14 15:40:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (557,'2026-08-14 15:40:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (558,'2026-08-14 15:40:42',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (559,'2026-08-14 15:40:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (560,'2026-08-14 15:40:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (561,'2026-08-14 15:40:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (562,'2026-08-14 15:40:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (563,'2026-08-14 15:40:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (564,'2026-08-14 15:40:45',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (565,'2026-08-14 15:40:48',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (566,'2026-08-14 15:40:48',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=1 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (567,'2026-08-14 15:40:48',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (568,'2026-08-14 15:40:48',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (569,'2026-08-14 15:40:48',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (570,'2026-08-14 15:40:48',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (571,'2026-08-14 15:40:51',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (572,'2026-08-14 15:40:51',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=1 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (573,'2026-08-14 15:40:51',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (574,'2026-08-14 15:40:51',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=1 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (575,'2026-08-14 15:40:51',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (576,'2026-08-14 15:40:51',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (577,'2026-08-14 15:41:15',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (578,'2026-08-14 15:41:15',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (579,'2026-08-14 15:41:15',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (580,'2026-08-14 15:41:15',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=0 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (581,'2026-08-14 15:41:15',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (582,'2026-08-14 15:41:15',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (583,'2026-08-14 15:41:18',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (584,'2026-08-14 15:41:18',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (585,'2026-08-14 15:41:18',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (586,'2026-08-14 15:41:18',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (587,'2026-08-14 15:41:18',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (588,'2026-08-14 15:41:18',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (589,'2026-08-14 15:41:21',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (590,'2026-08-14 15:41:21',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=1 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (591,'2026-08-14 15:41:21',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (592,'2026-08-14 15:41:21',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (593,'2026-08-14 15:41:21',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (594,'2026-08-14 15:41:21',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (595,'2026-08-14 15:41:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (596,'2026-08-14 15:41:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (597,'2026-08-14 15:41:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (598,'2026-08-14 15:41:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (599,'2026-08-14 15:41:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (600,'2026-08-14 15:41:24',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (601,'2026-08-14 15:41:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (602,'2026-08-14 15:41:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (603,'2026-08-14 15:41:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (604,'2026-08-14 15:41:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=0 capteam=1 allies=1 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (605,'2026-08-14 15:41:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (606,'2026-08-14 15:41:27',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (607,'2026-08-14 15:41:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 0 name=POINT_ANZIO_LAUNDRY owner=0 capping=0 capteam=0 allies=0 axis=0 ox=-1495 oy=-326','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (608,'2026-08-14 15:41:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 1 name=POINT_BRIDGE owner=1 capping=0 capteam=1 allies=0 axis=0 ox=1040 oy=-288','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (609,'2026-08-14 15:41:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 2 name=POINT_ANZIO_STREET owner=0 capping=0 capteam=0 allies=0 axis=0 ox=448 oy=800','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (610,'2026-08-14 15:41:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 3 name=POINT_ANZIO_PLAZA owner=2 capping=1 capteam=1 allies=2 axis=0 ox=-698 oy=923','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (611,'2026-08-14 15:41:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] flag 4 name=POINT_ANZIO_HILL owner=0 capping=0 capteam=0 allies=0 axis=0 ox=1375 oy=1682','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (612,'2026-08-14 15:41:30',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] scan done flags=5','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (613,'2026-08-14 15:41:31',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] kill flag=3 capteam=1 mode=far victim=1 vname=Jill killer=2 kname=Bowser dist=2419 count_before=2 owner_before=2','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (614,'2026-08-14 15:41:33',2,'dod_anzio','AMXX (KTPBreakDrive)','[BD] after flag=3 allies=2 axis=0 capping=1 owner=2','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (615,'2026-08-14 15:41:44',2,'dod_anzio','AMXX (KTPMatchHandler)','[KTP] event=TEST_END_MATCH match_id=1786721560-TEST final=1-0','','1786721560-TEST');
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (616,'2026-08-14 15:41:44',2,'dod_anzio','AMXX (KTPMatchHandler)','[KTP] event=DISCORD_EDIT_SKIP reason=no_msg_id','',NULL);
INSERT INTO `hlstats_Events_Admin` (`id`, `eventTime`, `serverId`, `map`, `type`, `message`, `playerName`, `match_id`) VALUES (617,'2026-08-14 15:41:44',2,'dod_anzio','AMXX (KTPHLTVRecorder)','[KTP HLTV] MATCH_WINDOW_CLOSE match_id=1786721560-TEST match_type=ktp map=dod_anzio hltv_port=27020 wall_time=1786722104 score=1-0','',NULL);
/*!40000 ALTER TABLE `hlstats_Events_Admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_ChangeName`
--

DROP TABLE IF EXISTS `hlstats_Events_ChangeName`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_ChangeName` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `oldName` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `newName` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM AUTO_INCREMENT=4869 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_ChangeName`
--

LOCK TABLES `hlstats_Events_ChangeName` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_ChangeName` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_ChangeName` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_ChangeRole`
--

DROP TABLE IF EXISTS `hlstats_Events_ChangeRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_ChangeRole` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `role` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM AUTO_INCREMENT=88071 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_ChangeRole`
--

LOCK TABLES `hlstats_Events_ChangeRole` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_ChangeRole` DISABLE KEYS */;
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88055,'2026-08-14 15:31:06',2,'',321,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88056,'2026-08-14 15:31:07',2,'',322,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88057,'2026-08-14 15:31:09',2,'',323,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88058,'2026-08-14 15:31:10',2,'',324,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88059,'2026-08-14 15:31:10',2,'',325,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88060,'2026-08-14 15:31:11',2,'',326,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88061,'2026-08-14 15:31:12',2,'',327,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88062,'2026-08-14 15:31:12',2,'',328,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88063,'2026-08-14 15:31:14',2,'',329,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88064,'2026-08-14 15:31:14',2,'',330,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88065,'2026-08-14 15:31:15',2,'',331,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88066,'2026-08-14 15:31:16',2,'',332,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88067,'2026-08-14 15:31:16',2,'',333,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88068,'2026-08-14 15:31:17',2,'',334,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88069,'2026-08-14 15:31:18',2,'',335,'Random',NULL);
INSERT INTO `hlstats_Events_ChangeRole` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `role`, `match_id`) VALUES (88070,'2026-08-14 15:31:20',2,'',336,'Random',NULL);
/*!40000 ALTER TABLE `hlstats_Events_ChangeRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_ChangeTeam`
--

DROP TABLE IF EXISTS `hlstats_Events_ChangeTeam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_ChangeTeam` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `team` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM AUTO_INCREMENT=429629 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_ChangeTeam`
--

LOCK TABLES `hlstats_Events_ChangeTeam` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_ChangeTeam` DISABLE KEYS */;
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429613,'2026-08-14 15:31:05',2,'',321,'Allies',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429614,'2026-08-14 15:31:06',2,'',322,'Axis',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429615,'2026-08-14 15:31:08',2,'',323,'Allies',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429616,'2026-08-14 15:31:09',2,'',324,'Axis',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429617,'2026-08-14 15:31:09',2,'',325,'Axis',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429618,'2026-08-14 15:31:10',2,'',326,'Allies',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429619,'2026-08-14 15:31:11',2,'',327,'Allies',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429620,'2026-08-14 15:31:11',2,'',328,'Axis',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429621,'2026-08-14 15:31:13',2,'',329,'Allies',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429622,'2026-08-14 15:31:13',2,'',330,'Allies',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429623,'2026-08-14 15:31:14',2,'',331,'Axis',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429624,'2026-08-14 15:31:15',2,'',332,'Axis',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429625,'2026-08-14 15:31:15',2,'',333,'Allies',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429626,'2026-08-14 15:31:16',2,'',334,'Axis',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429627,'2026-08-14 15:31:17',2,'',335,'Allies',NULL);
INSERT INTO `hlstats_Events_ChangeTeam` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `team`, `match_id`) VALUES (429628,'2026-08-14 15:31:19',2,'',336,'Axis',NULL);
/*!40000 ALTER TABLE `hlstats_Events_ChangeTeam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Chat`
--

DROP TABLE IF EXISTS `hlstats_Events_Chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Chat` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `message_mode` tinyint NOT NULL DEFAULT '0',
  `message` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`),
  KEY `serverId` (`serverId`),
  FULLTEXT KEY `message` (`message`)
) ENGINE=MyISAM AUTO_INCREMENT=257885 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Chat`
--

LOCK TABLES `hlstats_Events_Chat` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_Chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Connects`
--

DROP TABLE IF EXISTS `hlstats_Events_Connects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Connects` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `ipAddress` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hostname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hostgroup` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `eventTime_Disconnect` datetime DEFAULT NULL,
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM AUTO_INCREMENT=44969 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Connects`
--

LOCK TABLES `hlstats_Events_Connects` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Connects` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_Connects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Disconnects`
--

DROP TABLE IF EXISTS `hlstats_Events_Disconnects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Disconnects` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33823 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Disconnects`
--

LOCK TABLES `hlstats_Events_Disconnects` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Disconnects` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_Disconnects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Entries`
--

DROP TABLE IF EXISTS `hlstats_Events_Entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Entries` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM AUTO_INCREMENT=400630 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Entries`
--

LOCK TABLES `hlstats_Events_Entries` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_Entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Frags`
--

DROP TABLE IF EXISTS `hlstats_Events_Frags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Frags` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `killerId` int unsigned NOT NULL DEFAULT '0',
  `victimId` int unsigned NOT NULL DEFAULT '0',
  `weapon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `headshot` tinyint(1) NOT NULL DEFAULT '0',
  `killerRole` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `victimRole` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pos_x` mediumint DEFAULT NULL,
  `pos_y` mediumint DEFAULT NULL,
  `pos_z` mediumint DEFAULT NULL,
  `pos_victim_x` mediumint DEFAULT NULL,
  `pos_victim_y` mediumint DEFAULT NULL,
  `pos_victim_z` mediumint DEFAULT NULL,
  `half` tinyint NOT NULL DEFAULT '0',
  `k_prone` tinyint NOT NULL DEFAULT '0',
  `v_prone` tinyint NOT NULL DEFAULT '0',
  `k_scope` tinyint NOT NULL DEFAULT '0',
  `v_scope` tinyint NOT NULL DEFAULT '0',
  `k_clip` smallint NOT NULL DEFAULT '-1',
  `k_ammo` smallint NOT NULL DEFAULT '-1',
  `v_clip` smallint NOT NULL DEFAULT '-1',
  `v_ammo` smallint NOT NULL DEFAULT '-1',
  `is_last_flag_defense` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `killerId` (`killerId`),
  KEY `victimId` (`victimId`),
  KEY `serverId` (`serverId`),
  KEY `headshot` (`headshot`),
  KEY `map` (`map`(5)),
  KEY `weapon16` (`weapon`(16)),
  KEY `killerRole` (`killerRole`(8)),
  KEY `idx_match_id` (`match_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1255574 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Frags`
--

LOCK TABLES `hlstats_Events_Frags` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Frags` DISABLE KEYS */;
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255455,'2026-08-14 15:31:51',2,'',NULL,325,333,'mg34',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255456,'2026-08-14 15:31:54',2,'',NULL,336,335,'mg34',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255457,'2026-08-14 15:31:56',2,'',NULL,333,328,'grenade',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255458,'2026-08-14 15:31:57',2,'',NULL,329,336,'greasegun',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255459,'2026-08-14 15:31:58',2,'',NULL,327,325,'bar',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255460,'2026-08-14 15:32:06',2,'',NULL,327,332,'bar',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255461,'2026-08-14 15:32:11',2,'',NULL,327,322,'bar',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255462,'2026-08-14 15:32:16',2,'',NULL,331,326,'mg42',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255463,'2026-08-14 15:32:24',2,'',NULL,331,321,'mg42',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255464,'2026-08-14 15:32:27',2,'',NULL,333,331,'30cal',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255465,'2026-08-14 15:32:30',2,'',NULL,334,333,'kar',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255466,'2026-08-14 15:32:31',2,'',NULL,327,336,'bar',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255467,'2026-08-14 15:32:33',2,'',NULL,323,328,'30cal',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255468,'2026-08-14 15:32:45',2,'dod_anzio','1786721560-TEST',334,327,'kar',0,'Random','Random',1780,-52,-356,1403,863,-390,1,0,0,0,0,4,59,5,219,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255469,'2026-08-14 15:32:55',2,'dod_anzio','1786721560-TEST',323,324,'30cal',0,'Random','Random',1260,1448,-270,1367,1685,-252,1,2,0,0,0,137,145,1,1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255470,'2026-08-14 15:32:56',2,'dod_anzio','1786721560-TEST',323,336,'30cal',0,'Random','Random',1260,1448,-270,1540,2134,-301,1,2,0,0,0,136,145,25,180,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255471,'2026-08-14 15:32:58',2,'dod_anzio','1786721560-TEST',336,323,'grenade2',0,'Random','Random',884,1227,-284,1260,1448,-270,1,0,2,0,0,25,0,135,145,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255472,'2026-08-14 15:33:00',2,'dod_anzio','1786721560-TEST',335,322,'30cal',0,'Random','Random',-556,816,-387,-452,978,-404,1,0,0,0,0,146,150,2,2,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255473,'2026-08-14 15:33:01',2,'dod_anzio','1786721560-TEST',330,334,'30cal',0,'Random','Random',713,-86,-436,1457,88,-348,1,2,0,0,0,142,150,0,59,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255474,'2026-08-14 15:33:06',2,'dod_anzio','1786721560-TEST',322,335,'grenade2',0,'Random','Random',1387,1209,-264,-535,848,-398,1,0,0,0,0,2,0,145,150,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255475,'2026-08-14 15:33:08',2,'dod_anzio','1786721560-TEST',329,325,'greasegun',0,'Random','Random',919,-185,-342,1400,813,-372,1,0,0,0,0,17,165,75,375,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255476,'2026-08-14 15:33:15',2,'dod_anzio','1786721560-TEST',333,331,'garand',0,'Random','Random',-6,798,-390,258,818,-390,1,0,0,0,0,4,80,67,375,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255477,'2026-08-14 15:33:25',2,'dod_anzio','1786721560-TEST',328,333,'pschreck',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255478,'2026-08-14 15:33:27',2,'dod_anzio','1786721560-TEST',329,334,'greasegun',0,'Random','Random',1361,-102,-353,1405,849,-372,1,0,0,0,0,12,151,72,375,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255479,'2026-08-14 15:33:27',2,'dod_anzio','1786721560-TEST',333,332,'grenade',0,'Random','Random',1361,-102,-353,521,790,-355,1,0,0,0,0,0,0,30,180,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255480,'2026-08-14 15:33:32',2,'dod_anzio','1786721560-TEST',328,330,'luger',1,'Random','Random',526,795,-372,110,900,-390,1,0,2,0,0,8,16,141,150,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255481,'2026-08-14 15:33:32',2,'dod_anzio','1786721560-TEST',327,328,'m1carbine',1,'Random','Random',-4,814,-390,526,795,-372,1,0,0,0,0,11,150,1,3,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255482,'2026-08-14 15:33:35',2,'dod_anzio','1786721560-TEST',322,329,'mp40',0,'Random','Random',1408,851,-372,1361,-102,-353,1,0,0,0,0,29,150,0,151,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255483,'2026-08-14 15:33:35',2,'dod_anzio','1786721560-TEST',336,327,'kar',0,'Random','Random',273,885,-390,-4,814,-390,1,0,0,0,0,5,60,8,150,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255484,'2026-08-14 15:33:38',2,'dod_anzio','1786721560-TEST',336,321,'luger',0,'Random','Random',153,849,-372,78,856,-390,1,0,0,0,0,5,16,20,162,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255485,'2026-08-14 15:33:52',2,'dod_anzio','1786721560-TEST',326,336,'colt',0,'Random','Random',56,821,-390,152,757,-390,1,0,0,0,0,5,14,4,16,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255486,'2026-08-14 15:33:52',2,'dod_anzio','1786721560-TEST',336,326,'grenade2',0,'Random','Random',152,757,-390,56,821,-390,1,6,0,0,0,4,0,4,14,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255487,'2026-08-14 15:34:04',2,'dod_anzio','1786721560-TEST',334,335,'kar',0,'Random','Random',-176,1166,-372,-1271,868,-198,1,0,0,0,0,5,60,5,50,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255488,'2026-08-14 15:34:06',2,'dod_anzio','1786721560-TEST',325,329,'mg42',0,'Random','Random',463,799,-390,-6,804,-390,1,2,0,0,0,244,250,6,80,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255489,'2026-08-14 15:34:08',2,'dod_anzio','1786721560-TEST',322,327,'mp40',0,'Random','Random',1171,-272,-336,384,-357,-390,1,0,1,0,0,27,148,16,240,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255490,'2026-08-14 15:34:10',2,'dod_anzio','1786721560-TEST',325,323,'mg42',0,'Random','Random',56,822,-390,-24,804,-390,1,0,0,0,0,240,250,1,1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255491,'2026-08-14 15:34:18',2,'dod_anzio','1786721560-TEST',325,330,'mg42',0,'Random','Random',82,848,-390,-24,835,-390,1,0,0,0,0,232,250,1,1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255492,'2026-08-14 15:34:22',2,'dod_anzio','1786721560-TEST',333,334,'m1carbine',0,'Random','Random',-1147,694,-389,-700,922,-404,1,0,0,0,0,12,150,2,2,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255493,'2026-08-14 15:34:41',2,'dod_anzio','1786721560-TEST',321,324,'bazooka',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255494,'2026-08-14 15:34:45',2,'dod_anzio','1786721560-TEST',328,335,'mp44',0,'Random','Random',404,-31,-390,-179,-128,-414,1,1,0,0,0,24,172,18,240,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255495,'2026-08-14 15:34:45',2,'dod_anzio','1786721560-TEST',329,325,'greasegun',0,'Random','Random',20,-159,-412,-371,603,-404,1,0,0,0,0,26,180,230,250,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255496,'2026-08-14 15:34:48',2,'dod_anzio','1786721560-TEST',328,321,'mp44',0,'Random','Random',404,-31,-372,-233,-96,-425,1,0,0,0,0,10,172,1,4,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255497,'2026-08-14 15:34:48',2,'dod_anzio','1786721560-TEST',329,332,'greasegun',0,'Random','Random',-26,60,-420,-7,807,-390,1,0,0,0,0,18,180,4,60,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255498,'2026-08-14 15:34:49',2,'dod_anzio','1786721560-TEST',328,326,'mp44',0,'Random','Random',404,-31,-372,-4,-7,-420,1,0,0,0,0,5,172,3,50,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255499,'2026-08-14 15:34:56',2,'dod_anzio','1786721560-TEST',322,329,'mp40',0,'Random','Random',75,826,-390,-24,845,-390,1,0,0,0,0,23,144,1,1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255500,'2026-08-14 15:35:01',2,'dod_anzio','1786721560-TEST',329,322,'grenade',0,'Random','Random',44,-2287,-588,56,787,-356,1,0,0,0,0,15,150,22,144,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255501,'2026-08-14 15:35:02',2,'dod_anzio','1786721560-TEST',327,328,'grenade',0,'Random','Random',-607,-478,-386,-87,-63,-438,1,0,0,0,0,0,240,13,142,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255502,'2026-08-14 15:35:17',2,'dod_anzio','1786721560-TEST',333,336,'m1carbine',0,'Random','Random',-1276,860,-212,-698,917,-404,1,0,0,0,0,13,146,2,1,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255503,'2026-08-14 15:35:19',2,'dod_anzio','1786721560-TEST',325,327,'mg42',0,'Random','Random',1474,7,-348,1044,-282,-332,1,0,0,0,0,248,250,20,220,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255504,'2026-08-14 15:35:20',2,'dod_anzio','1786721560-TEST',333,331,'grenade',0,'Random','Random',-1238,860,-198,-664,767,-401,1,0,0,0,0,10,146,72,375,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255505,'2026-08-14 15:35:26',2,'dod_anzio','1786721560-TEST',334,329,'scopedkar',0,'Random','Random',10,808,-390,0,613,-410,1,0,0,0,0,5,60,13,135,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255506,'2026-08-14 15:35:31',2,'dod_anzio','1786721560-TEST',330,325,'garand',1,'Random','Random',994,-264,-332,1474,7,-348,1,0,0,0,0,7,80,246,250,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255507,'2026-08-14 15:35:31',2,'dod_anzio','1786721560-TEST',326,334,'30cal',0,'Random','Random',-13,584,-410,10,808,-390,1,0,0,0,0,134,150,3,60,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255508,'2026-08-14 15:35:33',2,'dod_anzio','1786721560-TEST',333,332,'m1carbine',0,'Random','Random',-1072,915,-422,-142,1147,-372,1,0,0,0,0,3,141,2,1,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255509,'2026-08-14 15:35:46',2,'dod_anzio','1786721560-TEST',324,321,'scopedkar',0,'Random','Random',-10,804,-390,-4,-21,-420,1,0,0,1,0,5,60,5,48,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255510,'2026-08-14 15:35:57',2,'dod_anzio','1786721560-TEST',328,330,'mg42',0,'Random','Random',1175,-264,-354,1039,-284,-350,1,2,0,0,0,244,250,7,14,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255511,'2026-08-14 15:35:59',2,'dod_anzio','1786721560-TEST',335,324,'greasegun',0,'Random','Random',-176,-103,-420,-11,729,-400,1,0,0,0,0,22,180,4,60,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255512,'2026-08-14 15:35:59',2,'dod_anzio','1786721560-TEST',328,326,'mg42',0,'Random','Random',1175,-264,-354,1072,-254,-340,1,0,0,0,0,238,250,121,150,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255513,'2026-08-14 15:35:59',2,'dod_anzio','1786721560-TEST',322,323,'luger',0,'Random','Random',-699,920,-404,-479,485,-404,1,0,0,0,0,1,16,3,50,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255514,'2026-08-14 15:36:03',2,'dod_anzio','1786721560-TEST',335,328,'greasegun',1,'Random','Random',393,-318,-372,1175,-264,-354,1,0,2,0,0,21,180,226,250,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255515,'2026-08-14 15:36:09',2,'dod_anzio','1786721560-TEST',335,334,'greasegun',0,'Random','Random',861,-291,-370,1501,-193,-356,1,0,0,0,0,13,180,250,250,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255516,'2026-08-14 15:36:15',2,'dod_anzio','1786721560-TEST',333,336,'m1carbine',0,'Random','Random',1364,-105,-353,1418,1040,-337,1,0,0,0,0,4,113,2,60,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255517,'2026-08-14 15:36:33',2,'dod_anzio','1786721560-TEST',326,332,'thompson',0,'Random','Random',20,-35,-438,-588,688,-422,1,0,0,0,0,22,180,168,250,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255518,'2026-08-14 15:36:33',2,'dod_anzio','1786721560-TEST',321,325,'colt',0,'Random','Random',396,843,-372,865,840,-390,1,0,0,0,0,2,14,5,60,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255519,'2026-08-14 15:36:38',2,'dod_anzio','1786721560-TEST',328,333,'k43',0,'Random','Random',1359,1043,-353,1364,-105,-353,1,0,0,0,0,5,70,0,86,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255520,'2026-08-14 15:36:43',2,'dod_anzio','1786721560-TEST',326,324,'thompson',1,'Random','Random',-2,791,-390,136,826,-372,1,0,0,0,0,22,171,3,16,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255521,'2026-08-14 15:36:46',2,'dod_anzio','1786721560-TEST',326,328,'thompson',0,'Random','Random',59,808,-372,938,849,-382,1,0,0,0,0,18,171,4,70,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255522,'2026-08-14 15:36:48',2,'dod_anzio','1786721560-TEST',334,326,'kar',0,'Random','Random',147,1111,-372,346,859,-372,1,0,0,0,0,5,55,17,171,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255523,'2026-08-14 15:36:51',2,'dod_anzio','1786721560-TEST',331,335,'k43',0,'Random','Random',-523,1265,-422,-421,938,-404,1,0,0,0,0,8,70,30,162,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255524,'2026-08-14 15:36:55',2,'dod_anzio','1786721560-TEST',336,329,'pschreck',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255525,'2026-08-14 15:37:02',2,'dod_anzio','1786721560-TEST',321,331,'colt',0,'Random','Random',-437,708,-364,-697,916,-404,1,0,0,0,0,6,1,0,70,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255526,'2026-08-14 15:37:29',2,'dod_anzio','1786721560-TEST',321,332,'bazooka',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,-1,-1,-1,-1,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255527,'2026-08-14 15:37:30',2,'dod_anzio','1786721560-TEST',335,334,'greasegun',0,'Random','Random',395,-311,-390,1043,-286,-332,1,0,0,0,0,23,180,4,54,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255528,'2026-08-14 15:37:31',2,'dod_anzio','1786721560-TEST',330,325,'thompson',0,'Random','Random',383,-279,-372,1172,-273,-336,1,0,0,0,0,30,180,2,1,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255529,'2026-08-14 15:37:40',2,'dod_anzio','1786721560-TEST',323,328,'colt',0,'Random','Random',-649,703,-422,-698,923,-422,1,0,0,0,0,5,7,4,8,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255530,'2026-08-14 15:37:46',2,'dod_anzio','1786721560-TEST',324,333,'scopedkar',0,'Random','Random',904,857,-382,-6,802,-390,1,0,0,1,0,3,60,0,150,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255531,'2026-08-14 15:37:53',2,'dod_anzio','1786721560-TEST',330,336,'thompson',0,'Random','Random',-24,-21,-438,-13,577,-392,1,0,0,0,0,24,179,1,4,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255532,'2026-08-14 15:37:55',2,'dod_anzio','1786721560-TEST',326,332,'greasegun',0,'Random','Random',1167,-278,-335,1461,621,-372,1,0,0,0,0,28,180,2,2,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255533,'2026-08-14 15:38:03',2,'dod_anzio','1786721560-TEST',334,330,'scopedkar',0,'Random','Random',-396,1155,-422,-663,803,-388,1,0,0,0,0,2,60,23,179,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255534,'2026-08-14 15:38:04',2,'dod_anzio','1786721560-TEST',331,323,'mg42',0,'Random','Random',-364,1154,-422,-606,856,-355,1,2,0,0,0,250,250,0,0,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255535,'2026-08-14 15:38:10',2,'dod_anzio','1786721560-TEST',331,321,'mg42',0,'Random','Random',-651,991,-404,-581,734,-411,1,0,0,0,0,240,250,1,2,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255536,'2026-08-14 15:38:14',2,'dod_anzio','1786721560-TEST',331,327,'mg42',0,'Random','Random',-697,919,-422,-552,554,-422,1,0,0,0,0,226,250,4,38,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255537,'2026-08-14 15:38:15',2,'dod_anzio','1786721560-TEST',326,322,'greasegun',0,'Random','Random',898,366,-518,857,515,-486,1,0,0,0,0,30,177,0,8,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255538,'2026-08-14 15:38:16',2,'dod_anzio','1786721560-TEST',326,328,'greasegun',0,'Random','Random',898,366,-518,825,518,-486,1,0,0,0,0,25,177,1,0,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255539,'2026-08-14 15:38:21',2,'dod_anzio','1786721560-TEST',328,326,'grenade2',0,'Random','Random',2176,1804,-355,861,399,-508,1,0,0,0,0,1,0,24,177,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255540,'2026-08-14 15:38:28',2,'dod_anzio','1786721560-TEST',329,334,'thompson',0,'Random','Random',-1086,663,-402,-694,951,-404,1,0,0,0,0,23,180,5,54,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255541,'2026-08-14 15:38:39',2,'dod_anzio','1786721560-TEST',336,329,'scopedkar',0,'Random','Random',-258,1207,-416,-709,874,-422,1,0,0,1,0,5,60,27,172,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255542,'2026-08-14 15:38:42',2,'dod_anzio','1786721560-TEST',336,323,'scopedkar',0,'Random','Random',-258,1207,-416,-1064,690,-389,1,0,0,1,0,4,60,2,2,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255543,'2026-08-14 15:38:45',2,'dod_anzio','1786721560-TEST',335,331,'thompson',0,'Random','Random',-4,791,-390,56,819,-390,1,0,0,0,0,26,180,218,250,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255544,'2026-08-14 15:38:57',2,'dod_anzio','1786721560-TEST',332,321,'mg34',0,'Random','Random',98,831,-372,-3,789,-390,1,0,0,0,0,73,375,15,150,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255545,'2026-08-14 15:38:58',2,'dod_anzio','1786721560-TEST',332,335,'mg34',0,'Random','Random',57,820,-390,104,698,-438,1,0,0,0,0,69,375,25,175,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255546,'2026-08-14 15:39:01',2,'dod_anzio','1786721560-TEST',326,332,'bar',0,'Random','Random',-1,791,-390,62,820,-390,1,0,0,0,0,20,240,68,375,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255547,'2026-08-14 15:39:01',2,'dod_anzio','1786721560-TEST',324,327,'scopedkar',0,'Random','Random',-255,1356,-264,-544,1149,-396,1,0,0,1,0,4,57,150,150,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255548,'2026-08-14 15:39:04',2,'dod_anzio','1786721560-TEST',324,330,'scopedkar',1,'Random','Random',-255,1356,-264,-1243,299,-390,1,0,0,1,0,3,57,4,50,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255549,'2026-08-14 15:39:13',2,'dod_anzio','1786721560-TEST',324,326,'scopedkar',0,'Random','Random',-96,1169,-390,137,1102,-372,1,0,0,0,0,5,54,1,1,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255550,'2026-08-14 15:39:33',2,'dod_anzio','1786721560-TEST',334,333,'mg42',0,'Random','Random',-904,895,-422,-195,1148,-381,1,2,0,0,0,246,250,24,180,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255551,'2026-08-14 15:39:37',2,'dod_anzio','1786721560-TEST',333,336,'grenade',0,'Random','Random',-506,-1039,-442,-566,1416,-396,1,0,0,0,0,24,0,8,15,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255552,'2026-08-14 15:39:41',2,'dod_anzio','1786721560-TEST',330,334,'greasegun',0,'Random','Random',-487,486,-404,-1218,851,-224,1,0,0,0,0,30,180,244,250,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255553,'2026-08-14 15:39:41',2,'dod_anzio','1786721560-TEST',327,332,'spring',0,'Random','Random',719,-334,-372,1762,-136,-356,1,0,0,1,0,5,50,15,180,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255554,'2026-08-14 15:39:48',2,'dod_anzio','1786721560-TEST',325,327,'mg42',0,'Random','Random',1175,-269,-354,808,-210,-363,1,2,0,0,0,248,250,4,50,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255555,'2026-08-14 15:39:52',2,'dod_anzio','1786721560-TEST',324,323,'scopedkar',0,'Random','Random',-389,1155,-422,-669,761,-404,1,0,0,1,0,4,53,20,231,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255556,'2026-08-14 15:39:53',2,'dod_anzio','1786721560-TEST',329,325,'greasegun',0,'Random','Random',391,-323,-372,1175,-269,-354,1,0,1,0,0,24,180,246,250,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255557,'2026-08-14 15:39:56',2,'dod_anzio','1786721560-TEST',324,335,'scopedkar',0,'Random','Random',-712,785,-418,-143,131,-414,1,0,0,1,0,3,53,1,1,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255558,'2026-08-14 15:39:57',2,'dod_anzio','1786721560-TEST',321,322,'spring',0,'Random','Random',656,-564,-268,1759,-92,-374,1,0,2,1,0,4,50,75,375,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255559,'2026-08-14 15:40:16',2,'dod_anzio','1786721560-TEST',334,329,'mp44',0,'Random','Random',934,847,-382,451,800,-372,1,0,0,0,0,21,180,26,173,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255560,'2026-08-14 15:40:17',2,'dod_anzio','1786721560-TEST',324,327,'scopedkar',1,'Random','Random',-638,626,-404,19,-54,-420,1,0,0,1,0,4,50,27,180,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255561,'2026-08-14 15:40:20',2,'dod_anzio','1786721560-TEST',333,332,'garand',0,'Random','Random',-3,789,-390,273,886,-390,1,0,0,0,0,5,80,3,60,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255562,'2026-08-14 15:40:25',2,'dod_anzio','1786721560-TEST',335,324,'30cal',0,'Random','Random',-147,75,-438,-410,410,-422,1,2,0,0,0,142,150,1,50,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255563,'2026-08-14 15:40:26',2,'dod_anzio','1786721560-TEST',333,331,'garand',0,'Random','Random',0,808,-390,885,839,-382,1,0,0,0,0,1,80,5,59,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255564,'2026-08-14 15:40:29',2,'dod_anzio','1786721560-TEST',333,336,'garand',0,'Random','Random',0,808,-390,986,823,-382,1,0,1,0,0,8,72,0,5,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255565,'2026-08-14 15:40:37',2,'dod_anzio','1786721560-TEST',325,333,'mg42',1,'Random','Random',290,856,-390,27,848,-390,1,0,0,0,0,244,250,7,72,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255566,'2026-08-14 15:40:43',2,'dod_anzio','1786721560-TEST',334,326,'mp44',0,'Random','Random',-624,1274,-396,-660,767,-400,1,0,0,0,0,17,170,2,2,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255567,'2026-08-14 15:40:48',2,'dod_anzio','1786721560-TEST',328,323,'scopedkar',0,'Random','Random',-939,860,-422,37,-88,-420,1,0,0,1,0,5,60,30,172,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255568,'2026-08-14 15:40:48',2,'dod_anzio','1786721560-TEST',326,334,'grenade',0,'Random','Random',1140,-252,-332,-907,826,-404,1,0,0,0,0,2,0,16,170,1);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255569,'2026-08-14 15:40:50',2,'dod_anzio','1786721560-TEST',331,321,'kar',0,'Random','Random',1807,1032,-320,1788,577,-278,1,0,0,0,0,5,60,5,48,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255570,'2026-08-14 15:40:54',2,'dod_anzio','1786721560-TEST',330,325,'30cal',0,'Random','Random',-206,-131,-422,-15,-22,-420,1,2,0,0,0,146,150,236,250,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255571,'2026-08-14 15:41:29',2,'dod_anzio','1786721560-TEST',333,328,'thompson',0,'Random','Random',-1288,-100,-390,-1197,585,-390,1,0,0,0,0,21,180,5,59,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255572,'2026-08-14 15:41:29',2,'dod_anzio','1786721560-TEST',332,330,'mp44',0,'Random','Random',1425,725,-390,1741,221,-372,1,0,0,0,0,13,180,140,150,0);
INSERT INTO `hlstats_Events_Frags` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `killerId`, `victimId`, `weapon`, `headshot`, `killerRole`, `victimRole`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `half`, `k_prone`, `v_prone`, `k_scope`, `v_scope`, `k_clip`, `k_ammo`, `v_clip`, `v_ammo`, `is_last_flag_defense`) VALUES (1255573,'2026-08-14 15:41:43',2,'dod_anzio','1786721560-TEST',336,323,'mg34',0,'Random','Random',NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,-1,-1,-1,-1,0);
/*!40000 ALTER TABLE `hlstats_Events_Frags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Latency`
--

DROP TABLE IF EXISTS `hlstats_Events_Latency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Latency` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `ping` int unsigned NOT NULL DEFAULT '0',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Latency`
--

LOCK TABLES `hlstats_Events_Latency` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Latency` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_Latency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_PlayerActions`
--

DROP TABLE IF EXISTS `hlstats_Events_PlayerActions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_PlayerActions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `actionId` int unsigned NOT NULL DEFAULT '0',
  `bonus` int NOT NULL DEFAULT '0',
  `pos_x` mediumint DEFAULT NULL,
  `pos_y` mediumint DEFAULT NULL,
  `pos_z` mediumint DEFAULT NULL,
  `contester_count` smallint DEFAULT NULL,
  `time_remaining` decimal(6,1) DEFAULT NULL,
  `is_capout` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`),
  KEY `actionId` (`actionId`),
  KEY `idx_match_id_act` (`match_id`)
) ENGINE=MyISAM AUTO_INCREMENT=543934 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_PlayerActions`
--

LOCK TABLES `hlstats_Events_PlayerActions` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_PlayerActions` DISABLE KEYS */;
INSERT INTO `hlstats_Events_PlayerActions` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `playerId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `contester_count`, `time_remaining`, `is_capout`) VALUES (543931,'2026-08-14 15:37:48',2,'dod_anzio','1786721560-TEST',324,725,0,904,857,-382,2,2.0,1);
INSERT INTO `hlstats_Events_PlayerActions` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `playerId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `contester_count`, `time_remaining`, `is_capout`) VALUES (543932,'2026-08-14 15:38:18',2,'dod_anzio','1786721560-TEST',326,725,0,898,366,-518,2,0.6,0);
INSERT INTO `hlstats_Events_PlayerActions` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `playerId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `contester_count`, `time_remaining`, `is_capout`) VALUES (543933,'2026-08-14 15:39:48',2,'dod_anzio','1786721560-TEST',322,725,0,1753,99,-356,2,2.0,1);
/*!40000 ALTER TABLE `hlstats_Events_PlayerActions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_PlayerPlayerActions`
--

DROP TABLE IF EXISTS `hlstats_Events_PlayerPlayerActions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_PlayerPlayerActions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `victimId` int unsigned NOT NULL DEFAULT '0',
  `actionId` int unsigned NOT NULL DEFAULT '0',
  `bonus` int NOT NULL DEFAULT '0',
  `pos_x` mediumint DEFAULT NULL,
  `pos_y` mediumint DEFAULT NULL,
  `pos_z` mediumint DEFAULT NULL,
  `pos_victim_x` mediumint DEFAULT NULL,
  `pos_victim_y` mediumint DEFAULT NULL,
  `pos_victim_z` mediumint DEFAULT NULL,
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`),
  KEY `actionId` (`actionId`),
  KEY `victimId` (`victimId`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_PlayerPlayerActions`
--

LOCK TABLES `hlstats_Events_PlayerPlayerActions` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_PlayerPlayerActions` DISABLE KEYS */;
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (58,'2026-08-14 15:33:33',2,'dod_anzio',333,328,724,0,1361,-102,-353,526,795,-372,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (59,'2026-08-14 15:33:53',2,'dod_anzio',321,336,724,0,-11,-2575,-588,152,757,-390,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (60,'2026-08-14 15:35:23',2,'dod_anzio',329,331,724,0,-107,103,-435,-664,767,-401,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (61,'2026-08-14 15:35:33',2,'dod_anzio',329,334,724,0,-505,-1035,-429,10,808,-390,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (62,'2026-08-14 15:36:03',2,'dod_anzio',333,328,724,0,459,-337,-372,1175,-264,-354,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (63,'2026-08-14 15:36:13',2,'dod_anzio',333,334,724,0,900,-268,-345,1501,-193,-356,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (64,'2026-08-14 15:36:38',2,'dod_anzio',334,333,724,0,1458,1812,-270,1364,-105,-353,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (65,'2026-08-14 15:37:33',2,'dod_anzio',335,325,724,0,395,-311,-390,1172,-273,-336,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (66,'2026-08-14 15:38:08',2,'dod_anzio',328,323,724,0,262,885,-372,-606,856,-355,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (67,'2026-08-14 15:38:28',2,'dod_anzio',323,334,724,0,-699,-1009,-524,-694,951,-404,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (68,'2026-08-14 15:39:03',2,'dod_anzio',335,332,724,0,834,-56,-441,62,820,-390,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (69,'2026-08-14 15:39:43',2,'dod_anzio',323,334,724,0,-277,378,-422,-1218,851,-224,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (70,'2026-08-14 15:40:38',2,'dod_anzio',332,333,724,0,1781,3200,-486,27,848,-390,'1786721560-TEST');
INSERT INTO `hlstats_Events_PlayerPlayerActions` (`id`, `eventTime`, `serverId`, `map`, `playerId`, `victimId`, `actionId`, `bonus`, `pos_x`, `pos_y`, `pos_z`, `pos_victim_x`, `pos_victim_y`, `pos_victim_z`, `match_id`) VALUES (71,'2026-08-14 15:40:48',2,'dod_anzio',329,334,724,0,20,-120,-430,-907,826,-404,'1786721560-TEST');
/*!40000 ALTER TABLE `hlstats_Events_PlayerPlayerActions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Statsme`
--

DROP TABLE IF EXISTS `hlstats_Events_Statsme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Statsme` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `weapon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `shots` int unsigned NOT NULL DEFAULT '0',
  `hits` int unsigned NOT NULL DEFAULT '0',
  `headshots` int unsigned NOT NULL DEFAULT '0',
  `damage` int unsigned NOT NULL DEFAULT '0',
  `kills` int unsigned NOT NULL DEFAULT '0',
  `deaths` int unsigned NOT NULL DEFAULT '0',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `half` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`),
  KEY `weapon` (`weapon`)
) ENGINE=MyISAM AUTO_INCREMENT=320337 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Statsme`
--

LOCK TABLES `hlstats_Events_Statsme` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Statsme` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_Statsme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Statsme2`
--

DROP TABLE IF EXISTS `hlstats_Events_Statsme2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Statsme2` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `weapon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `head` int unsigned NOT NULL DEFAULT '0',
  `chest` int unsigned NOT NULL DEFAULT '0',
  `stomach` int unsigned NOT NULL DEFAULT '0',
  `leftarm` int unsigned NOT NULL DEFAULT '0',
  `rightarm` int unsigned NOT NULL DEFAULT '0',
  `leftleg` int unsigned NOT NULL DEFAULT '0',
  `rightleg` int unsigned NOT NULL DEFAULT '0',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`),
  KEY `weapon` (`weapon`)
) ENGINE=MyISAM AUTO_INCREMENT=319862 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Statsme2`
--

LOCK TABLES `hlstats_Events_Statsme2` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Statsme2` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_Statsme2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_StatsmeLatency`
--

DROP TABLE IF EXISTS `hlstats_Events_StatsmeLatency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_StatsmeLatency` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `ping` int unsigned NOT NULL DEFAULT '0',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM AUTO_INCREMENT=57740 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_StatsmeLatency`
--

LOCK TABLES `hlstats_Events_StatsmeLatency` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_StatsmeLatency` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_StatsmeLatency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_StatsmeTime`
--

DROP TABLE IF EXISTS `hlstats_Events_StatsmeTime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_StatsmeTime` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `time` time NOT NULL DEFAULT '00:00:00',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM AUTO_INCREMENT=57755 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_StatsmeTime`
--

LOCK TABLES `hlstats_Events_StatsmeTime` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_StatsmeTime` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_StatsmeTime` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Suicides`
--

DROP TABLE IF EXISTS `hlstats_Events_Suicides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Suicides` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `weapon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pos_x` mediumint DEFAULT NULL,
  `pos_y` mediumint DEFAULT NULL,
  `pos_z` mediumint DEFAULT NULL,
  `half` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`),
  KEY `idx_match_id_sui` (`match_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Suicides`
--

LOCK TABLES `hlstats_Events_Suicides` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Suicides` DISABLE KEYS */;
INSERT INTO `hlstats_Events_Suicides` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `playerId`, `weapon`, `pos_x`, `pos_y`, `pos_z`, `half`) VALUES (16,'2026-08-14 15:38:05',2,'dod_anzio','1786721560-TEST',335,'world',NULL,NULL,NULL,1);
INSERT INTO `hlstats_Events_Suicides` (`id`, `eventTime`, `serverId`, `map`, `match_id`, `playerId`, `weapon`, `pos_x`, `pos_y`, `pos_z`, `half`) VALUES (17,'2026-08-14 15:38:58',2,'dod_anzio','1786721560-TEST',328,'world',NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `hlstats_Events_Suicides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_TeamBonuses`
--

DROP TABLE IF EXISTS `hlstats_Events_TeamBonuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_TeamBonuses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `actionId` int unsigned NOT NULL DEFAULT '0',
  `bonus` int NOT NULL DEFAULT '0',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerId` (`playerId`),
  KEY `actionId` (`actionId`)
) ENGINE=MyISAM AUTO_INCREMENT=1647777 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_TeamBonuses`
--

LOCK TABLES `hlstats_Events_TeamBonuses` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_TeamBonuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_TeamBonuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Events_Teamkills`
--

DROP TABLE IF EXISTS `hlstats_Events_Teamkills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Events_Teamkills` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `eventTime` datetime DEFAULT NULL,
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `match_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `killerId` int unsigned NOT NULL DEFAULT '0',
  `victimId` int unsigned NOT NULL DEFAULT '0',
  `weapon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pos_x` mediumint DEFAULT NULL,
  `pos_y` mediumint DEFAULT NULL,
  `pos_z` mediumint DEFAULT NULL,
  `pos_victim_x` mediumint DEFAULT NULL,
  `pos_victim_y` mediumint DEFAULT NULL,
  `pos_victim_z` mediumint DEFAULT NULL,
  `half` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `killerId` (`killerId`),
  KEY `idx_match_id_tk` (`match_id`)
) ENGINE=MyISAM AUTO_INCREMENT=31970 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Events_Teamkills`
--

LOCK TABLES `hlstats_Events_Teamkills` WRITE;
/*!40000 ALTER TABLE `hlstats_Events_Teamkills` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Events_Teamkills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Games`
--

DROP TABLE IF EXISTS `hlstats_Games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Games` (
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hidden` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `realgame` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'hl2mp',
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Games`
--

LOCK TABLES `hlstats_Games` WRITE;
/*!40000 ALTER TABLE `hlstats_Games` DISABLE KEYS */;
INSERT INTO `hlstats_Games` (`code`, `name`, `hidden`, `realgame`) VALUES ('dod','Day of Defeat','0','dod');
/*!40000 ALTER TABLE `hlstats_Games` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Games_Defaults`
--

DROP TABLE IF EXISTS `hlstats_Games_Defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Games_Defaults` (
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parameter` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`code`,`parameter`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Games_Defaults`
--

LOCK TABLES `hlstats_Games_Defaults` WRITE;
/*!40000 ALTER TABLE `hlstats_Games_Defaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Games_Defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Games_Supported`
--

DROP TABLE IF EXISTS `hlstats_Games_Supported`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Games_Supported` (
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Games_Supported`
--

LOCK TABLES `hlstats_Games_Supported` WRITE;
/*!40000 ALTER TABLE `hlstats_Games_Supported` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Games_Supported` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Heatmap_Config`
--

DROP TABLE IF EXISTS `hlstats_Heatmap_Config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Heatmap_Config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `xoffset` float NOT NULL,
  `yoffset` float NOT NULL,
  `flipx` tinyint(1) NOT NULL DEFAULT '0',
  `flipy` tinyint(1) NOT NULL DEFAULT '1',
  `rotate` tinyint(1) NOT NULL DEFAULT '0',
  `days` tinyint NOT NULL DEFAULT '30',
  `brush` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'small',
  `scale` float NOT NULL,
  `font` tinyint NOT NULL DEFAULT '10',
  `thumbw` float NOT NULL DEFAULT '0.170312',
  `thumbh` float NOT NULL DEFAULT '0.170312',
  `cropx1` int NOT NULL DEFAULT '0',
  `cropy1` int NOT NULL DEFAULT '0',
  `cropx2` int NOT NULL DEFAULT '0',
  `cropy2` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gamemap` (`map`,`game`)
) ENGINE=MyISAM AUTO_INCREMENT=443 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Heatmap_Config`
--

LOCK TABLES `hlstats_Heatmap_Config` WRITE;
/*!40000 ALTER TABLE `hlstats_Heatmap_Config` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Heatmap_Config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_HostGroups`
--

DROP TABLE IF EXISTS `hlstats_HostGroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_HostGroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pattern` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_HostGroups`
--

LOCK TABLES `hlstats_HostGroups` WRITE;
/*!40000 ALTER TABLE `hlstats_HostGroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_HostGroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Livestats`
--

DROP TABLE IF EXISTS `hlstats_Livestats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Livestats` (
  `player_id` int NOT NULL DEFAULT '0',
  `server_id` int NOT NULL DEFAULT '0',
  `cli_address` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cli_city` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cli_country` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cli_flag` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cli_state` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cli_lat` float(7,4) DEFAULT NULL,
  `cli_lng` float(7,4) DEFAULT NULL,
  `steam_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `team` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `kills` int NOT NULL DEFAULT '0',
  `deaths` int NOT NULL DEFAULT '0',
  `suicides` int NOT NULL DEFAULT '0',
  `headshots` int NOT NULL DEFAULT '0',
  `shots` int NOT NULL DEFAULT '0',
  `hits` int NOT NULL DEFAULT '0',
  `is_dead` tinyint(1) NOT NULL DEFAULT '0',
  `has_bomb` int NOT NULL DEFAULT '0',
  `ping` int NOT NULL DEFAULT '0',
  `connected` int NOT NULL DEFAULT '0',
  `skill_change` int NOT NULL DEFAULT '0',
  `skill` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`player_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Livestats`
--

LOCK TABLES `hlstats_Livestats` WRITE;
/*!40000 ALTER TABLE `hlstats_Livestats` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Livestats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Maps_Counts`
--

DROP TABLE IF EXISTS `hlstats_Maps_Counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Maps_Counts` (
  `rowId` int NOT NULL AUTO_INCREMENT,
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kills` int NOT NULL,
  `headshots` int NOT NULL,
  PRIMARY KEY (`game`,`map`),
  KEY `rowId` (`rowId`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Maps_Counts`
--

LOCK TABLES `hlstats_Maps_Counts` WRITE;
/*!40000 ALTER TABLE `hlstats_Maps_Counts` DISABLE KEYS */;
INSERT INTO `hlstats_Maps_Counts` (`rowId`, `game`, `map`, `kills`, `headshots`) VALUES (102,'dod','',13,0);
INSERT INTO `hlstats_Maps_Counts` (`rowId`, `game`, `map`, `kills`, `headshots`) VALUES (103,'dod','dod_anzio',106,0);
/*!40000 ALTER TABLE `hlstats_Maps_Counts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Mods_Defaults`
--

DROP TABLE IF EXISTS `hlstats_Mods_Defaults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Mods_Defaults` (
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `parameter` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`code`,`parameter`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Mods_Defaults`
--

LOCK TABLES `hlstats_Mods_Defaults` WRITE;
/*!40000 ALTER TABLE `hlstats_Mods_Defaults` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Mods_Defaults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Mods_Supported`
--

DROP TABLE IF EXISTS `hlstats_Mods_Supported`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Mods_Supported` (
  `code` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Mods_Supported`
--

LOCK TABLES `hlstats_Mods_Supported` WRITE;
/*!40000 ALTER TABLE `hlstats_Mods_Supported` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Mods_Supported` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Options`
--

DROP TABLE IF EXISTS `hlstats_Options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Options` (
  `keyname` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `opttype` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`keyname`),
  KEY `opttype` (`opttype`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Options`
--

LOCK TABLES `hlstats_Options` WRITE;
/*!40000 ALTER TABLE `hlstats_Options` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Options_Choices`
--

DROP TABLE IF EXISTS `hlstats_Options_Choices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Options_Choices` (
  `keyname` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`keyname`,`value`),
  KEY `keyname` (`keyname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Options_Choices`
--

LOCK TABLES `hlstats_Options_Choices` WRITE;
/*!40000 ALTER TABLE `hlstats_Options_Choices` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Options_Choices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_PlayerNames`
--

DROP TABLE IF EXISTS `hlstats_PlayerNames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_PlayerNames` (
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lastuse` datetime DEFAULT NULL,
  `connection_time` int unsigned NOT NULL DEFAULT '0',
  `numuses` int unsigned NOT NULL DEFAULT '0',
  `kills` int unsigned NOT NULL DEFAULT '0',
  `deaths` int unsigned NOT NULL DEFAULT '0',
  `suicides` int unsigned NOT NULL DEFAULT '0',
  `headshots` int unsigned NOT NULL DEFAULT '0',
  `shots` int unsigned NOT NULL DEFAULT '0',
  `hits` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`playerId`,`name`),
  KEY `name16` (`name`(16))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_PlayerNames`
--

LOCK TABLES `hlstats_PlayerNames` WRITE;
/*!40000 ALTER TABLE `hlstats_PlayerNames` DISABLE KEYS */;
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (321,'Jill','2026-08-14 15:41:45',0,1,5,7,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (322,'Bowser','2026-08-14 15:41:45',0,1,5,5,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (323,'Sonic','2026-08-14 15:41:45',0,1,4,8,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (324,'Seymour','2026-08-14 15:41:45',0,1,8,5,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (325,'Ganon','2026-08-14 15:41:45',0,1,7,8,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (326,'Tidus','2026-08-14 15:41:45',0,1,10,8,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (327,'Banjo','2026-08-14 15:41:45',0,1,7,8,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (328,'Robotnik','2026-08-14 15:41:45',0,1,10,9,1,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (329,'Claire','2026-08-14 15:41:45',0,1,8,7,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (330,'Redfield','2026-08-14 15:41:45',0,1,6,6,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (331,'Master','2026-08-14 15:41:45',0,1,7,6,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (332,'Pyramid','2026-08-14 15:41:45',0,1,3,10,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (333,'Denton','2026-08-14 15:41:45',0,1,14,7,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (334,'Gruntilda','2026-08-14 15:41:45',0,1,9,9,0,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (335,'Snake','2026-08-14 15:41:45',0,1,7,7,1,0,0,0);
INSERT INTO `hlstats_PlayerNames` (`playerId`, `name`, `lastuse`, `connection_time`, `numuses`, `kills`, `deaths`, `suicides`, `headshots`, `shots`, `hits`) VALUES (336,'Arthas','2026-08-14 15:41:45',0,1,9,9,0,0,0,0);
/*!40000 ALTER TABLE `hlstats_PlayerNames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_PlayerUniqueIds`
--

DROP TABLE IF EXISTS `hlstats_PlayerUniqueIds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_PlayerUniqueIds` (
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `uniqueId` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `merge` int unsigned DEFAULT NULL,
  PRIMARY KEY (`uniqueId`,`game`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_PlayerUniqueIds`
--

LOCK TABLES `hlstats_PlayerUniqueIds` WRITE;
/*!40000 ALTER TABLE `hlstats_PlayerUniqueIds` DISABLE KEYS */;
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (321,'BOT:1cbd58d14b0e20440b2866a3e3f46fff','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (322,'BOT:d8a6341f9a419ccb35a8dd8042e11b67','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (323,'BOT:ccef2877dc571df16c4cf39a41b39448','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (324,'BOT:8fc5046ede548de86879b3e3234dc9ca','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (325,'BOT:fbe07e835bf29e58da32984083442b9b','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (326,'BOT:fe8dbed646ace6a402574a62f3acad4d','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (327,'BOT:f8fe9b9a0a470604303e7712f3c6642e','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (328,'BOT:b032c6705a72410045965a9ec3e1b653','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (329,'BOT:29211fdf221b8310663d4593517ff8f4','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (330,'BOT:f029d4273369fe617404d421bf9406bc','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (331,'BOT:0fbef0c5b11a7e09768df9dfa230f9aa','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (332,'BOT:1cf9e8c0b1b28c53a292ea7fd5a539b6','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (333,'BOT:59acc26ac0e0ce6e9d526c24b264c811','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (334,'BOT:dd14cc52d051d359214b6fd00d3e873d','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (335,'BOT:ae2595495e5823ce81c35ceba77a3ab1','dod',NULL);
INSERT INTO `hlstats_PlayerUniqueIds` (`playerId`, `uniqueId`, `game`, `merge`) VALUES (336,'BOT:ec1ad58936b0fb5d75e74ddb70e911c6','dod',NULL);
/*!40000 ALTER TABLE `hlstats_PlayerUniqueIds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Players`
--

DROP TABLE IF EXISTS `hlstats_Players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Players` (
  `playerId` int unsigned NOT NULL AUTO_INCREMENT,
  `last_event` int NOT NULL DEFAULT '0',
  `connection_time` int unsigned NOT NULL DEFAULT '0',
  `lastName` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lastAddress` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `city` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `flag` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lat` float(7,4) DEFAULT NULL,
  `lng` float(7,4) DEFAULT NULL,
  `clan` int unsigned NOT NULL DEFAULT '0',
  `kills` int unsigned NOT NULL DEFAULT '0',
  `deaths` int unsigned NOT NULL DEFAULT '0',
  `suicides` int unsigned NOT NULL DEFAULT '0',
  `skill` int unsigned NOT NULL DEFAULT '1000',
  `shots` int unsigned NOT NULL DEFAULT '0',
  `hits` int unsigned NOT NULL DEFAULT '0',
  `teamkills` int unsigned NOT NULL DEFAULT '0',
  `fullName` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `homepage` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icq` int unsigned DEFAULT NULL,
  `mmrank` tinyint DEFAULT NULL,
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hideranking` int unsigned NOT NULL DEFAULT '0',
  `headshots` int unsigned NOT NULL DEFAULT '0',
  `last_skill_change` int NOT NULL DEFAULT '0',
  `displayEvents` int unsigned NOT NULL DEFAULT '1',
  `kill_streak` int NOT NULL DEFAULT '0',
  `death_streak` int NOT NULL DEFAULT '0',
  `blockavatar` int unsigned NOT NULL DEFAULT '0',
  `activity` int NOT NULL DEFAULT '100',
  `createdate` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`playerId`),
  KEY `playerclan` (`clan`,`playerId`),
  KEY `skill` (`skill`),
  KEY `game` (`game`),
  KEY `kills` (`kills`),
  KEY `hideranking` (`hideranking`)
) ENGINE=MyISAM AUTO_INCREMENT=337 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Players`
--

LOCK TABLES `hlstats_Players` WRITE;
/*!40000 ALTER TABLE `hlstats_Players` DISABLE KEYS */;
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (321,1786725920,0,'Jill','','','','','',NULL,NULL,0,5,7,0,996,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,-4,1,3,2,0,100,1786725893);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (322,1786725920,0,'Bowser','','','','','',NULL,NULL,0,5,5,0,1000,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,0,1,4,2,0,100,1786725893);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (323,1786725920,0,'Sonic','','','','','',NULL,NULL,0,4,8,0,992,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,-8,1,3,5,0,100,1786725893);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (324,1786725920,0,'Seymour','','','','','',NULL,NULL,0,8,5,0,1006,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,6,1,7,2,0,100,1786725893);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (325,1786725920,0,'Ganon','','','','','',NULL,NULL,0,7,8,0,998,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,-2,1,3,3,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (326,1786725920,0,'Tidus','','','','','',NULL,NULL,0,10,8,0,1004,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,4,1,3,2,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (327,1786725920,0,'Banjo','','','','','',NULL,NULL,0,7,8,0,998,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,-2,1,4,3,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (328,1786725920,0,'Robotnik','','','','','',NULL,NULL,0,10,9,1,1002,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,2,1,3,3,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (329,1786725920,0,'Claire','','','','','',NULL,NULL,0,8,7,0,1002,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,2,1,3,2,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (330,1786725920,0,'Redfield','','','','','',NULL,NULL,0,6,6,0,1000,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,0,1,2,2,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (331,1786725920,0,'Master','','','','','',NULL,NULL,0,7,6,0,1002,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,2,1,3,3,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (332,1786725920,0,'Pyramid','','','','','',NULL,NULL,0,3,10,0,986,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,-14,1,2,7,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (333,1786725920,0,'Denton','','','','','',NULL,NULL,0,14,7,0,1014,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,14,1,6,3,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (334,1786725920,0,'Gruntilda','','','','','',NULL,NULL,0,9,9,0,1000,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,0,1,2,2,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (335,1786725920,0,'Snake','','','','','',NULL,NULL,0,7,7,1,1000,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,0,1,3,3,0,100,1786725894);
INSERT INTO `hlstats_Players` (`playerId`, `last_event`, `connection_time`, `lastName`, `lastAddress`, `city`, `state`, `country`, `flag`, `lat`, `lng`, `clan`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `teamkills`, `fullName`, `email`, `homepage`, `icq`, `mmrank`, `game`, `hideranking`, `headshots`, `last_skill_change`, `displayEvents`, `kill_streak`, `death_streak`, `blockavatar`, `activity`, `createdate`) VALUES (336,1786725920,0,'Arthas','','','','','',NULL,NULL,0,9,9,0,1000,0,0,0,NULL,NULL,NULL,NULL,NULL,'dod',0,0,0,1,3,3,0,100,1786725894);
/*!40000 ALTER TABLE `hlstats_Players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Players_Awards`
--

DROP TABLE IF EXISTS `hlstats_Players_Awards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Players_Awards` (
  `awardTime` date NOT NULL,
  `awardId` int unsigned NOT NULL DEFAULT '0',
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `count` int unsigned NOT NULL DEFAULT '0',
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`awardTime`,`awardId`,`playerId`,`game`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Players_Awards`
--

LOCK TABLES `hlstats_Players_Awards` WRITE;
/*!40000 ALTER TABLE `hlstats_Players_Awards` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Players_Awards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Players_History`
--

DROP TABLE IF EXISTS `hlstats_Players_History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Players_History` (
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `eventTime` date DEFAULT NULL,
  `connection_time` int unsigned NOT NULL DEFAULT '0',
  `kills` int unsigned NOT NULL DEFAULT '0',
  `deaths` int unsigned NOT NULL DEFAULT '0',
  `suicides` int unsigned NOT NULL DEFAULT '0',
  `skill` int unsigned NOT NULL DEFAULT '1000',
  `shots` int unsigned NOT NULL DEFAULT '0',
  `hits` int unsigned NOT NULL DEFAULT '0',
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `headshots` int unsigned NOT NULL DEFAULT '0',
  `teamkills` int unsigned NOT NULL DEFAULT '0',
  `kill_streak` int NOT NULL DEFAULT '0',
  `death_streak` int NOT NULL DEFAULT '0',
  `skill_change` int NOT NULL DEFAULT '0',
  UNIQUE KEY `eventTime` (`eventTime`,`playerId`,`game`),
  KEY `playerId` (`playerId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Players_History`
--

LOCK TABLES `hlstats_Players_History` WRITE;
/*!40000 ALTER TABLE `hlstats_Players_History` DISABLE KEYS */;
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (321,'2026-08-14',0,5,7,0,996,0,0,'dod',0,0,3,2,-4);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (322,'2026-08-14',0,5,5,0,1000,0,0,'dod',0,0,4,2,0);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (323,'2026-08-14',0,4,8,0,992,0,0,'dod',0,0,3,5,-8);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (324,'2026-08-14',0,8,5,0,1006,0,0,'dod',0,0,7,2,6);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (325,'2026-08-14',0,7,8,0,998,0,0,'dod',0,0,3,3,-2);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (326,'2026-08-14',0,10,8,0,1004,0,0,'dod',0,0,3,2,4);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (327,'2026-08-14',0,7,8,0,998,0,0,'dod',0,0,4,3,-2);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (328,'2026-08-14',0,10,9,1,1002,0,0,'dod',0,0,3,3,2);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (329,'2026-08-14',0,8,7,0,1002,0,0,'dod',0,0,3,2,2);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (330,'2026-08-14',0,6,6,0,1000,0,0,'dod',0,0,2,2,0);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (331,'2026-08-14',0,7,6,0,1002,0,0,'dod',0,0,3,3,2);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (332,'2026-08-14',0,3,10,0,986,0,0,'dod',0,0,2,7,-14);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (333,'2026-08-14',0,14,7,0,1014,0,0,'dod',0,0,6,3,14);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (334,'2026-08-14',0,9,9,0,1000,0,0,'dod',0,0,2,2,0);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (335,'2026-08-14',0,7,7,1,1000,0,0,'dod',0,0,3,3,0);
INSERT INTO `hlstats_Players_History` (`playerId`, `eventTime`, `connection_time`, `kills`, `deaths`, `suicides`, `skill`, `shots`, `hits`, `game`, `headshots`, `teamkills`, `kill_streak`, `death_streak`, `skill_change`) VALUES (336,'2026-08-14',0,9,9,0,1000,0,0,'dod',0,0,3,3,0);
/*!40000 ALTER TABLE `hlstats_Players_History` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Players_Ribbons`
--

DROP TABLE IF EXISTS `hlstats_Players_Ribbons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Players_Ribbons` (
  `playerId` int unsigned NOT NULL DEFAULT '0',
  `ribbonId` int unsigned NOT NULL DEFAULT '0',
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Players_Ribbons`
--

LOCK TABLES `hlstats_Players_Ribbons` WRITE;
/*!40000 ALTER TABLE `hlstats_Players_Ribbons` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Players_Ribbons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Ranks`
--

DROP TABLE IF EXISTS `hlstats_Ranks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Ranks` (
  `rankId` int unsigned NOT NULL AUTO_INCREMENT,
  `image` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `minKills` int unsigned NOT NULL DEFAULT '0',
  `maxKills` int NOT NULL DEFAULT '0',
  `rankName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`rankId`),
  UNIQUE KEY `rankgame` (`image`,`game`),
  KEY `game` (`game`(8))
) ENGINE=MyISAM AUTO_INCREMENT=1181 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Ranks`
--

LOCK TABLES `hlstats_Ranks` WRITE;
/*!40000 ALTER TABLE `hlstats_Ranks` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Ranks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Ribbons`
--

DROP TABLE IF EXISTS `hlstats_Ribbons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Ribbons` (
  `ribbonId` int unsigned NOT NULL AUTO_INCREMENT,
  `awardCode` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `awardCount` int NOT NULL DEFAULT '0',
  `special` tinyint NOT NULL DEFAULT '0',
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ribbonName` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`ribbonId`),
  UNIQUE KEY `award` (`awardCode`,`awardCount`,`game`,`special`)
) ENGINE=MyISAM AUTO_INCREMENT=1798 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Ribbons`
--

LOCK TABLES `hlstats_Ribbons` WRITE;
/*!40000 ALTER TABLE `hlstats_Ribbons` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Ribbons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Roles`
--

DROP TABLE IF EXISTS `hlstats_Roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Roles` (
  `roleId` int unsigned NOT NULL AUTO_INCREMENT,
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'valve',
  `code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hidden` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `picked` int unsigned NOT NULL DEFAULT '0',
  `kills` int unsigned NOT NULL DEFAULT '0',
  `deaths` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`roleId`),
  UNIQUE KEY `gamecode` (`game`,`code`)
) ENGINE=MyISAM AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Roles`
--

LOCK TABLES `hlstats_Roles` WRITE;
/*!40000 ALTER TABLE `hlstats_Roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Servers`
--

DROP TABLE IF EXISTS `hlstats_Servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Servers` (
  `serverId` int unsigned NOT NULL AUTO_INCREMENT,
  `address` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `port` int unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sortorder` tinyint NOT NULL DEFAULT '0',
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'valve',
  `publicaddress` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `statusurl` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kills` int NOT NULL DEFAULT '0',
  `players` int NOT NULL DEFAULT '0',
  `rounds` int NOT NULL DEFAULT '0',
  `suicides` int NOT NULL DEFAULT '0',
  `headshots` int NOT NULL DEFAULT '0',
  `bombs_planted` int NOT NULL DEFAULT '0',
  `bombs_defused` int NOT NULL DEFAULT '0',
  `ct_wins` int NOT NULL DEFAULT '0',
  `ts_wins` int NOT NULL DEFAULT '0',
  `act_players` int NOT NULL DEFAULT '0',
  `max_players` int NOT NULL DEFAULT '0',
  `act_map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `map_rounds` int NOT NULL DEFAULT '0',
  `map_ct_wins` int NOT NULL DEFAULT '0',
  `map_ts_wins` int NOT NULL DEFAULT '0',
  `map_started` int NOT NULL DEFAULT '0',
  `map_changes` int NOT NULL DEFAULT '0',
  `ct_shots` int NOT NULL DEFAULT '0',
  `ct_hits` int NOT NULL DEFAULT '0',
  `ts_shots` int NOT NULL DEFAULT '0',
  `ts_hits` int NOT NULL DEFAULT '0',
  `map_ct_shots` int NOT NULL DEFAULT '0',
  `map_ct_hits` int NOT NULL DEFAULT '0',
  `map_ts_shots` int NOT NULL DEFAULT '0',
  `map_ts_hits` int NOT NULL DEFAULT '0',
  `lat` float(7,4) DEFAULT NULL,
  `lng` float(7,4) DEFAULT NULL,
  `city` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `country` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_event` int unsigned NOT NULL DEFAULT '0',
  `rcon_password` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`serverId`),
  UNIQUE KEY `addressport` (`address`,`port`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Servers`
--

LOCK TABLES `hlstats_Servers` WRITE;
/*!40000 ALTER TABLE `hlstats_Servers` DISABLE KEYS */;
INSERT INTO `hlstats_Servers` (`serverId`, `address`, `port`, `name`, `sortorder`, `game`, `publicaddress`, `statusurl`, `kills`, `players`, `rounds`, `suicides`, `headshots`, `bombs_planted`, `bombs_defused`, `ct_wins`, `ts_wins`, `act_players`, `max_players`, `act_map`, `map_rounds`, `map_ct_wins`, `map_ts_wins`, `map_started`, `map_changes`, `ct_shots`, `ct_hits`, `ts_shots`, `ts_hits`, `map_ct_shots`, `map_ct_hits`, `map_ts_shots`, `map_ts_hits`, `lat`, `lng`, `city`, `country`, `last_event`, `rcon_password`) VALUES (2,'127.0.0.1',27015,'KTP Lane B ephemeral',0,'dod','',NULL,119,16,0,2,0,0,0,0,0,16,0,'dod_anzio',0,0,0,1786725893,0,0,0,0,0,0,0,0,0,NULL,NULL,'','',1786722105,'');
/*!40000 ALTER TABLE `hlstats_Servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Servers_Config`
--

DROP TABLE IF EXISTS `hlstats_Servers_Config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Servers_Config` (
  `serverId` int unsigned NOT NULL DEFAULT '0',
  `parameter` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `serverConfigId` int unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`serverId`,`parameter`),
  KEY `serverConfigId` (`serverConfigId`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Servers_Config`
--

LOCK TABLES `hlstats_Servers_Config` WRITE;
/*!40000 ALTER TABLE `hlstats_Servers_Config` DISABLE KEYS */;
INSERT INTO `hlstats_Servers_Config` (`serverId`, `parameter`, `value`, `serverConfigId`) VALUES (2,'IgnoreBots','0',6);
INSERT INTO `hlstats_Servers_Config` (`serverId`, `parameter`, `value`, `serverConfigId`) VALUES (2,'MinPlayers','2',7);
INSERT INTO `hlstats_Servers_Config` (`serverId`, `parameter`, `value`, `serverConfigId`) VALUES (2,'BonusRoundIgnore','0',8);
INSERT INTO `hlstats_Servers_Config` (`serverId`, `parameter`, `value`, `serverConfigId`) VALUES (2,'BroadCastEvents','0',9);
INSERT INTO `hlstats_Servers_Config` (`serverId`, `parameter`, `value`, `serverConfigId`) VALUES (2,'PlayerEvents','0',10);
/*!40000 ALTER TABLE `hlstats_Servers_Config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Servers_Config_Default`
--

DROP TABLE IF EXISTS `hlstats_Servers_Config_Default`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Servers_Config_Default` (
  `parameter` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`parameter`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Servers_Config_Default`
--

LOCK TABLES `hlstats_Servers_Config_Default` WRITE;
/*!40000 ALTER TABLE `hlstats_Servers_Config_Default` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Servers_Config_Default` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Teams`
--

DROP TABLE IF EXISTS `hlstats_Teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Teams` (
  `teamId` int unsigned NOT NULL AUTO_INCREMENT,
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'valve',
  `code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hidden` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `playerlist_bgcolor` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `playerlist_color` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `playerlist_index` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`teamId`),
  UNIQUE KEY `gamecode` (`game`,`code`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Teams`
--

LOCK TABLES `hlstats_Teams` WRITE;
/*!40000 ALTER TABLE `hlstats_Teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Trend`
--

DROP TABLE IF EXISTS `hlstats_Trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Trend` (
  `timestamp` int NOT NULL DEFAULT '0',
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `players` int NOT NULL DEFAULT '0',
  `kills` int NOT NULL DEFAULT '0',
  `headshots` int NOT NULL DEFAULT '0',
  `servers` int NOT NULL DEFAULT '0',
  `act_slots` int NOT NULL DEFAULT '0',
  `max_slots` int NOT NULL DEFAULT '0',
  KEY `game` (`game`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Trend`
--

LOCK TABLES `hlstats_Trend` WRITE;
/*!40000 ALTER TABLE `hlstats_Trend` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Trend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_Weapons`
--

DROP TABLE IF EXISTS `hlstats_Weapons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_Weapons` (
  `weaponId` int unsigned NOT NULL AUTO_INCREMENT,
  `game` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'valve',
  `code` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modifier` float(10,2) NOT NULL DEFAULT '1.00',
  `kills` int unsigned NOT NULL DEFAULT '0',
  `headshots` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`weaponId`),
  UNIQUE KEY `gamecode` (`game`,`code`),
  KEY `code` (`code`),
  KEY `modifier` (`modifier`)
) ENGINE=MyISAM AUTO_INCREMENT=939 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_Weapons`
--

LOCK TABLES `hlstats_Weapons` WRITE;
/*!40000 ALTER TABLE `hlstats_Weapons` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_Weapons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hlstats_server_load`
--

DROP TABLE IF EXISTS `hlstats_server_load`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hlstats_server_load` (
  `server_id` int NOT NULL DEFAULT '0',
  `timestamp` int NOT NULL DEFAULT '0',
  `act_players` tinyint NOT NULL DEFAULT '0',
  `min_players` tinyint NOT NULL DEFAULT '0',
  `max_players` tinyint NOT NULL DEFAULT '0',
  `map` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uptime` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `fps` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  KEY `server_id` (`server_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hlstats_server_load`
--

LOCK TABLES `hlstats_server_load` WRITE;
/*!40000 ALTER TABLE `hlstats_server_load` DISABLE KEYS */;
/*!40000 ALTER TABLE `hlstats_server_load` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_damage_events`
--

DROP TABLE IF EXISTS `ktp_damage_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_damage_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `server_id` int unsigned NOT NULL,
  `match_id` varchar(64) DEFAULT NULL,
  `half` tinyint NOT NULL DEFAULT '0' COMMENT '0=no match context, 1/2=half, 3+=OT',
  `attacker_id` int NOT NULL,
  `victim_id` int NOT NULL,
  `weapon` varchar(32) NOT NULL,
  `damage` smallint NOT NULL COMMENT 'raw engine value, not clamped to HP',
  `damage_capped` tinyint unsigned NOT NULL COMMENT 'MIN(damage, 100) -- read this one for stats',
  `hitplace` tinyint NOT NULL,
  `game_time` float NOT NULL COMMENT 'get_gametime() at the hit, seconds since map start',
  `event_time` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_server` (`server_id`),
  KEY `idx_match` (`match_id`),
  KEY `idx_attacker` (`attacker_id`),
  KEY `idx_victim` (`victim_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Per-hit damage ledger -- every client_damage hit, capped and raw';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_damage_events`
--

LOCK TABLES `ktp_damage_events` WRITE;
/*!40000 ALTER TABLE `ktp_damage_events` DISABLE KEYS */;
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (878,2,'1786721560-TEST',1,332,335,'grenade2',15,15,0,105.21,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (879,2,'1786721560-TEST',1,332,332,'mortar',12,12,0,106.35,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (880,2,'1786721560-TEST',1,334,327,'kar',120,100,7,107.41,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (881,2,'1786721560-TEST',1,325,325,'mortar',12,12,0,107.49,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (882,2,'1786721560-TEST',1,323,336,'30cal',63,63,5,115.56,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (883,2,'1786721560-TEST',1,323,324,'30cal',63,63,7,116.95,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (884,2,'1786721560-TEST',1,323,324,'30cal',63,63,7,117.41,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (885,2,'1786721560-TEST',1,323,336,'30cal',63,63,5,118.15,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (886,2,'1786721560-TEST',1,336,323,'grenade2',30,30,0,120.37,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (887,2,'1786721560-TEST',1,335,322,'30cal',85,85,3,122.87,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (888,2,'1786721560-TEST',1,335,322,'30cal',85,85,3,123.08,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (889,2,'1786721560-TEST',1,330,334,'30cal',63,63,4,123.44,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (890,2,'1786721560-TEST',1,330,334,'30cal',46,46,4,123.44,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (891,2,'1786721560-TEST',1,322,335,'grenade2',44,44,0,128.28,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (892,2,'1786721560-TEST',1,329,325,'greasegun',30,30,5,130.47,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (893,2,'1786721560-TEST',1,329,325,'greasegun',15,15,5,130.47,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (894,2,'1786721560-TEST',1,329,325,'greasegun',30,30,5,130.67,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (895,2,'1786721560-TEST',1,329,325,'greasegun',9,9,5,130.68,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (896,2,'1786721560-TEST',1,329,325,'greasegun',30,30,5,130.88,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (897,2,'1786721560-TEST',1,333,328,'garand',90,90,6,134.76,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (898,2,'1786721560-TEST',1,333,331,'garand',90,90,4,137.65,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (899,2,'1786721560-TEST',1,333,331,'garand',68,68,4,137.65,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (900,2,'1786721560-TEST',1,329,334,'greasegun',30,30,4,146.22,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (901,2,'1786721560-TEST',1,329,334,'greasegun',30,30,4,146.43,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (902,2,'1786721560-TEST',1,333,333,'mortar',112,100,0,147.17,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (903,2,'1786721560-TEST',1,329,334,'greasegun',30,30,5,149.1,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (904,2,'1786721560-TEST',1,329,322,'greasegun',26,26,5,149.11,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (905,2,'1786721560-TEST',1,329,334,'greasegun',30,30,5,149.31,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (906,2,'1786721560-TEST',1,333,332,'grenade',90,90,0,149.94,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (907,2,'1786721560-TEST',1,329,322,'greasegun',30,30,7,151.24,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (908,2,'1786721560-TEST',1,329,322,'greasegun',30,30,7,151.44,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (909,2,'1786721560-TEST',1,328,330,'luger',100,100,1,154.77,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (910,2,'1786721560-TEST',1,327,328,'m1carbine',100,100,1,154.98,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (911,2,'1786721560-TEST',1,322,329,'mp40',40,40,2,157.23,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (912,2,'1786721560-TEST',1,327,336,'m1carbine',30,30,7,157.75,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (913,2,'1786721560-TEST',1,336,327,'kar',120,100,6,157.81,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (914,2,'1786721560-TEST',1,321,336,'greasegun',30,30,6,159.83,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (915,2,'1786721560-TEST',1,321,336,'greasegun',30,30,6,160.03,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (916,2,'1786721560-TEST',1,336,321,'luger',30,30,5,160.23,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (917,2,'1786721560-TEST',1,336,321,'luger',8,8,5,160.23,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (918,2,'1786721560-TEST',1,336,321,'luger',30,30,5,160.45,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (919,2,'1786721560-TEST',1,336,321,'luger',39,39,5,160.45,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (920,2,'1786721560-TEST',1,324,324,'mortar',83,83,0,173.18,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (921,2,'1786721560-TEST',1,326,336,'colt',30,30,4,174.38,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (922,2,'1786721560-TEST',1,336,326,'grenade2',90,90,0,174.73,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (923,2,'1786721560-TEST',1,334,335,'kar',120,100,4,186.91,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (924,2,'1786721560-TEST',1,325,329,'mg42',63,63,6,187.87,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (925,2,'1786721560-TEST',1,325,329,'mg42',63,63,7,188.53,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (926,2,'1786721560-TEST',1,322,327,'mp40',40,40,2,189.94,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (927,2,'1786721560-TEST',1,322,327,'mp40',40,40,2,190.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (928,2,'1786721560-TEST',1,322,327,'mp40',40,40,2,190.21,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (929,2,'1786721560-TEST',1,325,323,'mg42',63,63,6,192.7,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (930,2,'1786721560-TEST',1,325,323,'mg42',63,63,5,192.93,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (931,2,'1786721560-TEST',1,325,330,'mg42',63,63,6,200.37,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (932,2,'1786721560-TEST',1,325,330,'mg42',85,85,2,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (933,2,'1786721560-TEST',1,333,334,'m1carbine',40,40,2,203.91,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (934,2,'1786721560-TEST',1,333,334,'m1carbine',30,30,5,204.17,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (935,2,'1786721560-TEST',1,333,334,'m1carbine',31,31,5,204.17,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (936,2,'1786721560-TEST',1,334,333,'grenade2',15,15,0,209.27,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (937,2,'1786721560-TEST',1,324,324,'mortar',70,70,0,223.66,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (938,2,'1786721560-TEST',1,325,325,'mortar',87,87,0,223.66,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (939,2,'1786721560-TEST',1,328,335,'mp44',37,37,7,227.3,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (940,2,'1786721560-TEST',1,328,335,'mp44',37,37,7,227.43,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (941,2,'1786721560-TEST',1,328,335,'mp44',37,37,7,227.57,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (942,2,'1786721560-TEST',1,329,325,'greasegun',30,30,6,227.85,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (943,2,'1786721560-TEST',1,328,326,'mp44',37,37,5,229.02,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (944,2,'1786721560-TEST',1,328,321,'mp44',50,50,3,230.26,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (945,2,'1786721560-TEST',1,329,332,'greasegun',30,30,6,230.27,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (946,2,'1786721560-TEST',1,328,321,'mp44',50,50,3,230.4,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (947,2,'1786721560-TEST',1,329,332,'greasegun',30,30,4,230.48,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (948,2,'1786721560-TEST',1,329,332,'greasegun',16,16,4,230.48,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (949,2,'1786721560-TEST',1,329,332,'greasegun',30,30,4,230.68,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (950,2,'1786721560-TEST',1,328,326,'mp44',37,37,5,231.32,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (951,2,'1786721560-TEST',1,328,326,'mp44',12,12,5,231.32,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (952,2,'1786721560-TEST',1,328,326,'mp44',37,37,5,231.45,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (953,2,'1786721560-TEST',1,322,329,'mp40',30,30,7,238.47,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (954,2,'1786721560-TEST',1,322,329,'mp40',30,30,7,238.61,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (955,2,'1786721560-TEST',1,322,329,'mp40',30,30,7,238.74,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (956,2,'1786721560-TEST',1,322,329,'mp40',30,30,7,238.88,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (957,2,'1786721560-TEST',1,327,328,'bar',63,63,4,240.13,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (958,2,'1786721560-TEST',1,329,322,'grenade',66,66,0,243.98,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (959,2,'1786721560-TEST',1,327,328,'grenade',74,74,0,244.21,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (960,2,'1786721560-TEST',1,323,323,'mortar',4,4,0,256.18,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (961,2,'1786721560-TEST',1,333,336,'m1carbine',40,40,2,259.54,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (962,2,'1786721560-TEST',1,333,336,'m1carbine',30,30,4,259.83,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (963,2,'1786721560-TEST',1,333,336,'m1carbine',13,13,4,259.83,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (964,2,'1786721560-TEST',1,333,336,'m1carbine',30,30,4,260.09,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (965,2,'1786721560-TEST',1,329,331,'m1carbine',30,30,4,261.31,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (966,2,'1786721560-TEST',1,325,327,'mg42',85,85,3,261.49,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (967,2,'1786721560-TEST',1,329,331,'m1carbine',30,30,6,261.59,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (968,2,'1786721560-TEST',1,325,327,'mg42',85,85,3,261.74,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (969,2,'1786721560-TEST',1,329,331,'m1carbine',30,30,6,261.87,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (970,2,'1786721560-TEST',1,333,331,'grenade',26,26,0,262.42,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (971,2,'1786721560-TEST',1,329,334,'m1carbine',40,40,3,268.57,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (972,2,'1786721560-TEST',1,329,334,'m1carbine',40,40,3,268.82,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (973,2,'1786721560-TEST',1,334,329,'scopedkar',120,100,4,268.83,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (974,2,'1786721560-TEST',1,333,332,'m1carbine',30,30,7,272.32,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (975,2,'1786721560-TEST',1,333,332,'m1carbine',30,30,7,272.61,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (976,2,'1786721560-TEST',1,330,325,'garand',300,100,1,273.12,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (977,2,'1786721560-TEST',1,326,334,'30cal',63,63,6,273.25,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (978,2,'1786721560-TEST',1,333,332,'m1carbine',30,30,4,275.31,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (979,2,'1786721560-TEST',1,333,332,'m1carbine',30,30,4,275.6,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (980,2,'1786721560-TEST',1,328,330,'mg42',37,37,3,285.9,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (981,2,'1786721560-TEST',1,324,321,'scopedkar',120,100,6,289.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (982,2,'1786721560-TEST',1,322,322,'mortar',12,12,0,293.16,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (983,2,'1786721560-TEST',1,333,328,'m1carbine',25,25,6,299.1,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (984,2,'1786721560-TEST',1,333,328,'m1carbine',25,25,6,299.37,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (985,2,'1786721560-TEST',1,328,330,'mg42',63,63,6,299.85,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (986,2,'1786721560-TEST',1,335,324,'greasegun',40,40,2,300.21,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (987,2,'1786721560-TEST',1,322,323,'luger',30,30,5,300.36,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (988,2,'1786721560-TEST',1,335,324,'greasegun',40,40,2,300.42,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (989,2,'1786721560-TEST',1,335,324,'greasegun',30,30,7,301.23,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (990,2,'1786721560-TEST',1,333,328,'m1carbine',30,30,5,301.32,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (991,2,'1786721560-TEST',1,322,323,'luger',30,30,7,301.49,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (992,2,'1786721560-TEST',1,328,326,'mg42',63,63,6,301.6,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (993,2,'1786721560-TEST',1,322,323,'luger',30,30,7,301.74,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (994,2,'1786721560-TEST',1,328,326,'mg42',63,63,6,301.81,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (995,2,'1786721560-TEST',1,322,323,'luger',30,30,7,301.97,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (996,2,'1786721560-TEST',1,335,328,'greasegun',100,100,1,306.05,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (997,2,'1786721560-TEST',1,333,334,'m1carbine',30,30,5,310.78,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (998,2,'1786721560-TEST',1,333,334,'m1carbine',30,30,5,311.04,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (999,2,'1786721560-TEST',1,335,334,'greasegun',26,26,5,311.39,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1000,2,'1786721560-TEST',1,335,334,'greasegun',30,30,4,311.59,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1001,2,'1786721560-TEST',1,333,336,'m1carbine',30,30,6,312.18,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1002,2,'1786721560-TEST',1,333,336,'m1carbine',40,40,3,316.97,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1003,2,'1786721560-TEST',1,333,336,'m1carbine',30,30,6,317.5,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1004,2,'1786721560-TEST',1,329,329,'mortar',63,63,0,326.74,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1005,2,'1786721560-TEST',1,334,333,'kar',69,69,1,334.13,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1006,2,'1786721560-TEST',1,321,325,'colt',30,30,6,335.08,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1007,2,'1786721560-TEST',1,330,330,'mortar',11,11,0,335.11,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1008,2,'1786721560-TEST',1,326,332,'thompson',40,40,3,335.25,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1009,2,'1786721560-TEST',1,321,325,'colt',30,30,6,335.33,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1010,2,'1786721560-TEST',1,326,332,'thompson',40,40,3,335.39,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1011,2,'1786721560-TEST',1,326,332,'thompson',40,40,3,335.53,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1012,2,'1786721560-TEST',1,321,325,'colt',30,30,6,335.55,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1013,2,'1786721560-TEST',1,321,325,'colt',30,30,6,335.76,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1014,2,'1786721560-TEST',1,328,333,'k43',90,90,5,340.19,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1015,2,'1786721560-TEST',1,324,326,'luger',30,30,4,345.26,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1016,2,'1786721560-TEST',1,326,324,'thompson',100,100,1,345.4,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1017,2,'1786721560-TEST',1,326,328,'thompson',30,30,6,348.38,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1018,2,'1786721560-TEST',1,326,328,'thompson',30,30,6,348.51,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1019,2,'1786721560-TEST',1,326,328,'thompson',30,30,6,348.65,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1020,2,'1786721560-TEST',1,326,328,'thompson',30,30,6,348.78,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1021,2,'1786721560-TEST',1,334,326,'kar',120,100,6,350.42,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1022,2,'1786721560-TEST',1,331,335,'k43',90,90,7,351.78,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1023,2,'1786721560-TEST',1,331,335,'k43',90,90,6,353.48,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1024,2,'1786721560-TEST',1,329,329,'mortar',112,100,0,357.21,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1025,2,'1786721560-TEST',1,335,331,'grenade',8,8,0,358.56,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1026,2,'1786721560-TEST',1,321,331,'colt',40,40,3,359.39,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1027,2,'1786721560-TEST',1,321,331,'colt',30,30,6,364.65,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1028,2,'1786721560-TEST',1,321,331,'colt',30,30,6,364.87,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1029,2,'1786721560-TEST',1,333,333,'mortar',10,10,0,375.28,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1030,2,'1786721560-TEST',1,322,322,'mortar',74,74,0,386.41,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1031,2,'1786721560-TEST',1,332,332,'mortar',51,51,0,386.41,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1032,2,'1786721560-TEST',1,335,325,'greasegun',24,24,7,391.5,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1033,2,'1786721560-TEST',1,335,334,'greasegun',30,30,7,391.5,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1034,2,'1786721560-TEST',1,332,332,'mortar',149,100,0,391.52,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1035,2,'1786721560-TEST',1,335,325,'greasegun',20,20,7,392.53,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1036,2,'1786721560-TEST',1,335,334,'greasegun',30,30,7,392.53,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1037,2,'1786721560-TEST',1,335,325,'greasegun',26,26,7,392.73,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1038,2,'1786721560-TEST',1,335,334,'greasegun',30,30,7,392.73,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1039,2,'1786721560-TEST',1,335,334,'greasegun',30,30,7,392.93,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1040,2,'1786721560-TEST',1,335,325,'greasegun',26,26,7,392.93,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1041,2,'1786721560-TEST',1,330,325,'thompson',32,32,5,393.48,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1042,2,'1786721560-TEST',1,323,328,'colt',30,30,6,397.33,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1043,2,'1786721560-TEST',1,323,328,'colt',30,30,6,397.56,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1044,2,'1786721560-TEST',1,328,323,'luger',30,30,4,397.9,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1045,2,'1786721560-TEST',1,328,323,'luger',30,30,4,398.14,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1046,2,'1786721560-TEST',1,328,323,'luger',30,30,5,399.29,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1047,2,'1786721560-TEST',1,323,328,'colt',30,30,6,402.84,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1048,2,'1786721560-TEST',1,323,328,'colt',30,30,6,403.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1049,2,'1786721560-TEST',1,333,336,'m1carbine',30,30,4,406.54,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1050,2,'1786721560-TEST',1,324,333,'scopedkar',113,100,7,408.12,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1051,2,'1786721560-TEST',1,330,336,'thompson',30,30,6,415.08,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1052,2,'1786721560-TEST',1,330,336,'thompson',30,30,7,415.21,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1053,2,'1786721560-TEST',1,330,336,'thompson',30,30,7,415.35,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1054,2,'1786721560-TEST',1,326,332,'greasegun',40,40,2,417.63,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1055,2,'1786721560-TEST',1,326,332,'greasegun',40,40,2,417.83,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1056,2,'1786721560-TEST',1,326,332,'greasegun',40,40,2,418.04,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1057,2,'1786721560-TEST',1,335,335,'mortar',8,8,0,418.26,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1058,2,'1786721560-TEST',1,323,334,'colt',30,30,7,420.01,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1059,2,'1786721560-TEST',1,323,334,'colt',30,30,7,420.25,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1060,2,'1786721560-TEST',1,334,330,'scopedkar',120,100,6,426.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1061,2,'1786721560-TEST',1,331,323,'mg42',85,85,2,426.75,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1062,2,'1786721560-TEST',1,331,321,'mg42',85,85,3,432.64,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1063,2,'1786721560-TEST',1,331,321,'mg42',85,85,3,432.85,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1064,2,'1786721560-TEST',1,331,327,'mg42',85,85,3,436.03,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1065,2,'1786721560-TEST',1,322,326,'luger',30,30,6,436.03,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1066,2,'1786721560-TEST',1,331,327,'mg42',85,85,3,436.28,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1067,2,'1786721560-TEST',1,326,322,'greasegun',30,30,4,437.24,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1068,2,'1786721560-TEST',1,326,328,'greasegun',40,40,2,438.27,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1069,2,'1786721560-TEST',1,326,328,'greasegun',30,30,4,438.48,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1070,2,'1786721560-TEST',1,326,328,'greasegun',40,40,3,438.69,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1071,2,'1786721560-TEST',1,328,326,'grenade2',79,79,0,443.28,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1072,2,'1786721560-TEST',1,329,334,'thompson',30,30,4,450.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1073,2,'1786721560-TEST',1,329,334,'thompson',30,30,4,450.23,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1074,2,'1786721560-TEST',1,336,329,'scopedkar',120,100,7,461.66,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1075,2,'1786721560-TEST',1,336,323,'scopedkar',120,100,4,464.11,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1076,2,'1786721560-TEST',1,335,331,'thompson',30,30,4,467.03,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1077,2,'1786721560-TEST',1,335,331,'thompson',30,30,4,467.18,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1078,2,'1786721560-TEST',1,335,331,'thompson',30,30,4,467.31,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1079,2,'1786721560-TEST',1,335,331,'thompson',40,40,3,467.45,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1080,2,'1786721560-TEST',1,332,321,'mg34',63,63,5,479.76,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1081,2,'1786721560-TEST',1,332,321,'mg34',41,41,5,479.76,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1082,2,'1786721560-TEST',1,332,335,'mg34',63,63,7,480.49,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1083,2,'1786721560-TEST',1,335,332,'thompson',40,40,3,480.51,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1084,2,'1786721560-TEST',1,335,332,'thompson',30,30,6,480.66,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1085,2,'1786721560-TEST',1,332,335,'mg34',63,63,7,480.7,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1086,2,'1786721560-TEST',1,326,332,'bar',63,63,6,483.48,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1087,2,'1786721560-TEST',1,336,327,'luger',40,40,3,483.63,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1088,2,'1786721560-TEST',1,324,327,'scopedkar',120,100,7,483.77,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1089,2,'1786721560-TEST',1,324,330,'scopedkar',106,100,1,486.29,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1090,2,'1786721560-TEST',1,324,324,'mortar',12,12,0,491.89,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1091,2,'1786721560-TEST',1,324,326,'scopedkar',120,100,6,496,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1092,2,'1786721560-TEST',1,323,323,'mortar',15,15,0,507.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1093,2,'1786721560-TEST',1,333,336,'greasegun',40,40,3,515.69,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1094,2,'1786721560-TEST',1,334,333,'mg42',63,63,6,515.85,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1095,2,'1786721560-TEST',1,333,336,'greasegun',30,30,6,515.91,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1096,2,'1786721560-TEST',1,334,333,'mg42',63,63,6,516.07,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1097,2,'1786721560-TEST',1,333,336,'grenade',42,42,0,519.34,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1098,2,'1786721560-TEST',1,322,322,'mortar',5,5,0,519.53,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1099,2,'1786721560-TEST',1,323,334,'bar',45,45,2,523.34,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1100,2,'1786721560-TEST',1,323,334,'bar',54,54,2,523.51,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1101,2,'1786721560-TEST',1,330,334,'greasegun',30,30,6,523.55,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1102,2,'1786721560-TEST',1,327,332,'spring',120,100,6,523.84,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1103,2,'1786721560-TEST',1,325,327,'mg42',63,63,4,530.44,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1104,2,'1786721560-TEST',1,325,327,'mg42',63,63,4,530.44,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1105,2,'1786721560-TEST',1,329,325,'greasegun',30,30,4,534.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1106,2,'1786721560-TEST',1,329,325,'greasegun',30,30,4,534.29,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1107,2,'1786721560-TEST',1,324,323,'scopedkar',160,100,3,534.38,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1108,2,'1786721560-TEST',1,329,325,'greasegun',30,30,5,535.12,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1109,2,'1786721560-TEST',1,329,325,'greasegun',30,30,5,535.32,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1110,2,'1786721560-TEST',1,324,335,'scopedkar',160,100,3,538.49,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1111,2,'1786721560-TEST',1,329,329,'grenade',24,24,0,538.61,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1112,2,'1786721560-TEST',1,321,322,'spring',120,100,5,539.37,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1113,2,'1786721560-TEST',1,321,321,'mortar',5,5,0,555.8,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1114,2,'1786721560-TEST',1,329,334,'greasegun',30,30,4,558.37,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1115,2,'1786721560-TEST',1,334,329,'mp44',50,50,3,558.52,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1116,2,'1786721560-TEST',1,329,334,'greasegun',30,30,4,558.59,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1117,2,'1786721560-TEST',1,329,334,'greasegun',4,4,4,558.59,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1118,2,'1786721560-TEST',1,334,329,'mp44',50,50,3,558.65,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1119,2,'1786721560-TEST',1,327,324,'greasegun',30,30,7,559.72,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1120,2,'1786721560-TEST',1,324,327,'scopedkar',400,100,1,559.73,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1121,2,'1786721560-TEST',1,332,333,'kar',77,77,7,560.48,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1122,2,'1786721560-TEST',1,333,332,'garand',90,90,7,561.07,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1123,2,'1786721560-TEST',1,333,332,'garand',90,90,7,562.99,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1124,2,'1786721560-TEST',1,333,336,'garand',89,89,7,566.43,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1125,2,'1786721560-TEST',1,333,331,'garand',90,90,7,566.44,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1126,2,'1786721560-TEST',1,323,324,'thompson',30,30,4,567.67,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1127,2,'1786721560-TEST',1,335,324,'30cal',63,63,4,567.81,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1128,2,'1786721560-TEST',1,333,331,'garand',120,100,2,568.35,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1129,2,'1786721560-TEST',1,333,336,'garand',90,90,4,571.38,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1130,2,'1786721560-TEST',1,325,333,'mg42',212,100,1,579.76,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1131,2,'1786721560-TEST',1,334,326,'mp44',37,37,7,585.14,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1132,2,'1786721560-TEST',1,334,326,'mp44',37,37,7,585.28,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1133,2,'1786721560-TEST',1,334,326,'mp44',37,37,7,585.43,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1134,2,'1786721560-TEST',1,328,323,'scopedkar',399,100,4,590.58,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1135,2,'1786721560-TEST',1,326,334,'grenade',39,39,0,590.62,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1136,2,'1786721560-TEST',1,326,328,'grenade',25,25,0,590.63,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1137,2,'1786721560-TEST',1,331,321,'kar',160,100,2,592.77,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1138,2,'1786721560-TEST',1,329,325,'colt',30,30,4,595.87,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1139,2,'1786721560-TEST',1,330,325,'30cal',63,63,7,596.39,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1140,2,'1786721560-TEST',1,330,325,'30cal',63,63,6,596.62,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1141,2,'1786721560-TEST',1,327,327,'mortar',24,24,0,613.53,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1142,2,'1786721560-TEST',1,332,330,'mp44',6,6,2,613.93,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1143,2,'1786721560-TEST',1,332,330,'mp44',37,37,5,614.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1144,2,'1786721560-TEST',1,333,328,'thompson',40,40,3,614.17,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1145,2,'1786721560-TEST',1,332,330,'mp44',37,37,5,614.2,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1146,2,'1786721560-TEST',1,333,328,'thompson',40,40,3,614.31,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1147,2,'1786721560-TEST',1,332,330,'mp44',37,37,5,614.34,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_damage_events` (`id`, `server_id`, `match_id`, `half`, `attacker_id`, `victim_id`, `weapon`, `damage`, `damage_capped`, `hitplace`, `game_time`, `event_time`, `created_at`) VALUES (1148,2,'1786721560-TEST',1,322,322,'mortar',42,42,0,615.42,'2026-08-14 16:45:16','2026-08-14 16:45:16');
/*!40000 ALTER TABLE `ktp_damage_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_flag_captures`
--

DROP TABLE IF EXISTS `ktp_flag_captures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_flag_captures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `server_id` int unsigned NOT NULL,
  `match_id` varchar(64) DEFAULT NULL,
  `half` tinyint NOT NULL DEFAULT '0' COMMENT '0=no match context, 1/2=half, 3+=OT',
  `player_id` int NOT NULL,
  `team` varchar(16) DEFAULT NULL COMMENT 'Allies/Axis, straight from the engine player string -- not KSC_TEAM_*''s numeric convention, that''s KTPAMXX-side only',
  `flag_name` varchar(64) DEFAULT NULL COMMENT 'engine point name, e.g. POINT_ANZIO_PLAZA; NULL if the trailing dash-quoted name failed to parse',
  `event_time` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_server` (`server_id`),
  KEY `idx_match` (`match_id`),
  KEY `idx_player` (`player_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Per-player DoD 1.3 flag-capture completions -- raw facts, multi-capper detection is a query-time GROUP BY on (flag_name, event_time), not a stored column';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_flag_captures`
--

LOCK TABLES `ktp_flag_captures` WRITE;
/*!40000 ALTER TABLE `ktp_flag_captures` DISABLE KEYS */;
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (1,2,NULL,0,324,'Axis','POINT_BRIDGE','2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (2,2,NULL,0,331,'Axis','POINT_BRIDGE','2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (3,2,NULL,0,329,'Allies','POINT_ANZIO_PLAZA','2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (4,2,NULL,0,335,'Allies','POINT_ANZIO_PLAZA','2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (5,2,'1786721560-TEST',1,321,'Allies','POINT_BRIDGE','2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (6,2,'1786721560-TEST',1,330,'Allies','POINT_BRIDGE','2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (7,2,'1786721560-TEST',1,322,'Axis','POINT_BRIDGE','2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (8,2,'1786721560-TEST',1,331,'Axis','POINT_BRIDGE','2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (9,2,'1786721560-TEST',1,326,'Allies','POINT_BRIDGE','2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (10,2,'1786721560-TEST',1,330,'Allies','POINT_BRIDGE','2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (11,2,'1786721560-TEST',1,322,'Axis','POINT_ANZIO_PLAZA','2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (12,2,'1786721560-TEST',1,332,'Axis','POINT_ANZIO_PLAZA','2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (13,2,'1786721560-TEST',1,321,'Allies','POINT_ANZIO_PLAZA','2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (14,2,'1786721560-TEST',1,335,'Allies','POINT_ANZIO_PLAZA','2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (15,2,'1786721560-TEST',1,322,'Axis','POINT_ANZIO_PLAZA','2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (16,2,'1786721560-TEST',1,332,'Axis','POINT_ANZIO_PLAZA','2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (17,2,'1786721560-TEST',1,325,'Axis','POINT_BRIDGE','2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (18,2,'1786721560-TEST',1,334,'Axis','POINT_BRIDGE','2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (19,2,'1786721560-TEST',1,330,'Allies','POINT_BRIDGE','2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (20,2,'1786721560-TEST',1,335,'Allies','POINT_BRIDGE','2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (21,2,'1786721560-TEST',1,321,'Allies','POINT_ANZIO_PLAZA','2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (22,2,'1786721560-TEST',1,323,'Allies','POINT_ANZIO_PLAZA','2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (23,2,'1786721560-TEST',1,334,'Axis','POINT_ANZIO_PLAZA','2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (24,2,'1786721560-TEST',1,336,'Axis','POINT_ANZIO_PLAZA','2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (25,2,'1786721560-TEST',1,329,'Allies','POINT_ANZIO_PLAZA','2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (26,2,'1786721560-TEST',1,335,'Allies','POINT_ANZIO_PLAZA','2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (27,2,'1786721560-TEST',1,324,'Axis','POINT_BRIDGE','2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_flag_captures` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `flag_name`, `event_time`, `created_at`) VALUES (28,2,'1786721560-TEST',1,332,'Axis','POINT_BRIDGE','2026-08-14 16:45:16','2026-08-14 16:45:16');
/*!40000 ALTER TABLE `ktp_flag_captures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_flag_positions`
--

DROP TABLE IF EXISTS `ktp_flag_positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_flag_positions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `server_id` int unsigned NOT NULL,
  `map_name` varchar(32) NOT NULL,
  `flag_index` tinyint NOT NULL,
  `flag_name` varchar(32) NOT NULL,
  `origin_x` mediumint NOT NULL,
  `origin_y` mediumint NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_server_map_flag` (`server_id`,`map_name`,`flag_index`),
  KEY `idx_map` (`map_name`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Static per-flag (x,y) per map, for last-flag-defense / ninja-cap proximity checks';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_flag_positions`
--

LOCK TABLES `ktp_flag_positions` WRITE;
/*!40000 ALTER TABLE `ktp_flag_positions` DISABLE KEYS */;
INSERT INTO `ktp_flag_positions` (`id`, `server_id`, `map_name`, `flag_index`, `flag_name`, `origin_x`, `origin_y`, `updated_at`) VALUES (6,2,'dod_anzio',0,'POINT_ANZIO_LAUNDRY',-1495,-326,'2026-08-14 16:44:53');
INSERT INTO `ktp_flag_positions` (`id`, `server_id`, `map_name`, `flag_index`, `flag_name`, `origin_x`, `origin_y`, `updated_at`) VALUES (7,2,'dod_anzio',1,'POINT_BRIDGE',1040,-288,'2026-08-14 16:44:53');
INSERT INTO `ktp_flag_positions` (`id`, `server_id`, `map_name`, `flag_index`, `flag_name`, `origin_x`, `origin_y`, `updated_at`) VALUES (8,2,'dod_anzio',2,'POINT_ANZIO_STREET',448,800,'2026-08-14 16:44:53');
INSERT INTO `ktp_flag_positions` (`id`, `server_id`, `map_name`, `flag_index`, `flag_name`, `origin_x`, `origin_y`, `updated_at`) VALUES (9,2,'dod_anzio',3,'POINT_ANZIO_PLAZA',-698,923,'2026-08-14 16:44:53');
INSERT INTO `ktp_flag_positions` (`id`, `server_id`, `map_name`, `flag_index`, `flag_name`, `origin_x`, `origin_y`, `updated_at`) VALUES (10,2,'dod_anzio',4,'POINT_ANZIO_HILL',1375,1682,'2026-08-14 16:44:53');
/*!40000 ALTER TABLE `ktp_flag_positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_match_players`
--

DROP TABLE IF EXISTS `ktp_match_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_match_players` (
  `id` int NOT NULL AUTO_INCREMENT,
  `match_id` varchar(64) NOT NULL,
  `player_id` int NOT NULL,
  `steam_id` varchar(32) NOT NULL,
  `player_name` varchar(64) NOT NULL,
  `team` tinyint NOT NULL,
  `joined_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_match_player` (`match_id`,`player_id`),
  KEY `idx_match` (`match_id`),
  KEY `idx_player` (`player_id`),
  KEY `idx_steam` (`steam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41751 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_match_players`
--

LOCK TABLES `ktp_match_players` WRITE;
/*!40000 ALTER TABLE `ktp_match_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `ktp_match_players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_match_stats`
--

DROP TABLE IF EXISTS `ktp_match_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_match_stats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `match_id` varchar(64) NOT NULL,
  `player_id` int NOT NULL,
  `half` tinyint NOT NULL DEFAULT '0',
  `kills` int DEFAULT '0',
  `deaths` int DEFAULT '0',
  `headshots` int DEFAULT '0',
  `team_kills` int DEFAULT '0',
  `suicides` int DEFAULT '0',
  `damage` int DEFAULT '0',
  `score` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_match_player_half` (`match_id`,`player_id`,`half`),
  KEY `idx_match` (`match_id`),
  KEY `idx_player` (`player_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63207 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_match_stats`
--

LOCK TABLES `ktp_match_stats` WRITE;
/*!40000 ALTER TABLE `ktp_match_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `ktp_match_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_matches`
--

DROP TABLE IF EXISTS `ktp_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_matches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `match_id` varchar(64) NOT NULL,
  `server_id` int NOT NULL,
  `map_name` varchar(32) NOT NULL,
  `half` tinyint DEFAULT '1',
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_match_id_half` (`match_id`,`half`),
  KEY `idx_server` (`server_id`),
  KEY `idx_start_time` (`start_time`),
  KEY `idx_map` (`map_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3549 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_matches`
--

LOCK TABLES `ktp_matches` WRITE;
/*!40000 ALTER TABLE `ktp_matches` DISABLE KEYS */;
INSERT INTO `ktp_matches` (`id`, `match_id`, `server_id`, `map_name`, `half`, `start_time`, `end_time`, `created_at`) VALUES (3547,'1786721560-TEST',2,'dod_anzio',1,'2026-08-14 16:44:55','2026-08-14 16:45:16','2026-08-14 16:44:55');
/*!40000 ALTER TABLE `ktp_matches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_position_samples`
--

DROP TABLE IF EXISTS `ktp_position_samples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_position_samples` (
  `id` int NOT NULL AUTO_INCREMENT,
  `server_id` int unsigned NOT NULL,
  `match_id` varchar(64) DEFAULT NULL,
  `half` tinyint NOT NULL DEFAULT '0' COMMENT '0=no match context, 1/2=half, 3+=OT',
  `player_id` int NOT NULL,
  `team` tinyint NOT NULL COMMENT '1=Allies, 2=Axis, per KSC_TEAM_ALLIES/AXIS',
  `pos_x` mediumint NOT NULL,
  `pos_y` mediumint NOT NULL,
  `pos_z` mediumint NOT NULL,
  `game_time` float NOT NULL COMMENT 'get_gametime() at the sample, seconds since map start',
  `event_time` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_server` (`server_id`),
  KEY `idx_match` (`match_id`),
  KEY `idx_player` (`player_id`),
  KEY `idx_event_time` (`event_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1523 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Periodic roster-position samples -- raw facts for positional/holding stats and ninja-cap detection, classified entirely at query time';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_position_samples`
--

LOCK TABLES `ktp_position_samples` WRITE;
/*!40000 ALTER TABLE `ktp_position_samples` DISABLE KEYS */;
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1,2,NULL,0,321,1,-288,-2528,-570,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (2,2,NULL,0,322,2,2752,3120,-482,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (3,2,NULL,0,323,1,32,-2720,-586,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (4,2,NULL,0,324,2,2560,3119,-482,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (5,2,NULL,0,325,2,2064,3504,-474,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (6,2,NULL,0,326,1,-416,-2528,-570,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (7,2,NULL,0,327,1,-416,-2656,-570,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (8,2,NULL,0,328,2,2064,3696,-474,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (9,2,NULL,0,329,1,-288,-2656,-570,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (10,2,NULL,0,330,1,-160,-2528,-570,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (11,2,NULL,0,331,2,2064,3312,-474,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (12,2,NULL,0,332,2,2640,3024,-482,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (13,2,NULL,0,333,1,-32,-2528,-570,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (14,2,NULL,0,334,2,2752,2944,-482,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (15,2,NULL,0,335,1,-164,-2652,-570,26.03,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (16,2,NULL,0,321,1,-759,-2105,-601,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (17,2,NULL,0,322,2,2159,2935,-508,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (18,2,NULL,0,323,1,86,-2125,-588,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (19,2,NULL,0,324,2,1955,2841,-508,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (20,2,NULL,0,325,2,1731,2998,-482,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (21,2,NULL,0,326,1,-761,-2073,-586,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (22,2,NULL,0,327,1,94,-2170,-588,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (23,2,NULL,0,328,2,1780,3167,-464,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (24,2,NULL,0,329,1,-734,-2153,-625,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (25,2,NULL,0,330,1,-724,-2018,-588,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (26,2,NULL,0,331,2,2595,3164,-420,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (27,2,NULL,0,332,2,2116,2920,-508,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (28,2,NULL,0,333,1,63,-1714,-530,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (29,2,NULL,0,334,2,2610,2123,-380,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (30,2,NULL,0,335,1,-714,-2216,-608,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (31,2,NULL,0,336,2,2284,2910,-508,31.06,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (32,2,NULL,0,321,1,-753,-1436,-492,36,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (33,2,NULL,0,322,2,1542,2452,-460,36,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (34,2,NULL,0,323,1,11,-1357,-501,36,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (35,2,NULL,0,324,2,1348,2418,-500,36,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (36,2,NULL,0,325,2,1542,2200,-334,36,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (37,2,NULL,0,326,1,-721,-1654,-546,36,'2026-08-14 16:44:54','2026-08-14 16:44:54');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (38,2,NULL,0,327,1,15,-1416,-470,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (39,2,NULL,0,328,2,1540,2331,-400,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (40,2,NULL,0,329,1,-719,-1691,-555,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (41,2,NULL,0,330,1,-507,-1289,-505,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (42,2,NULL,0,331,2,2696,2440,-432,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (43,2,NULL,0,332,2,1526,2495,-482,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (44,2,NULL,0,333,1,66,-945,-380,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (45,2,NULL,0,334,2,2180,1536,-220,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (46,2,NULL,0,335,1,-715,-1737,-566,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (47,2,NULL,0,336,2,1602,2651,-500,36,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (48,2,NULL,0,321,1,-1037,-979,-380,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (49,2,NULL,0,322,2,1273,1792,-252,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (50,2,NULL,0,323,1,181,-592,-412,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (51,2,NULL,0,324,2,673,2269,-470,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (52,2,NULL,0,325,2,1435,1413,-252,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (53,2,NULL,0,326,1,-843,-956,-481,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (54,2,NULL,0,327,1,175,-657,-412,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (55,2,NULL,0,328,2,1268,1621,-252,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (56,2,NULL,0,329,1,-750,-966,-524,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (57,2,NULL,0,330,1,-504,-1002,-315,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (58,2,NULL,0,331,2,2287,1862,-377,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (59,2,NULL,0,332,2,1635,1733,-252,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (60,2,NULL,0,333,1,178,-209,-412,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (61,2,NULL,0,334,2,1834,1045,-320,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (62,2,NULL,0,335,1,-735,-1001,-524,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (63,2,NULL,0,336,2,1128,2210,-492,41.03,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (64,2,'1786721560-TEST',1,321,1,207,-503,-412,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (65,2,'1786721560-TEST',1,322,2,231,1509,-360,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (66,2,'1786721560-TEST',1,323,1,1731,1528,-270,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (67,2,'1786721560-TEST',1,324,2,873,836,-382,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (68,2,'1786721560-TEST',1,325,2,-272,1356,-261,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (69,2,'1786721560-TEST',1,326,1,-505,-1034,-428,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (70,2,'1786721560-TEST',1,327,1,1403,863,-372,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (71,2,'1786721560-TEST',1,328,2,2694,2387,-420,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (72,2,'1786721560-TEST',1,329,1,-513,414,-422,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (73,2,'1786721560-TEST',1,330,1,457,-329,-372,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (74,2,'1786721560-TEST',1,331,2,2251,2955,-508,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (75,2,'1786721560-TEST',1,332,2,-309,1357,-314,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (76,2,'1786721560-TEST',1,333,1,32,-2720,-575,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (77,2,'1786721560-TEST',1,334,2,1780,-52,-374,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (78,2,'1786721560-TEST',1,335,1,-1234,864,-195,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (79,2,'1786721560-TEST',1,336,2,1806,3193,-478,106.02,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (80,2,'1786721560-TEST',1,321,1,299,-24,-372,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (81,2,'1786721560-TEST',1,322,2,232,1432,-360,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (82,2,'1786721560-TEST',1,323,1,1492,1642,-252,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (83,2,'1786721560-TEST',1,324,2,1369,899,-372,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (84,2,'1786721560-TEST',1,325,2,9,1185,-372,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (85,2,'1786721560-TEST',1,326,1,-506,-1002,-328,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (86,2,'1786721560-TEST',1,328,2,2234,1803,-355,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (87,2,'1786721560-TEST',1,329,1,-365,389,-404,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (88,2,'1786721560-TEST',1,330,1,897,-189,-346,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (89,2,'1786721560-TEST',1,331,2,1531,2626,-500,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (90,2,'1786721560-TEST',1,332,2,216,959,-372,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (91,2,'1786721560-TEST',1,333,1,98,-2034,-588,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (92,2,'1786721560-TEST',1,334,2,1560,124,-348,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (93,2,'1786721560-TEST',1,335,1,-1400,879,-212,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (94,2,'1786721560-TEST',1,336,2,1544,2450,-459,111.06,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (95,2,'1786721560-TEST',1,321,1,997,-265,-332,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (96,2,'1786721560-TEST',1,322,2,314,1330,-364,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (97,2,'1786721560-TEST',1,323,1,1260,1448,-270,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (98,2,'1786721560-TEST',1,324,2,1367,1685,-252,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (99,2,'1786721560-TEST',1,325,2,819,1185,-272,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (100,2,'1786721560-TEST',1,326,1,-505,-1002,-335,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (101,2,'1786721560-TEST',1,328,2,2026,1113,-320,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (102,2,'1786721560-TEST',1,329,1,363,-40,-372,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (103,2,'1786721560-TEST',1,330,1,1040,-301,-332,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (104,2,'1786721560-TEST',1,331,2,1317,2271,-492,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (105,2,'1786721560-TEST',1,332,2,521,790,-390,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (106,2,'1786721560-TEST',1,333,1,8,-1231,-471,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (107,2,'1786721560-TEST',1,334,2,1457,88,-348,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (108,2,'1786721560-TEST',1,335,1,-1184,858,-377,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (109,2,'1786721560-TEST',1,336,2,1540,2134,-301,116.09,'2026-08-14 16:44:55','2026-08-14 16:44:55');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (110,2,'1786721560-TEST',1,321,1,1141,-273,-332,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (111,2,'1786721560-TEST',1,322,2,-455,1110,-404,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (112,2,'1786721560-TEST',1,325,2,884,1227,-284,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (113,2,'1786721560-TEST',1,326,1,-503,-1002,-313,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (114,2,'1786721560-TEST',1,327,1,-475,-2438,-588,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (115,2,'1786721560-TEST',1,328,2,1535,1035,-320,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (116,2,'1786721560-TEST',1,329,1,901,-276,-345,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (117,2,'1786721560-TEST',1,330,1,712,-176,-377,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (118,2,'1786721560-TEST',1,331,2,1010,2211,-492,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (119,2,'1786721560-TEST',1,332,2,521,790,-354,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (120,2,'1786721560-TEST',1,333,1,218,-489,-412,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (121,2,'1786721560-TEST',1,334,2,1457,88,-348,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (122,2,'1786721560-TEST',1,335,1,-587,775,-382,121.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (123,2,'1786721560-TEST',1,321,1,853,-216,-354,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (124,2,'1786721560-TEST',1,325,2,1365,1521,-252,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (125,2,'1786721560-TEST',1,326,1,-504,-1002,-319,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (126,2,'1786721560-TEST',1,327,1,-761,-2072,-587,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (127,2,'1786721560-TEST',1,328,2,1264,821,-372,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (128,2,'1786721560-TEST',1,329,1,919,-185,-342,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (129,2,'1786721560-TEST',1,330,1,1050,-106,-518,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (130,2,'1786721560-TEST',1,331,2,472,1966,-380,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (131,2,'1786721560-TEST',1,332,2,521,790,-354,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (132,2,'1786721560-TEST',1,333,1,-27,199,-392,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (133,2,'1786721560-TEST',1,335,1,-535,848,-398,126.06,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (134,2,'1786721560-TEST',1,321,1,815,-212,-362,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (135,2,'1786721560-TEST',1,322,2,2670,3023,-500,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (136,2,'1786721560-TEST',1,324,2,2618,3004,-500,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (137,2,'1786721560-TEST',1,326,1,-505,-1002,-350,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (138,2,'1786721560-TEST',1,327,1,-756,-1401,-495,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (139,2,'1786721560-TEST',1,328,2,978,889,-382,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (140,2,'1786721560-TEST',1,329,1,919,-185,-342,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (141,2,'1786721560-TEST',1,330,1,802,-155,-518,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (142,2,'1786721560-TEST',1,331,2,285,1329,-364,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (143,2,'1786721560-TEST',1,332,2,521,790,-354,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (144,2,'1786721560-TEST',1,333,1,-12,714,-403,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (145,2,'1786721560-TEST',1,334,2,2088,3397,-492,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (146,2,'1786721560-TEST',1,336,2,2146,3602,-492,131.09,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (147,2,'1786721560-TEST',1,321,1,815,-212,-362,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (148,2,'1786721560-TEST',1,322,2,2027,2877,-508,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (149,2,'1786721560-TEST',1,323,1,-274,-2511,-588,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (150,2,'1786721560-TEST',1,324,2,2608,2113,-380,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (151,2,'1786721560-TEST',1,326,1,-504,-1002,-342,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (152,2,'1786721560-TEST',1,327,1,-1087,-934,-364,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (153,2,'1786721560-TEST',1,328,2,892,836,-382,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (154,2,'1786721560-TEST',1,329,1,919,-185,-342,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (155,2,'1786721560-TEST',1,330,1,877,279,-518,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (156,2,'1786721560-TEST',1,331,2,258,818,-372,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (157,2,'1786721560-TEST',1,332,2,521,790,-354,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (158,2,'1786721560-TEST',1,333,1,-6,798,-390,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (159,2,'1786721560-TEST',1,334,2,1585,2692,-500,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (160,2,'1786721560-TEST',1,335,1,86,-2144,-588,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (161,2,'1786721560-TEST',1,336,2,1716,3026,-464,136.02,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (162,2,'1786721560-TEST',1,321,1,794,-218,-365,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (163,2,'1786721560-TEST',1,322,2,1540,2306,-387,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (164,2,'1786721560-TEST',1,323,1,-720,-1870,-588,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (165,2,'1786721560-TEST',1,324,2,2180,1533,-220,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (166,2,'1786721560-TEST',1,326,1,-501,-994,-310,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (167,2,'1786721560-TEST',1,327,1,-534,-579,-354,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (168,2,'1786721560-TEST',1,328,2,892,836,-382,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (169,2,'1786721560-TEST',1,329,1,924,-196,-341,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (170,2,'1786721560-TEST',1,330,1,875,506,-486,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (171,2,'1786721560-TEST',1,332,2,521,790,-354,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (172,2,'1786721560-TEST',1,333,1,-6,798,-390,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (173,2,'1786721560-TEST',1,334,2,1528,1901,-252,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (174,2,'1786721560-TEST',1,335,1,12,-1368,-497,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (175,2,'1786721560-TEST',1,336,2,1344,2364,-500,141.05,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (176,2,'1786721560-TEST',1,321,1,877,284,-518,146.08,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (177,2,'1786721560-TEST',1,322,2,1461,1504,-252,146.08,'2026-08-14 16:44:56','2026-08-14 16:44:56');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (178,2,'1786721560-TEST',1,323,1,-504,-1119,-519,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (179,2,'1786721560-TEST',1,324,2,1805,1011,-318,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (180,2,'1786721560-TEST',1,325,2,2704,2816,-500,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (181,2,'1786721560-TEST',1,326,1,-361,-275,-372,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (182,2,'1786721560-TEST',1,327,1,-134,218,-404,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (183,2,'1786721560-TEST',1,328,2,852,831,-390,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (184,2,'1786721560-TEST',1,329,1,1361,-102,-353,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (185,2,'1786721560-TEST',1,330,1,731,536,-468,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (186,2,'1786721560-TEST',1,331,2,2471,2873,-500,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (187,2,'1786721560-TEST',1,332,2,521,790,-354,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (188,2,'1786721560-TEST',1,333,1,-6,798,-390,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (189,2,'1786721560-TEST',1,334,2,1380,1127,-320,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (190,2,'1786721560-TEST',1,335,1,184,-645,-412,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (191,2,'1786721560-TEST',1,336,2,644,2278,-466,146.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (192,2,'1786721560-TEST',1,321,1,652,564,-484,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (193,2,'1786721560-TEST',1,322,2,1408,851,-372,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (194,2,'1786721560-TEST',1,323,1,-505,-1002,-312,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (195,2,'1786721560-TEST',1,324,2,1670,508,-260,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (196,2,'1786721560-TEST',1,325,2,2530,2001,-380,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (197,2,'1786721560-TEST',1,326,1,198,-270,-412,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (198,2,'1786721560-TEST',1,327,1,-12,704,-404,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (199,2,'1786721560-TEST',1,328,2,848,830,-355,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (200,2,'1786721560-TEST',1,329,1,1361,-102,-353,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (201,2,'1786721560-TEST',1,330,1,216,711,-484,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (202,2,'1786721560-TEST',1,331,2,1678,2693,-500,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (203,2,'1786721560-TEST',1,335,1,-17,-23,-420,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (204,2,'1786721560-TEST',1,336,2,359,1769,-360,151.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (205,2,'1786721560-TEST',1,321,1,142,707,-456,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (206,2,'1786721560-TEST',1,322,2,1408,851,-390,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (207,2,'1786721560-TEST',1,323,1,-503,-1076,-522,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (208,2,'1786721560-TEST',1,324,2,1671,610,-260,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (209,2,'1786721560-TEST',1,325,2,2179,1348,-220,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (210,2,'1786721560-TEST',1,326,1,206,-307,-412,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (211,2,'1786721560-TEST',1,327,1,-4,814,-390,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (212,2,'1786721560-TEST',1,329,1,1361,-102,-353,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (213,2,'1786721560-TEST',1,331,2,1520,1931,-252,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (214,2,'1786721560-TEST',1,335,1,-635,632,-404,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (215,2,'1786721560-TEST',1,336,2,175,1045,-372,156.05,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (216,2,'1786721560-TEST',1,322,2,1732,214,-372,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (217,2,'1786721560-TEST',1,323,1,-503,-1002,-312,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (218,2,'1786721560-TEST',1,324,2,1140,878,-364,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (219,2,'1786721560-TEST',1,325,2,1639,1039,-320,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (220,2,'1786721560-TEST',1,326,1,-19,390,-392,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (221,2,'1786721560-TEST',1,327,1,14,-2603,-588,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (222,2,'1786721560-TEST',1,329,1,-139,-2506,-588,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (223,2,'1786721560-TEST',1,330,1,-454,-2425,-588,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (224,2,'1786721560-TEST',1,331,2,1242,1463,-252,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (225,2,'1786721560-TEST',1,333,1,-532,-2462,-588,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (226,2,'1786721560-TEST',1,335,1,-1162,854,-422,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (227,2,'1786721560-TEST',1,336,2,109,835,-372,161.08,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (228,2,'1786721560-TEST',1,322,2,1690,-60,-374,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (229,2,'1786721560-TEST',1,323,1,-506,-1047,-472,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (230,2,'1786721560-TEST',1,324,2,865,828,-390,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (231,2,'1786721560-TEST',1,325,2,1197,532,-364,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (232,2,'1786721560-TEST',1,326,1,0,743,-387,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (233,2,'1786721560-TEST',1,327,1,85,-1822,-556,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (234,2,'1786721560-TEST',1,328,2,2702,2399,-422,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (235,2,'1786721560-TEST',1,329,1,62,-1681,-523,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (236,2,'1786721560-TEST',1,330,1,-722,-1799,-582,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (237,2,'1786721560-TEST',1,331,2,1731,2020,-270,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (238,2,'1786721560-TEST',1,332,2,2272,2943,-508,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (239,2,'1786721560-TEST',1,333,1,-682,-1643,-543,166.01,'2026-08-14 16:44:57','2026-08-14 16:44:57');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (240,2,'1786721560-TEST',1,334,2,1785,3131,-440,166.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (241,2,'1786721560-TEST',1,335,1,-1383,1014,-224,166.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (242,2,'1786721560-TEST',1,336,2,152,757,-390,166.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (243,2,'1786721560-TEST',1,322,2,1676,-64,-374,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (244,2,'1786721560-TEST',1,323,1,-503,-1002,-347,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (245,2,'1786721560-TEST',1,324,2,882,820,-382,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (246,2,'1786721560-TEST',1,325,2,1222,561,-364,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (247,2,'1786721560-TEST',1,326,1,81,827,-372,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (248,2,'1786721560-TEST',1,327,1,48,-1030,-401,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (249,2,'1786721560-TEST',1,328,2,2307,1872,-380,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (250,2,'1786721560-TEST',1,329,1,52,-894,-390,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (251,2,'1786721560-TEST',1,330,1,-698,-1014,-524,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (252,2,'1786721560-TEST',1,331,2,1731,2020,-270,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (253,2,'1786721560-TEST',1,332,2,1442,2614,-500,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (254,2,'1786721560-TEST',1,333,1,-505,-1044,-456,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (255,2,'1786721560-TEST',1,334,2,1544,2277,-372,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (256,2,'1786721560-TEST',1,335,1,-1160,1076,-79,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (257,2,'1786721560-TEST',1,336,2,152,757,-390,171.04,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (258,2,'1786721560-TEST',1,321,1,-269,-2512,-588,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (259,2,'1786721560-TEST',1,322,2,1574,-189,-356,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (260,2,'1786721560-TEST',1,323,1,-506,-995,-310,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (261,2,'1786721560-TEST',1,324,2,1139,878,-364,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (262,2,'1786721560-TEST',1,325,2,1171,890,-364,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (263,2,'1786721560-TEST',1,327,1,193,-269,-412,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (264,2,'1786721560-TEST',1,328,2,2107,1148,-312,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (265,2,'1786721560-TEST',1,329,1,182,-212,-412,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (266,2,'1786721560-TEST',1,330,1,-767,-855,-343,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (267,2,'1786721560-TEST',1,331,2,1560,1678,-252,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (268,2,'1786721560-TEST',1,332,2,918,2221,-492,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (269,2,'1786721560-TEST',1,333,1,-504,-1002,-346,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (270,2,'1786721560-TEST',1,334,2,1237,1612,-252,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (271,2,'1786721560-TEST',1,335,1,-1129,1076,-78,176.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (272,2,'1786721560-TEST',1,321,1,-720,-1907,-588,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (273,2,'1786721560-TEST',1,322,2,1171,-272,-336,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (274,2,'1786721560-TEST',1,323,1,-472,-321,-372,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (275,2,'1786721560-TEST',1,324,2,1407,992,-356,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (276,2,'1786721560-TEST',1,325,2,953,873,-382,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (277,2,'1786721560-TEST',1,327,1,-18,395,-392,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (278,2,'1786721560-TEST',1,328,2,1469,1050,-320,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (279,2,'1786721560-TEST',1,329,1,-15,456,-392,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (280,2,'1786721560-TEST',1,330,1,-493,-455,-389,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (281,2,'1786721560-TEST',1,331,2,1391,1024,-344,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (282,2,'1786721560-TEST',1,332,2,454,1987,-386,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (283,2,'1786721560-TEST',1,333,1,-504,-1014,-374,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (284,2,'1786721560-TEST',1,334,2,631,1180,-306,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (285,2,'1786721560-TEST',1,335,1,-1396,941,-212,181.01,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (286,2,'1786721560-TEST',1,321,1,-504,-1159,-515,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (287,2,'1786721560-TEST',1,322,2,1171,-272,-336,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (288,2,'1786721560-TEST',1,323,1,-101,321,-392,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (289,2,'1786721560-TEST',1,324,2,1401,1451,-270,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (290,2,'1786721560-TEST',1,325,2,608,802,-372,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (291,2,'1786721560-TEST',1,327,1,67,-7,-420,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (292,2,'1786721560-TEST',1,328,2,978,833,-382,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (293,2,'1786721560-TEST',1,329,1,-1,782,-390,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (294,2,'1786721560-TEST',1,330,1,-493,-455,-389,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (295,2,'1786721560-TEST',1,331,2,1361,289,-364,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (296,2,'1786721560-TEST',1,332,2,284,1339,-364,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (297,2,'1786721560-TEST',1,333,1,-504,-1002,-343,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (298,2,'1786721560-TEST',1,334,2,-86,1174,-372,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (299,2,'1786721560-TEST',1,335,1,-1276,847,-167,186.05,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (300,2,'1786721560-TEST',1,321,1,-505,-1002,-338,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (301,2,'1786721560-TEST',1,322,2,1171,-272,-336,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (302,2,'1786721560-TEST',1,323,1,-3,741,-398,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (303,2,'1786721560-TEST',1,324,2,1401,1451,-270,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (304,2,'1786721560-TEST',1,325,2,176,850,-372,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (305,2,'1786721560-TEST',1,326,1,-331,-2496,-588,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (306,2,'1786721560-TEST',1,328,2,985,824,-382,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (307,2,'1786721560-TEST',1,330,1,-186,-103,-420,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (308,2,'1786721560-TEST',1,331,2,1675,233,-372,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (309,2,'1786721560-TEST',1,332,2,265,887,-372,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (310,2,'1786721560-TEST',1,333,1,-846,-954,-481,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (311,2,'1786721560-TEST',1,334,2,-699,923,-404,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (312,2,'1786721560-TEST',1,335,1,-740,-2196,-608,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (313,2,'1786721560-TEST',1,336,2,2702,2515,-450,191.08,'2026-08-14 16:44:58','2026-08-14 16:44:58');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (314,2,'1786721560-TEST',1,321,1,-504,-1065,-532,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (315,2,'1786721560-TEST',1,322,2,1171,-272,-336,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (316,2,'1786721560-TEST',1,324,2,1264,864,-372,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (317,2,'1786721560-TEST',1,325,2,67,774,-390,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (318,2,'1786721560-TEST',1,326,1,-719,-1839,-588,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (319,2,'1786721560-TEST',1,328,2,985,824,-382,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (320,2,'1786721560-TEST',1,330,1,-9,622,-410,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (321,2,'1786721560-TEST',1,331,2,1384,-197,-355,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (322,2,'1786721560-TEST',1,332,2,526,792,-390,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (323,2,'1786721560-TEST',1,333,1,-1265,-506,-372,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (324,2,'1786721560-TEST',1,334,2,-700,922,-404,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (325,2,'1786721560-TEST',1,335,1,-737,-1915,-588,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (326,2,'1786721560-TEST',1,336,2,2337,1888,-368,196.01,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (327,2,'1786721560-TEST',1,321,1,-504,-1002,-338,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (328,2,'1786721560-TEST',1,322,2,1171,-272,-336,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (329,2,'1786721560-TEST',1,323,1,-416,-2527,-584,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (330,2,'1786721560-TEST',1,324,2,935,851,-382,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (331,2,'1786721560-TEST',1,325,2,82,848,-390,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (332,2,'1786721560-TEST',1,326,1,-694,-1041,-524,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (333,2,'1786721560-TEST',1,327,1,-416,-2655,-584,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (334,2,'1786721560-TEST',1,328,2,1027,924,-364,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (335,2,'1786721560-TEST',1,329,1,-288,-2656,-584,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (336,2,'1786721560-TEST',1,331,2,1203,-267,-339,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (337,2,'1786721560-TEST',1,332,2,694,800,-372,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (338,2,'1786721560-TEST',1,333,1,-1238,310,-372,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (339,2,'1786721560-TEST',1,334,2,-700,922,-404,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (340,2,'1786721560-TEST',1,335,1,-504,-1069,-523,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (341,2,'1786721560-TEST',1,336,2,1818,1388,-229,201.05,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (342,2,'1786721560-TEST',1,321,1,-506,-1002,-319,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (343,2,'1786721560-TEST',1,322,2,973,-61,-500,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (344,2,'1786721560-TEST',1,323,1,-736,-2105,-601,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (345,2,'1786721560-TEST',1,324,2,904,816,-382,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (346,2,'1786721560-TEST',1,325,2,56,699,-420,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (347,2,'1786721560-TEST',1,326,1,-813,-866,-347,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (348,2,'1786721560-TEST',1,327,1,-760,-2073,-587,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (349,2,'1786721560-TEST',1,328,2,1614,296,-372,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (350,2,'1786721560-TEST',1,329,1,106,-2003,-588,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (351,2,'1786721560-TEST',1,331,2,1731,-163,-356,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (352,2,'1786721560-TEST',1,332,2,560,751,-372,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (353,2,'1786721560-TEST',1,333,1,-860,887,-404,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (354,2,'1786721560-TEST',1,335,1,-505,-1002,-356,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (355,2,'1786721560-TEST',1,336,2,1086,1485,-258,206.09,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (356,2,'1786721560-TEST',1,321,1,-541,-575,-355,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (357,2,'1786721560-TEST',1,322,2,798,-149,-518,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (358,2,'1786721560-TEST',1,323,1,-746,-1485,-503,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (359,2,'1786721560-TEST',1,324,2,507,796,-372,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (360,2,'1786721560-TEST',1,325,2,16,808,-390,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (361,2,'1786721560-TEST',1,326,1,-402,-315,-372,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (362,2,'1786721560-TEST',1,327,1,-662,-1610,-535,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (363,2,'1786721560-TEST',1,328,2,1755,97,-356,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (364,2,'1786721560-TEST',1,329,1,8,-1236,-473,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (365,2,'1786721560-TEST',1,331,2,1735,65,-356,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (366,2,'1786721560-TEST',1,332,2,560,751,-372,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (367,2,'1786721560-TEST',1,333,1,-1139,850,-422,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (368,2,'1786721560-TEST',1,335,1,-504,-1095,-521,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (369,2,'1786721560-TEST',1,336,2,337,1196,-359,211.02,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (370,2,'1786721560-TEST',1,321,1,-188,-61,-438,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (371,2,'1786721560-TEST',1,322,2,877,291,-518,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (372,2,'1786721560-TEST',1,323,1,-1023,-986,-380,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (373,2,'1786721560-TEST',1,324,2,56,821,-390,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (374,2,'1786721560-TEST',1,325,2,-24,806,-390,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (375,2,'1786721560-TEST',1,326,1,194,-260,-412,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (376,2,'1786721560-TEST',1,327,1,-505,-1023,-394,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (377,2,'1786721560-TEST',1,328,2,1761,42,-356,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (378,2,'1786721560-TEST',1,329,1,217,-516,-412,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (379,2,'1786721560-TEST',1,330,1,-583,-2383,-588,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (380,2,'1786721560-TEST',1,331,2,1751,2,-356,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (381,2,'1786721560-TEST',1,332,2,314,851,-372,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (382,2,'1786721560-TEST',1,333,1,-1361,895,-230,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (383,2,'1786721560-TEST',1,335,1,-503,-1002,-320,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (384,2,'1786721560-TEST',1,336,2,-282,1156,-404,216.06,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (385,2,'1786721560-TEST',1,321,1,-233,-96,-425,221,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (386,2,'1786721560-TEST',1,322,2,632,563,-484,221,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (387,2,'1786721560-TEST',1,323,1,-1289,-578,-390,221,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (388,2,'1786721560-TEST',1,324,2,49,824,-390,221,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (389,2,'1786721560-TEST',1,325,2,-11,756,-396,221,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (390,2,'1786721560-TEST',1,326,1,203,-372,-394,221,'2026-08-14 16:44:59','2026-08-14 16:44:59');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (391,2,'1786721560-TEST',1,327,1,-505,-1002,-314,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (392,2,'1786721560-TEST',1,328,2,1065,-275,-332,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (393,2,'1786721560-TEST',1,329,1,195,-404,-397,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (394,2,'1786721560-TEST',1,330,1,-728,-1828,-588,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (395,2,'1786721560-TEST',1,331,2,1256,-230,-343,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (396,2,'1786721560-TEST',1,332,2,74,716,-427,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (397,2,'1786721560-TEST',1,333,1,-1276,874,-185,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (398,2,'1786721560-TEST',1,334,2,2685,2406,-424,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (399,2,'1786721560-TEST',1,335,1,-540,-548,-359,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (400,2,'1786721560-TEST',1,336,2,-781,1733,-396,221,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (401,2,'1786721560-TEST',1,321,1,-233,-96,-425,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (402,2,'1786721560-TEST',1,322,2,152,707,-468,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (403,2,'1786721560-TEST',1,323,1,-1289,-578,-390,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (404,2,'1786721560-TEST',1,325,2,-9,652,-392,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (405,2,'1786721560-TEST',1,326,1,180,-229,-412,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (406,2,'1786721560-TEST',1,327,1,-505,-1002,-340,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (407,2,'1786721560-TEST',1,328,2,404,-150,-372,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (408,2,'1786721560-TEST',1,329,1,121,-176,-412,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (409,2,'1786721560-TEST',1,330,1,-505,-1065,-486,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (410,2,'1786721560-TEST',1,331,2,1734,-31,-374,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (411,2,'1786721560-TEST',1,332,2,31,822,-390,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (412,2,'1786721560-TEST',1,333,1,-718,916,-404,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (413,2,'1786721560-TEST',1,334,2,2239,1810,-358,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (414,2,'1786721560-TEST',1,335,1,-179,-128,-414,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (415,2,'1786721560-TEST',1,336,2,-1410,1513,-388,226.03,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (416,2,'1786721560-TEST',1,322,2,56,850,-390,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (417,2,'1786721560-TEST',1,323,1,-1284,-495,-372,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (418,2,'1786721560-TEST',1,326,1,3,-15,-420,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (419,2,'1786721560-TEST',1,327,1,-568,-779,-350,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (420,2,'1786721560-TEST',1,328,2,404,-31,-372,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (421,2,'1786721560-TEST',1,329,1,-23,131,-414,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (422,2,'1786721560-TEST',1,330,1,-504,-1002,-346,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (423,2,'1786721560-TEST',1,331,2,1672,-62,-374,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (424,2,'1786721560-TEST',1,333,1,-1171,844,-422,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (425,2,'1786721560-TEST',1,334,2,2014,1105,-320,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (426,2,'1786721560-TEST',1,336,2,-1384,1393,-392,231.07,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (427,2,'1786721560-TEST',1,322,2,39,808,-390,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (428,2,'1786721560-TEST',1,323,1,-1176,445,-372,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (429,2,'1786721560-TEST',1,324,2,2656,3120,-482,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (430,2,'1786721560-TEST',1,325,2,2736,3024,-482,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (431,2,'1786721560-TEST',1,327,1,-606,-522,-380,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (432,2,'1786721560-TEST',1,328,2,37,-126,-412,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (433,2,'1786721560-TEST',1,329,1,-6,753,-396,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (434,2,'1786721560-TEST',1,330,1,-505,-1036,-432,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (435,2,'1786721560-TEST',1,331,2,1680,-168,-356,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (436,2,'1786721560-TEST',1,332,2,2064,3504,-474,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (437,2,'1786721560-TEST',1,333,1,-1389,927,-212,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (438,2,'1786721560-TEST',1,334,2,1676,519,-260,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (439,2,'1786721560-TEST',1,336,2,-1138,1701,-384,236,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (440,2,'1786721560-TEST',1,321,1,10,-2616,-588,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (441,2,'1786721560-TEST',1,322,2,75,826,-390,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (442,2,'1786721560-TEST',1,323,1,-1210,862,-261,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (443,2,'1786721560-TEST',1,324,2,2175,2940,-508,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (444,2,'1786721560-TEST',1,325,2,2693,2222,-380,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (445,2,'1786721560-TEST',1,326,1,-472,-2439,-588,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (446,2,'1786721560-TEST',1,327,1,-607,-478,-386,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (447,2,'1786721560-TEST',1,328,2,-87,-63,-438,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (448,2,'1786721560-TEST',1,329,1,-329,-2525,-588,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (449,2,'1786721560-TEST',1,330,1,-504,-1002,-312,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (450,2,'1786721560-TEST',1,331,2,1048,-279,-332,241.04,'2026-08-14 16:45:00','2026-08-14 16:45:00');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (451,2,'1786721560-TEST',1,332,2,1695,2909,-508,241.04,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (452,2,'1786721560-TEST',1,333,1,-1084,1009,-228,241.04,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (453,2,'1786721560-TEST',1,334,2,1670,508,-260,241.04,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (454,2,'1786721560-TEST',1,335,1,-486,-2537,-588,241.04,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (455,2,'1786721560-TEST',1,336,2,-736,1568,-380,241.04,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (456,2,'1786721560-TEST',1,321,1,86,-1829,-557,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (457,2,'1786721560-TEST',1,323,1,-1285,1036,-224,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (458,2,'1786721560-TEST',1,324,2,1373,2569,-500,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (459,2,'1786721560-TEST',1,325,2,2181,1683,-298,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (460,2,'1786721560-TEST',1,326,1,-760,-2073,-588,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (461,2,'1786721560-TEST',1,327,1,-607,-478,-386,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (462,2,'1786721560-TEST',1,329,1,71,-1862,-565,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (463,2,'1786721560-TEST',1,330,1,-505,-1004,-345,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (464,2,'1786721560-TEST',1,331,2,377,-137,-372,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (465,2,'1786721560-TEST',1,332,2,1541,2110,-289,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (466,2,'1786721560-TEST',1,333,1,-1073,983,-242,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (467,2,'1786721560-TEST',1,334,2,1671,583,-260,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (468,2,'1786721560-TEST',1,335,1,-697,-2042,-588,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (469,2,'1786721560-TEST',1,336,2,-698,917,-404,246.07,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (470,2,'1786721560-TEST',1,321,1,-7,-1273,-486,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (471,2,'1786721560-TEST',1,323,1,-1160,1076,-78,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (472,2,'1786721560-TEST',1,324,2,846,2224,-492,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (473,2,'1786721560-TEST',1,325,2,2011,1104,-320,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (474,2,'1786721560-TEST',1,326,1,-759,-1363,-498,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (475,2,'1786721560-TEST',1,327,1,-139,-67,-420,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (476,2,'1786721560-TEST',1,329,1,35,-1070,-415,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (477,2,'1786721560-TEST',1,330,1,-505,-1002,-333,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (478,2,'1786721560-TEST',1,331,2,69,-259,-292,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (479,2,'1786721560-TEST',1,332,2,956,1723,-231,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (480,2,'1786721560-TEST',1,333,1,-1234,1033,-224,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (481,2,'1786721560-TEST',1,334,2,1165,870,-364,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (482,2,'1786721560-TEST',1,335,1,-508,-1302,-504,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (483,2,'1786721560-TEST',1,336,2,-698,917,-404,251,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (484,2,'1786721560-TEST',1,321,1,201,-508,-412,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (485,2,'1786721560-TEST',1,323,1,-1182,1060,-192,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (486,2,'1786721560-TEST',1,324,2,487,1905,-364,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (487,2,'1786721560-TEST',1,325,2,1519,743,-311,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (488,2,'1786721560-TEST',1,326,1,-1087,-971,-382,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (489,2,'1786721560-TEST',1,327,1,390,-297,-372,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (490,2,'1786721560-TEST',1,329,1,202,-324,-412,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (491,2,'1786721560-TEST',1,330,1,-504,-956,-310,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (492,2,'1786721560-TEST',1,331,2,9,0,-420,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (493,2,'1786721560-TEST',1,332,2,795,1442,-234,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (494,2,'1786721560-TEST',1,333,1,-1276,862,-192,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (495,2,'1786721560-TEST',1,334,2,868,828,-383,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (496,2,'1786721560-TEST',1,335,1,-504,-1002,-336,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (497,2,'1786721560-TEST',1,336,2,-698,917,-404,256.03,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (498,2,'1786721560-TEST',1,321,1,53,-174,-430,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (499,2,'1786721560-TEST',1,322,2,2293,2893,-508,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (500,2,'1786721560-TEST',1,323,1,-1298,1011,-224,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (501,2,'1786721560-TEST',1,324,2,217,1266,-364,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (502,2,'1786721560-TEST',1,325,2,1474,7,-348,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (503,2,'1786721560-TEST',1,326,1,-519,-538,-360,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (504,2,'1786721560-TEST',1,327,1,1044,-282,-332,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (505,2,'1786721560-TEST',1,328,2,2227,2953,-508,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (506,2,'1786721560-TEST',1,329,1,-107,103,-435,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (507,2,'1786721560-TEST',1,330,1,-463,-379,-372,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (508,2,'1786721560-TEST',1,331,2,-663,762,-403,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (509,2,'1786721560-TEST',1,332,2,819,1316,-242,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (510,2,'1786721560-TEST',1,333,1,-1276,860,-212,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (511,2,'1786721560-TEST',1,334,2,75,826,-372,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (512,2,'1786721560-TEST',1,335,1,-496,-1009,-364,261.06,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (513,2,'1786721560-TEST',1,321,1,-320,321,-404,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (514,2,'1786721560-TEST',1,322,2,1505,2621,-500,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (515,2,'1786721560-TEST',1,323,1,-1276,866,-188,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (516,2,'1786721560-TEST',1,324,2,284,1080,-368,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (517,2,'1786721560-TEST',1,325,2,1474,7,-348,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (518,2,'1786721560-TEST',1,326,1,-153,106,-417,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (519,2,'1786721560-TEST',1,328,2,1543,2472,-470,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (520,2,'1786721560-TEST',1,329,1,-26,258,-392,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (521,2,'1786721560-TEST',1,330,1,206,-24,-392,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (522,2,'1786721560-TEST',1,332,2,676,1575,-281,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (523,2,'1786721560-TEST',1,333,1,-774,889,-404,266,'2026-08-14 16:45:01','2026-08-14 16:45:01');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (524,2,'1786721560-TEST',1,334,2,10,808,-390,266,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (525,2,'1786721560-TEST',1,335,1,-504,-1002,-315,266,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (526,2,'1786721560-TEST',1,321,1,-525,522,-404,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (527,2,'1786721560-TEST',1,322,2,939,2221,-492,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (528,2,'1786721560-TEST',1,323,1,-1187,611,-377,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (529,2,'1786721560-TEST',1,324,2,175,1048,-372,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (530,2,'1786721560-TEST',1,325,2,1474,7,-348,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (531,2,'1786721560-TEST',1,326,1,-13,584,-410,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (532,2,'1786721560-TEST',1,328,2,1391,1693,-252,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (533,2,'1786721560-TEST',1,330,1,879,-288,-349,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (534,2,'1786721560-TEST',1,332,2,83,1149,-372,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (535,2,'1786721560-TEST',1,333,1,-1072,905,-422,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (536,2,'1786721560-TEST',1,334,2,10,808,-390,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (537,2,'1786721560-TEST',1,335,1,-506,-1049,-483,271.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (538,2,'1786721560-TEST',1,321,1,-504,260,-414,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (539,2,'1786721560-TEST',1,322,2,482,1972,-382,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (540,2,'1786721560-TEST',1,323,1,-1078,531,-382,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (541,2,'1786721560-TEST',1,324,2,69,774,-390,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (542,2,'1786721560-TEST',1,326,1,-8,631,-410,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (543,2,'1786721560-TEST',1,327,1,53,-2617,-588,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (544,2,'1786721560-TEST',1,328,2,1098,1644,-257,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (545,2,'1786721560-TEST',1,329,1,-481,-2435,-588,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (546,2,'1786721560-TEST',1,330,1,1039,-284,-332,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (547,2,'1786721560-TEST',1,331,2,1859,3274,-496,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (548,2,'1786721560-TEST',1,333,1,-1072,915,-422,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (549,2,'1786721560-TEST',1,335,1,-504,-1002,-328,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (550,2,'1786721560-TEST',1,336,2,2319,3407,-492,276.06,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (551,2,'1786721560-TEST',1,321,1,-536,345,-414,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (552,2,'1786721560-TEST',1,322,2,-11,1450,-296,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (553,2,'1786721560-TEST',1,323,1,-1078,531,-382,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (554,2,'1786721560-TEST',1,324,2,68,848,-390,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (555,2,'1786721560-TEST',1,326,1,-63,448,-392,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (556,2,'1786721560-TEST',1,327,1,94,-1876,-568,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (557,2,'1786721560-TEST',1,328,2,1180,1569,-254,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (558,2,'1786721560-TEST',1,329,1,-708,-1990,-588,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (559,2,'1786721560-TEST',1,330,1,1039,-284,-332,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (560,2,'1786721560-TEST',1,331,2,1544,2490,-479,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (561,2,'1786721560-TEST',1,333,1,-1072,915,-422,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (562,2,'1786721560-TEST',1,335,1,-504,-1061,-519,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (563,2,'1786721560-TEST',1,336,2,2608,2869,-500,281,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (564,2,'1786721560-TEST',1,321,1,-357,254,-396,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (565,2,'1786721560-TEST',1,322,2,-275,1339,-264,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (566,2,'1786721560-TEST',1,323,1,-1029,289,-364,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (567,2,'1786721560-TEST',1,324,2,14,808,-390,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (568,2,'1786721560-TEST',1,325,2,2752,3120,-482,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (569,2,'1786721560-TEST',1,326,1,364,-42,-372,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (570,2,'1786721560-TEST',1,327,1,35,-1069,-414,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (571,2,'1786721560-TEST',1,328,2,1381,1019,-363,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (572,2,'1786721560-TEST',1,329,1,-502,-1137,-517,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (573,2,'1786721560-TEST',1,330,1,1039,-284,-332,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (574,2,'1786721560-TEST',1,331,2,1298,2020,-270,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (575,2,'1786721560-TEST',1,332,2,2560,3119,-482,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (576,2,'1786721560-TEST',1,333,1,-985,872,-404,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (577,2,'1786721560-TEST',1,334,2,2064,3504,-474,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (578,2,'1786721560-TEST',1,335,1,-504,-1002,-315,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (579,2,'1786721560-TEST',1,336,2,2554,2026,-380,286.03,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (580,2,'1786721560-TEST',1,322,2,-275,1339,-264,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (581,2,'1786721560-TEST',1,323,1,-779,229,-382,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (582,2,'1786721560-TEST',1,324,2,-10,804,-390,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (583,2,'1786721560-TEST',1,325,2,2119,2920,-508,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (584,2,'1786721560-TEST',1,326,1,1007,-273,-332,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (585,2,'1786721560-TEST',1,327,1,171,-338,-412,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (586,2,'1786721560-TEST',1,328,2,1471,515,-372,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (587,2,'1786721560-TEST',1,329,1,-505,-1002,-356,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (588,2,'1786721560-TEST',1,330,1,1039,-284,-332,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (589,2,'1786721560-TEST',1,331,2,1342,1848,-252,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (590,2,'1786721560-TEST',1,332,2,2073,2899,-508,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (591,2,'1786721560-TEST',1,333,1,-292,288,-404,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (592,2,'1786721560-TEST',1,334,2,1728,2997,-501,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (593,2,'1786721560-TEST',1,335,1,-504,-1002,-320,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (594,2,'1786721560-TEST',1,336,2,2188,1415,-220,291.07,'2026-08-14 16:45:02','2026-08-14 16:45:02');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (595,2,'1786721560-TEST',1,322,2,-601,1005,-404,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (596,2,'1786721560-TEST',1,323,1,-345,264,-400,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (597,2,'1786721560-TEST',1,324,2,-11,783,-390,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (598,2,'1786721560-TEST',1,325,2,1398,2598,-500,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (599,2,'1786721560-TEST',1,326,1,1007,-273,-350,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (600,2,'1786721560-TEST',1,327,1,413,-207,-372,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (601,2,'1786721560-TEST',1,328,2,1607,-184,-356,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (602,2,'1786721560-TEST',1,329,1,-506,-1063,-520,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (603,2,'1786721560-TEST',1,330,1,1039,-284,-350,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (604,2,'1786721560-TEST',1,331,2,1382,967,-366,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (605,2,'1786721560-TEST',1,332,2,1536,2303,-386,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (606,2,'1786721560-TEST',1,333,1,385,-62,-372,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (607,2,'1786721560-TEST',1,334,2,1541,2236,-352,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (608,2,'1786721560-TEST',1,335,1,-536,-523,-362,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (609,2,'1786721560-TEST',1,336,2,1884,1132,-338,296,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (610,2,'1786721560-TEST',1,322,2,-699,920,-404,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (611,2,'1786721560-TEST',1,323,1,-479,485,-404,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (612,2,'1786721560-TEST',1,324,2,-11,729,-400,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (613,2,'1786721560-TEST',1,325,2,852,2223,-492,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (614,2,'1786721560-TEST',1,326,1,1072,-254,-340,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (615,2,'1786721560-TEST',1,327,1,491,-347,-372,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (616,2,'1786721560-TEST',1,328,2,1175,-264,-354,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (617,2,'1786721560-TEST',1,329,1,-504,-1002,-333,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (618,2,'1786721560-TEST',1,331,2,967,882,-382,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (619,2,'1786721560-TEST',1,332,2,1243,1614,-252,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (620,2,'1786721560-TEST',1,333,1,459,-337,-372,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (621,2,'1786721560-TEST',1,334,2,1378,1194,-270,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (622,2,'1786721560-TEST',1,335,1,-176,-103,-420,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (623,2,'1786721560-TEST',1,336,2,1884,1132,-338,301.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (624,2,'1786721560-TEST',1,321,1,89,-2112,-588,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (625,2,'1786721560-TEST',1,322,2,-699,920,-404,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (626,2,'1786721560-TEST',1,325,2,477,1880,-364,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (627,2,'1786721560-TEST',1,327,1,491,-347,-390,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (628,2,'1786721560-TEST',1,329,1,-506,-1067,-499,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (629,2,'1786721560-TEST',1,330,1,-765,-2074,-583,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (630,2,'1786721560-TEST',1,331,2,700,808,-367,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (631,2,'1786721560-TEST',1,332,2,627,1185,-307,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (632,2,'1786721560-TEST',1,333,1,459,-337,-372,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (633,2,'1786721560-TEST',1,334,2,1524,401,-372,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (634,2,'1786721560-TEST',1,335,1,393,-319,-372,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (635,2,'1786721560-TEST',1,336,2,1898,1095,-320,306.06,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (636,2,'1786721560-TEST',1,321,1,9,-1208,-463,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (637,2,'1786721560-TEST',1,322,2,-699,920,-404,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (638,2,'1786721560-TEST',1,325,2,-7,1420,-276,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (639,2,'1786721560-TEST',1,327,1,932,-265,-357,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (640,2,'1786721560-TEST',1,329,1,-504,-1002,-318,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (641,2,'1786721560-TEST',1,330,1,-720,-1776,-576,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (642,2,'1786721560-TEST',1,331,2,56,822,-390,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (643,2,'1786721560-TEST',1,332,2,-278,1157,-404,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (644,2,'1786721560-TEST',1,333,1,900,-268,-345,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (645,2,'1786721560-TEST',1,334,2,1555,-190,-356,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (646,2,'1786721560-TEST',1,335,1,861,-291,-370,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (647,2,'1786721560-TEST',1,336,2,1424,1040,-338,311,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (648,2,'1786721560-TEST',1,321,1,238,-457,-412,316.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (649,2,'1786721560-TEST',1,322,2,-699,920,-404,316.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (650,2,'1786721560-TEST',1,323,1,20,-2613,-588,316.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (651,2,'1786721560-TEST',1,324,2,2668,2882,-500,316.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (652,2,'1786721560-TEST',1,325,2,-319,1343,-347,316.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (653,2,'1786721560-TEST',1,326,1,-150,-2502,-588,316.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (654,2,'1786721560-TEST',1,327,1,1180,-278,-354,316.03,'2026-08-14 16:45:03','2026-08-14 16:45:03');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (655,2,'1786721560-TEST',1,328,2,2636,2860,-500,316.03,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (656,2,'1786721560-TEST',1,329,1,-505,-1028,-415,316.03,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (657,2,'1786721560-TEST',1,330,1,-505,-1063,-487,316.03,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (658,2,'1786721560-TEST',1,331,2,24,808,-390,316.03,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (659,2,'1786721560-TEST',1,332,2,-714,952,-404,316.03,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (660,2,'1786721560-TEST',1,333,1,1317,-156,-349,316.03,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (661,2,'1786721560-TEST',1,334,2,2070,3308,-492,316.03,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (662,2,'1786721560-TEST',1,335,1,1055,-241,-350,316.03,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (663,2,'1786721560-TEST',1,336,2,1418,1040,-354,316.03,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (664,2,'1786721560-TEST',1,321,1,-35,275,-392,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (665,2,'1786721560-TEST',1,322,2,-699,920,-422,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (666,2,'1786721560-TEST',1,323,1,-736,-2206,-603,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (667,2,'1786721560-TEST',1,324,2,1856,2789,-500,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (668,2,'1786721560-TEST',1,325,2,-374,1320,-422,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (669,2,'1786721560-TEST',1,326,1,57,-1678,-522,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (670,2,'1786721560-TEST',1,327,1,698,-323,-372,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (671,2,'1786721560-TEST',1,328,2,2701,2295,-397,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (672,2,'1786721560-TEST',1,329,1,-529,-438,-372,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (673,2,'1786721560-TEST',1,330,1,-504,-1002,-336,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (674,2,'1786721560-TEST',1,331,2,-70,1130,-372,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (675,2,'1786721560-TEST',1,332,2,-646,899,-397,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (676,2,'1786721560-TEST',1,333,1,1364,-105,-353,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (677,2,'1786721560-TEST',1,334,2,1565,2646,-500,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (678,2,'1786721560-TEST',1,335,1,773,16,-468,321.06,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (679,2,'1786721560-TEST',1,321,1,-11,732,-400,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (680,2,'1786721560-TEST',1,322,2,-638,897,-396,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (681,2,'1786721560-TEST',1,323,1,-733,-1946,-555,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (682,2,'1786721560-TEST',1,324,2,1325,2355,-492,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (683,2,'1786721560-TEST',1,325,2,21,1117,-372,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (684,2,'1786721560-TEST',1,326,1,68,-891,-390,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (685,2,'1786721560-TEST',1,327,1,61,-54,-420,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (686,2,'1786721560-TEST',1,328,2,2205,1751,-330,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (687,2,'1786721560-TEST',1,329,1,-146,74,-438,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (688,2,'1786721560-TEST',1,330,1,-506,-1056,-493,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (689,2,'1786721560-TEST',1,331,2,-560,1656,-396,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (690,2,'1786721560-TEST',1,332,2,-588,688,-422,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (691,2,'1786721560-TEST',1,333,1,1364,-105,-353,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (692,2,'1786721560-TEST',1,334,2,1484,1859,-252,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (693,2,'1786721560-TEST',1,335,1,877,373,-497,326.09,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (694,2,'1786721560-TEST',1,321,1,0,820,-390,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (695,2,'1786721560-TEST',1,322,2,-536,1266,-404,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (696,2,'1786721560-TEST',1,323,1,-505,-1210,-511,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (697,2,'1786721560-TEST',1,324,2,615,2284,-460,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (698,2,'1786721560-TEST',1,325,2,668,802,-372,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (699,2,'1786721560-TEST',1,326,1,139,-188,-412,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (700,2,'1786721560-TEST',1,327,1,70,-176,-272,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (701,2,'1786721560-TEST',1,328,2,2024,1080,-320,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (702,2,'1786721560-TEST',1,329,1,-10,610,-410,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (703,2,'1786721560-TEST',1,330,1,-505,-1002,-312,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (704,2,'1786721560-TEST',1,331,2,-1310,1638,-380,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (705,2,'1786721560-TEST',1,332,2,-588,688,-422,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (706,2,'1786721560-TEST',1,333,1,1364,-105,-353,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (707,2,'1786721560-TEST',1,334,2,1458,1812,-252,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (708,2,'1786721560-TEST',1,335,1,431,711,-484,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (709,2,'1786721560-TEST',1,336,2,2676,3030,-500,331.02,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (710,2,'1786721560-TEST',1,321,1,430,817,-372,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (711,2,'1786721560-TEST',1,322,2,-1043,1163,-380,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (712,2,'1786721560-TEST',1,323,1,-505,-1002,-339,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (713,2,'1786721560-TEST',1,324,2,366,1729,-360,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (714,2,'1786721560-TEST',1,326,1,-31,35,-420,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (715,2,'1786721560-TEST',1,327,1,70,-176,-272,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (716,2,'1786721560-TEST',1,328,2,1363,1043,-353,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (717,2,'1786721560-TEST',1,329,1,-8,702,-405,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (718,2,'1786721560-TEST',1,330,1,-502,-1053,-483,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (719,2,'1786721560-TEST',1,331,2,-1383,1393,-392,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (720,2,'1786721560-TEST',1,333,1,1364,-105,-353,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (721,2,'1786721560-TEST',1,334,2,1458,1812,-252,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (722,2,'1786721560-TEST',1,335,1,73,824,-372,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (723,2,'1786721560-TEST',1,336,2,1933,2829,-508,336.05,'2026-08-14 16:45:04','2026-08-14 16:45:04');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (724,2,'1786721560-TEST',1,321,1,-191,1140,-374,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (725,2,'1786721560-TEST',1,322,2,-1128,1217,-380,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (726,2,'1786721560-TEST',1,323,1,-540,-597,-352,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (727,2,'1786721560-TEST',1,324,2,156,1073,-372,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (728,2,'1786721560-TEST',1,326,1,-12,692,-406,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (729,2,'1786721560-TEST',1,327,1,70,-176,-272,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (730,2,'1786721560-TEST',1,328,2,1417,1003,-352,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (731,2,'1786721560-TEST',1,329,1,-587,671,-422,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (732,2,'1786721560-TEST',1,330,1,-504,-1002,-340,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (733,2,'1786721560-TEST',1,331,2,-1358,1597,-378,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (734,2,'1786721560-TEST',1,334,2,1364,1757,-252,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (735,2,'1786721560-TEST',1,335,1,-233,1145,-392,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (736,2,'1786721560-TEST',1,336,2,1539,2220,-344,341.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (737,2,'1786721560-TEST',1,321,1,-689,925,-404,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (738,2,'1786721560-TEST',1,322,2,-1184,1284,-391,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (739,2,'1786721560-TEST',1,323,1,-152,58,-420,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (740,2,'1786721560-TEST',1,326,1,-2,791,-390,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (741,2,'1786721560-TEST',1,327,1,70,-176,-272,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (742,2,'1786721560-TEST',1,328,2,1008,900,-382,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (743,2,'1786721560-TEST',1,329,1,-585,673,-422,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (744,2,'1786721560-TEST',1,330,1,-505,-1040,-444,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (745,2,'1786721560-TEST',1,331,2,-932,1625,-398,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (746,2,'1786721560-TEST',1,334,2,766,1169,-281,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (747,2,'1786721560-TEST',1,335,1,-721,934,-404,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (748,2,'1786721560-TEST',1,336,2,1440,1429,-252,346.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (749,2,'1786721560-TEST',1,321,1,-635,694,-404,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (750,2,'1786721560-TEST',1,322,2,-1292,1214,-388,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (751,2,'1786721560-TEST',1,323,1,-458,260,-414,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (752,2,'1786721560-TEST',1,324,2,2696,2871,-500,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (753,2,'1786721560-TEST',1,325,2,2555,2899,-500,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (754,2,'1786721560-TEST',1,327,1,92,-35,-415,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (755,2,'1786721560-TEST',1,329,1,-40,596,-392,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (756,2,'1786721560-TEST',1,330,1,-504,-1002,-337,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (757,2,'1786721560-TEST',1,331,2,-523,1265,-422,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (758,2,'1786721560-TEST',1,332,2,1852,3273,-496,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (759,2,'1786721560-TEST',1,334,2,180,1031,-372,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (760,2,'1786721560-TEST',1,335,1,-451,926,-404,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (761,2,'1786721560-TEST',1,336,2,1098,907,-364,351.05,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (762,2,'1786721560-TEST',1,321,1,-459,816,-388,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (763,2,'1786721560-TEST',1,322,2,-1375,868,-230,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (764,2,'1786721560-TEST',1,323,1,-458,260,-414,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (765,2,'1786721560-TEST',1,324,2,2476,1964,-380,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (766,2,'1786721560-TEST',1,325,2,1738,2725,-500,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (767,2,'1786721560-TEST',1,326,1,34,-2673,-588,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (768,2,'1786721560-TEST',1,327,1,628,-337,-372,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (769,2,'1786721560-TEST',1,329,1,16,825,-390,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (770,2,'1786721560-TEST',1,330,1,-505,-1028,-411,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (771,2,'1786721560-TEST',1,331,2,-623,971,-404,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (772,2,'1786721560-TEST',1,332,2,1353,2518,-500,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (773,2,'1786721560-TEST',1,333,1,-759,-2163,-630,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (774,2,'1786721560-TEST',1,334,2,145,704,-456,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (775,2,'1786721560-TEST',1,336,2,858,828,-390,356.09,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (776,2,'1786721560-TEST',1,321,1,-437,708,-382,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (777,2,'1786721560-TEST',1,322,2,-1111,828,-404,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (778,2,'1786721560-TEST',1,323,1,-458,260,-414,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (779,2,'1786721560-TEST',1,324,2,2172,1314,-224,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (780,2,'1786721560-TEST',1,325,2,1538,2027,-252,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (781,2,'1786721560-TEST',1,326,1,-687,-2304,-588,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (782,2,'1786721560-TEST',1,327,1,923,-188,-341,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (783,2,'1786721560-TEST',1,330,1,-503,-1002,-312,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (784,2,'1786721560-TEST',1,331,2,-697,916,-404,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (785,2,'1786721560-TEST',1,332,2,769,2241,-486,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (786,2,'1786721560-TEST',1,333,1,-677,-1638,-542,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (787,2,'1786721560-TEST',1,334,2,844,525,-468,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (788,2,'1786721560-TEST',1,336,2,349,829,-372,361.02,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (789,2,'1786721560-TEST',1,321,1,-518,816,-366,366.06,'2026-08-14 16:45:05','2026-08-14 16:45:05');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (790,2,'1786721560-TEST',1,322,2,-802,535,-375,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (791,2,'1786721560-TEST',1,323,1,-458,260,-414,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (792,2,'1786721560-TEST',1,324,2,1608,1032,-320,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (793,2,'1786721560-TEST',1,325,2,1381,1214,-258,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (794,2,'1786721560-TEST',1,326,1,-740,-2033,-562,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (795,2,'1786721560-TEST',1,327,1,572,-347,-372,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (796,2,'1786721560-TEST',1,328,2,2709,2520,-452,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (797,2,'1786721560-TEST',1,329,1,32,-2719,-576,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (798,2,'1786721560-TEST',1,330,1,-505,-1018,-393,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (799,2,'1786721560-TEST',1,332,2,401,1858,-364,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (800,2,'1786721560-TEST',1,333,1,-505,-1068,-495,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (801,2,'1786721560-TEST',1,334,2,875,321,-518,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (802,2,'1786721560-TEST',1,335,1,-288,-2528,-584,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (803,2,'1786721560-TEST',1,336,2,56,823,-390,366.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (804,2,'1786721560-TEST',1,321,1,-492,488,-404,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (805,2,'1786721560-TEST',1,322,2,-784,544,-382,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (806,2,'1786721560-TEST',1,323,1,-458,260,-414,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (807,2,'1786721560-TEST',1,324,2,1149,761,-364,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (808,2,'1786721560-TEST',1,325,2,1552,344,-372,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (809,2,'1786721560-TEST',1,326,1,-506,-1268,-506,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (810,2,'1786721560-TEST',1,327,1,53,-37,-420,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (811,2,'1786721560-TEST',1,328,2,2283,1861,-377,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (812,2,'1786721560-TEST',1,329,1,-660,-2328,-588,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (813,2,'1786721560-TEST',1,330,1,-505,-953,-292,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (814,2,'1786721560-TEST',1,332,2,-52,1338,-276,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (815,2,'1786721560-TEST',1,333,1,-504,-1002,-340,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (816,2,'1786721560-TEST',1,334,2,879,111,-518,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (817,2,'1786721560-TEST',1,335,1,91,-1858,-564,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (818,2,'1786721560-TEST',1,336,2,24,808,-390,371,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (819,2,'1786721560-TEST',1,321,1,-389,275,-404,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (820,2,'1786721560-TEST',1,322,2,-1229,505,-372,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (821,2,'1786721560-TEST',1,323,1,-428,237,-396,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (822,2,'1786721560-TEST',1,324,2,1163,808,-364,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (823,2,'1786721560-TEST',1,325,2,1542,-186,-356,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (824,2,'1786721560-TEST',1,326,1,-505,-1002,-331,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (825,2,'1786721560-TEST',1,327,1,-553,223,-396,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (826,2,'1786721560-TEST',1,328,2,1874,1382,-220,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (827,2,'1786721560-TEST',1,329,1,-641,-1579,-527,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (828,2,'1786721560-TEST',1,330,1,-336,-252,-372,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (829,2,'1786721560-TEST',1,332,2,-355,1351,-383,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (830,2,'1786721560-TEST',1,333,1,-486,-1045,-471,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (831,2,'1786721560-TEST',1,334,2,878,168,-518,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (832,2,'1786721560-TEST',1,335,1,32,-1051,-408,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (833,2,'1786721560-TEST',1,336,2,71,712,-411,376.03,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (834,2,'1786721560-TEST',1,321,1,-389,275,-404,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (835,2,'1786721560-TEST',1,322,2,-907,878,-404,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (836,2,'1786721560-TEST',1,323,1,-427,237,-414,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (837,2,'1786721560-TEST',1,324,2,1613,754,-266,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (838,2,'1786721560-TEST',1,325,2,1172,-273,-336,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (839,2,'1786721560-TEST',1,326,1,-539,-598,-352,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (840,2,'1786721560-TEST',1,327,1,-829,241,-382,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (841,2,'1786721560-TEST',1,328,2,1112,1511,-257,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (842,2,'1786721560-TEST',1,329,1,-505,-1025,-400,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (843,2,'1786721560-TEST',1,330,1,207,-325,-412,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (844,2,'1786721560-TEST',1,331,2,2693,2577,-466,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (845,2,'1786721560-TEST',1,332,2,-618,987,-404,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (846,2,'1786721560-TEST',1,333,1,-505,-1002,-314,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (847,2,'1786721560-TEST',1,334,2,878,369,-495,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (848,2,'1786721560-TEST',1,335,1,207,-357,-412,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (849,2,'1786721560-TEST',1,336,2,679,540,-484,381.06,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (850,2,'1786721560-TEST',1,321,1,-389,275,-404,386.09,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (851,2,'1786721560-TEST',1,322,2,-731,917,-404,386.09,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (852,2,'1786721560-TEST',1,323,1,-288,244,-422,386.09,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (853,2,'1786721560-TEST',1,324,2,1671,508,-260,386.09,'2026-08-14 16:45:06','2026-08-14 16:45:06');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (854,2,'1786721560-TEST',1,325,2,1172,-273,-336,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (855,2,'1786721560-TEST',1,326,1,-251,-175,-390,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (856,2,'1786721560-TEST',1,327,1,-1029,313,-364,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (857,2,'1786721560-TEST',1,328,2,380,1190,-351,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (858,2,'1786721560-TEST',1,329,1,-504,-1002,-335,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (859,2,'1786721560-TEST',1,330,1,222,-413,-412,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (860,2,'1786721560-TEST',1,332,2,-699,920,-404,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (861,2,'1786721560-TEST',1,333,1,-504,-950,-350,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (862,2,'1786721560-TEST',1,334,2,852,220,-484,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (863,2,'1786721560-TEST',1,335,1,237,-233,-412,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (864,2,'1786721560-TEST',1,336,2,875,328,-486,386.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (865,2,'1786721560-TEST',1,321,1,-389,275,-404,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (866,2,'1786721560-TEST',1,322,2,-731,917,-422,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (867,2,'1786721560-TEST',1,323,1,-359,352,-404,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (868,2,'1786721560-TEST',1,324,2,1671,508,-260,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (869,2,'1786721560-TEST',1,325,2,1172,-273,-336,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (870,2,'1786721560-TEST',1,326,1,-219,-80,-433,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (871,2,'1786721560-TEST',1,327,1,-1029,313,-382,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (872,2,'1786721560-TEST',1,328,2,-420,1153,-404,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (873,2,'1786721560-TEST',1,329,1,-505,-1027,-407,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (874,2,'1786721560-TEST',1,330,1,376,-45,-372,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (875,2,'1786721560-TEST',1,332,2,-699,920,-404,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (876,2,'1786721560-TEST',1,333,1,-402,-313,-372,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (877,2,'1786721560-TEST',1,334,2,1043,-286,-332,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (878,2,'1786721560-TEST',1,335,1,404,-272,-372,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (879,2,'1786721560-TEST',1,336,2,875,250,-518,391.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (880,2,'1786721560-TEST',1,321,1,-389,275,-404,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (881,2,'1786721560-TEST',1,322,2,-229,1176,-390,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (882,2,'1786721560-TEST',1,323,1,-646,696,-404,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (883,2,'1786721560-TEST',1,324,2,1366,734,-372,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (884,2,'1786721560-TEST',1,326,1,-52,300,-392,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (885,2,'1786721560-TEST',1,327,1,-1135,437,-364,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (886,2,'1786721560-TEST',1,328,2,-544,1078,-396,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (887,2,'1786721560-TEST',1,329,1,-503,-1002,-321,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (888,2,'1786721560-TEST',1,330,1,793,-317,-366,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (889,2,'1786721560-TEST',1,331,2,2579,2941,-500,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (890,2,'1786721560-TEST',1,332,2,2690,2903,-500,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (891,2,'1786721560-TEST',1,333,1,-87,366,-392,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (892,2,'1786721560-TEST',1,334,2,1998,3324,-492,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (893,2,'1786721560-TEST',1,335,1,954,-268,-332,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (894,2,'1786721560-TEST',1,336,2,877,332,-518,396.06,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (895,2,'1786721560-TEST',1,321,1,-389,275,-404,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (896,2,'1786721560-TEST',1,322,2,454,800,-372,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (897,2,'1786721560-TEST',1,323,1,-649,703,-404,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (898,2,'1786721560-TEST',1,324,2,952,862,-382,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (899,2,'1786721560-TEST',1,326,1,-12,708,-404,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (900,2,'1786721560-TEST',1,327,1,-1190,641,-399,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (901,2,'1786721560-TEST',1,328,2,-698,923,-422,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (902,2,'1786721560-TEST',1,329,1,-505,-1002,-330,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (903,2,'1786721560-TEST',1,330,1,1014,-277,-332,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (904,2,'1786721560-TEST',1,331,2,1774,2745,-500,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (905,2,'1786721560-TEST',1,332,2,2645,2107,-380,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (906,2,'1786721560-TEST',1,333,1,0,743,-398,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (907,2,'1786721560-TEST',1,334,2,1536,2530,-499,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (908,2,'1786721560-TEST',1,335,1,1046,-278,-332,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (909,2,'1786721560-TEST',1,336,2,521,681,-484,401.09,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (910,2,'1786721560-TEST',1,321,1,-389,275,-404,406.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (911,2,'1786721560-TEST',1,322,2,559,756,-372,406.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (912,2,'1786721560-TEST',1,323,1,-657,769,-399,406.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (913,2,'1786721560-TEST',1,324,2,904,857,-382,406.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (914,2,'1786721560-TEST',1,325,2,2064,3600,-474,406.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (915,2,'1786721560-TEST',1,326,1,-52,246,-392,406.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (916,2,'1786721560-TEST',1,327,1,-766,911,-404,406.03,'2026-08-14 16:45:07','2026-08-14 16:45:07');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (917,2,'1786721560-TEST',1,328,2,2064,3312,-474,406.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (918,2,'1786721560-TEST',1,329,1,-504,-1002,-313,406.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (919,2,'1786721560-TEST',1,330,1,940,-286,-333,406.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (920,2,'1786721560-TEST',1,331,2,1293,2244,-492,406.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (921,2,'1786721560-TEST',1,332,2,2182,1496,-220,406.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (922,2,'1786721560-TEST',1,333,1,-6,802,-390,406.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (923,2,'1786721560-TEST',1,334,2,1426,1761,-252,406.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (924,2,'1786721560-TEST',1,335,1,918,-227,-342,406.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (925,2,'1786721560-TEST',1,336,2,80,709,-420,406.03,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (926,2,'1786721560-TEST',1,321,1,-473,490,-404,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (927,2,'1786721560-TEST',1,322,2,559,756,-372,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (928,2,'1786721560-TEST',1,323,1,-657,769,-399,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (929,2,'1786721560-TEST',1,324,2,904,857,-382,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (930,2,'1786721560-TEST',1,325,2,2596,3224,-420,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (931,2,'1786721560-TEST',1,326,1,404,-98,-372,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (932,2,'1786721560-TEST',1,327,1,914,-186,-342,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (933,2,'1786721560-TEST',1,328,2,1627,2774,-500,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (934,2,'1786721560-TEST',1,329,1,-504,-1002,-350,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (935,2,'1786721560-TEST',1,330,1,370,-113,-372,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (936,2,'1786721560-TEST',1,331,2,515,2287,-460,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (937,2,'1786721560-TEST',1,332,2,1695,1060,-320,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (938,2,'1786721560-TEST',1,334,2,806,1171,-271,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (939,2,'1786721560-TEST',1,335,1,914,-186,-342,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (940,2,'1786721560-TEST',1,336,2,-5,739,-399,411.06,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (941,2,'1786721560-TEST',1,321,1,-655,736,-404,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (942,2,'1786721560-TEST',1,322,2,71,825,-372,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (943,2,'1786721560-TEST',1,323,1,-657,769,-399,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (944,2,'1786721560-TEST',1,324,2,904,810,-358,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (945,2,'1786721560-TEST',1,325,2,2697,2484,-443,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (946,2,'1786721560-TEST',1,326,1,972,-270,-332,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (947,2,'1786721560-TEST',1,327,1,890,-191,-347,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (948,2,'1786721560-TEST',1,328,2,1493,1881,-252,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (949,2,'1786721560-TEST',1,329,1,-867,-961,-467,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (950,2,'1786721560-TEST',1,330,1,-109,105,-417,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (951,2,'1786721560-TEST',1,331,2,287,1657,-360,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (952,2,'1786721560-TEST',1,332,2,1240,869,-364,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (953,2,'1786721560-TEST',1,334,2,-4,1182,-372,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (954,2,'1786721560-TEST',1,335,1,849,-201,-276,416.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (955,2,'1786721560-TEST',1,321,1,-655,736,-422,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (956,2,'1786721560-TEST',1,322,2,40,808,-390,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (957,2,'1786721560-TEST',1,323,1,-657,769,-416,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (958,2,'1786721560-TEST',1,324,2,910,837,-382,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (959,2,'1786721560-TEST',1,325,2,2313,1876,-376,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (960,2,'1786721560-TEST',1,326,1,712,-134,-384,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (961,2,'1786721560-TEST',1,327,1,875,-194,-336,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (962,2,'1786721560-TEST',1,328,2,971,1309,-262,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (963,2,'1786721560-TEST',1,329,1,-1273,-553,-390,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (964,2,'1786721560-TEST',1,330,1,-655,704,-404,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (965,2,'1786721560-TEST',1,331,2,296,1324,-364,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (966,2,'1786721560-TEST',1,333,1,32,-2720,-575,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (967,2,'1786721560-TEST',1,334,2,-396,1155,-404,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (968,2,'1786721560-TEST',1,335,1,809,-162,-500,421.02,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (969,2,'1786721560-TEST',1,321,1,-581,734,-411,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (970,2,'1786721560-TEST',1,322,2,67,803,-329,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (971,2,'1786721560-TEST',1,323,1,-604,850,-358,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (972,2,'1786721560-TEST',1,324,2,904,854,-382,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (973,2,'1786721560-TEST',1,325,2,2090,1137,-312,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (974,2,'1786721560-TEST',1,326,1,876,-92,-518,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (975,2,'1786721560-TEST',1,327,1,391,-62,-372,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (976,2,'1786721560-TEST',1,328,2,173,1015,-372,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (977,2,'1786721560-TEST',1,329,1,-1289,-578,-390,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (978,2,'1786721560-TEST',1,331,2,-364,1154,-422,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (979,2,'1786721560-TEST',1,333,1,-649,-2336,-588,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (980,2,'1786721560-TEST',1,334,2,-396,1155,-422,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (981,2,'1786721560-TEST',1,335,1,809,-162,-500,426.05,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (982,2,'1786721560-TEST',1,321,1,-581,734,-411,431.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (983,2,'1786721560-TEST',1,322,2,311,713,-484,431.09,'2026-08-14 16:45:08','2026-08-14 16:45:08');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (984,2,'1786721560-TEST',1,324,2,904,811,-382,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (985,2,'1786721560-TEST',1,325,2,1584,748,-276,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (986,2,'1786721560-TEST',1,326,1,873,122,-500,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (987,2,'1786721560-TEST',1,327,1,-282,280,-404,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (988,2,'1786721560-TEST',1,328,2,160,707,-458,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (989,2,'1786721560-TEST',1,329,1,-1517,-206,-364,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (990,2,'1786721560-TEST',1,331,2,-583,1088,-396,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (991,2,'1786721560-TEST',1,332,2,2504,2841,-500,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (992,2,'1786721560-TEST',1,333,1,-733,-1562,-523,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (993,2,'1786721560-TEST',1,334,2,-396,1155,-404,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (994,2,'1786721560-TEST',1,336,2,2696,2710,-498,431.09,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (995,2,'1786721560-TEST',1,322,2,857,515,-486,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (996,2,'1786721560-TEST',1,324,2,1172,838,-364,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (997,2,'1786721560-TEST',1,325,2,1219,359,-364,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (998,2,'1786721560-TEST',1,326,1,898,366,-518,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (999,2,'1786721560-TEST',1,327,1,-552,554,-422,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1000,2,'1786721560-TEST',1,328,2,825,518,-468,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1001,2,'1786721560-TEST',1,329,1,-1461,157,-382,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1002,2,'1786721560-TEST',1,331,2,-697,919,-422,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1003,2,'1786721560-TEST',1,332,2,1746,2729,-500,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1004,2,'1786721560-TEST',1,333,1,-916,-976,-439,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1005,2,'1786721560-TEST',1,334,2,-652,974,-422,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1006,2,'1786721560-TEST',1,336,2,2508,1989,-380,436.02,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1007,2,'1786721560-TEST',1,321,1,-67,-2479,-588,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1008,2,'1786721560-TEST',1,323,1,-554,-2379,-588,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1009,2,'1786721560-TEST',1,324,2,1172,760,-364,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1010,2,'1786721560-TEST',1,325,2,1122,888,-364,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1011,2,'1786721560-TEST',1,326,1,898,366,-518,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1012,2,'1786721560-TEST',1,327,1,-591,-2372,-588,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1013,2,'1786721560-TEST',1,329,1,-1461,157,-382,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1014,2,'1786721560-TEST',1,330,1,-602,-2408,-588,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1015,2,'1786721560-TEST',1,331,2,2315,1882,-394,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1016,2,'1786721560-TEST',1,332,2,1538,2026,-252,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1017,2,'1786721560-TEST',1,333,1,-945,-868,-368,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1018,2,'1786721560-TEST',1,334,2,-694,951,-404,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1019,2,'1786721560-TEST',1,335,1,-142,-2500,-588,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1020,2,'1786721560-TEST',1,336,2,2205,1766,-337,441.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1021,2,'1786721560-TEST',1,321,1,55,-1668,-520,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1022,2,'1786721560-TEST',1,323,1,-719,-1659,-547,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1023,2,'1786721560-TEST',1,324,2,1175,790,-364,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1024,2,'1786721560-TEST',1,325,2,846,828,-372,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1025,2,'1786721560-TEST',1,327,1,-724,-1625,-538,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1026,2,'1786721560-TEST',1,329,1,-1299,165,-364,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1027,2,'1786721560-TEST',1,330,1,-762,-2074,-594,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1028,2,'1786721560-TEST',1,331,2,2184,1384,-220,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1029,2,'1786721560-TEST',1,332,2,1731,1728,-270,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1030,2,'1786721560-TEST',1,333,1,-526,-488,-367,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1031,2,'1786721560-TEST',1,334,2,-694,951,-404,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1032,2,'1786721560-TEST',1,335,1,65,-1718,-531,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1033,2,'1786721560-TEST',1,336,2,1684,1410,-252,446.08,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1034,2,'1786721560-TEST',1,321,1,93,-875,-390,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1035,2,'1786721560-TEST',1,322,2,2678,3031,-500,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1036,2,'1786721560-TEST',1,323,1,-830,-991,-485,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1037,2,'1786721560-TEST',1,324,2,899,837,-382,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1038,2,'1786721560-TEST',1,325,2,56,822,-390,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1039,2,'1786721560-TEST',1,327,1,-896,-963,-452,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1040,2,'1786721560-TEST',1,328,2,2609,3015,-500,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1041,2,'1786721560-TEST',1,329,1,-922,648,-383,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1042,2,'1786721560-TEST',1,330,1,-531,-1426,-492,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1043,2,'1786721560-TEST',1,331,2,1656,1066,-320,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1044,2,'1786721560-TEST',1,332,2,1731,1728,-270,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1045,2,'1786721560-TEST',1,333,1,80,-64,-418,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1046,2,'1786721560-TEST',1,335,1,86,-926,-386,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1047,2,'1786721560-TEST',1,336,2,1002,1362,-261,451.01,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1048,2,'1786721560-TEST',1,321,1,149,-186,-412,456.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1049,2,'1786721560-TEST',1,322,2,2019,2874,-508,456.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1050,2,'1786721560-TEST',1,323,1,-1266,-452,-372,456.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1051,2,'1786721560-TEST',1,324,2,355,835,-372,456.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1052,2,'1786721560-TEST',1,325,2,25,808,-390,456.05,'2026-08-14 16:45:09','2026-08-14 16:45:09');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1053,2,'1786721560-TEST',1,326,1,32,-2719,-576,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1054,2,'1786721560-TEST',1,327,1,-1340,-456,-364,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1055,2,'1786721560-TEST',1,328,2,2643,2144,-380,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1056,2,'1786721560-TEST',1,329,1,-566,646,-422,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1057,2,'1786721560-TEST',1,330,1,-504,-1002,-316,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1058,2,'1786721560-TEST',1,331,2,1101,895,-364,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1059,2,'1786721560-TEST',1,332,2,976,1749,-233,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1060,2,'1786721560-TEST',1,333,1,297,-98,-390,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1061,2,'1786721560-TEST',1,335,1,151,-219,-412,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1062,2,'1786721560-TEST',1,336,2,93,1194,-372,456.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1063,2,'1786721560-TEST',1,321,1,-47,-343,-358,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1064,2,'1786721560-TEST',1,322,2,1540,2311,-389,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1065,2,'1786721560-TEST',1,323,1,-1208,369,-372,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1066,2,'1786721560-TEST',1,324,2,96,1477,-364,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1067,2,'1786721560-TEST',1,325,2,87,821,-390,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1068,2,'1786721560-TEST',1,326,1,102,-2008,-588,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1069,2,'1786721560-TEST',1,327,1,-1739,-176,-364,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1070,2,'1786721560-TEST',1,328,2,2178,1570,-237,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1071,2,'1786721560-TEST',1,329,1,-693,823,-393,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1072,2,'1786721560-TEST',1,330,1,-506,-1002,-345,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1073,2,'1786721560-TEST',1,331,2,851,832,-390,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1074,2,'1786721560-TEST',1,332,2,437,1641,-360,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1075,2,'1786721560-TEST',1,333,1,362,-65,-372,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1076,2,'1786721560-TEST',1,335,1,-19,448,-392,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1077,2,'1786721560-TEST',1,336,2,-258,1207,-416,461.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1078,2,'1786721560-TEST',1,321,1,-47,-343,-358,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1079,2,'1786721560-TEST',1,322,2,1465,1519,-252,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1080,2,'1786721560-TEST',1,324,2,-248,1552,-276,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1081,2,'1786721560-TEST',1,325,2,693,807,-372,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1082,2,'1786721560-TEST',1,326,1,8,-1219,-467,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1083,2,'1786721560-TEST',1,327,1,-2017,22,-302,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1084,2,'1786721560-TEST',1,328,2,1506,1501,-252,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1085,2,'1786721560-TEST',1,330,1,-505,-1002,-332,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1086,2,'1786721560-TEST',1,331,2,60,819,-372,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1087,2,'1786721560-TEST',1,332,2,188,1780,-378,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1088,2,'1786721560-TEST',1,333,1,996,-273,-332,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1089,2,'1786721560-TEST',1,334,2,2416,2861,-500,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1090,2,'1786721560-TEST',1,335,1,0,762,-395,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1091,2,'1786721560-TEST',1,336,2,-258,1207,-416,466.01,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1092,2,'1786721560-TEST',1,321,1,37,-45,-420,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1093,2,'1786721560-TEST',1,322,2,1177,864,-364,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1094,2,'1786721560-TEST',1,324,2,-246,1590,-276,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1095,2,'1786721560-TEST',1,325,2,996,863,-364,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1096,2,'1786721560-TEST',1,326,1,195,-518,-412,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1097,2,'1786721560-TEST',1,327,1,-1770,-60,-356,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1098,2,'1786721560-TEST',1,328,2,886,1258,-272,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1099,2,'1786721560-TEST',1,330,1,-504,-1083,-522,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1100,2,'1786721560-TEST',1,332,2,194,1756,-360,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1101,2,'1786721560-TEST',1,333,1,868,-262,-351,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1102,2,'1786721560-TEST',1,334,2,1621,2662,-500,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1103,2,'1786721560-TEST',1,335,1,-4,791,-390,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1104,2,'1786721560-TEST',1,336,2,-258,1207,-416,471.05,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1105,2,'1786721560-TEST',1,321,1,-8,612,-410,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1106,2,'1786721560-TEST',1,322,2,1048,948,-364,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1107,2,'1786721560-TEST',1,323,1,-103,-2517,-588,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1108,2,'1786721560-TEST',1,324,2,-74,1334,-276,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1109,2,'1786721560-TEST',1,325,2,1046,900,-364,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1110,2,'1786721560-TEST',1,326,1,-28,156,-411,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1111,2,'1786721560-TEST',1,327,1,-1550,502,-364,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1112,2,'1786721560-TEST',1,328,2,850,1211,-286,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1113,2,'1786721560-TEST',1,329,1,-678,-2315,-588,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1114,2,'1786721560-TEST',1,330,1,-1115,-876,-364,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1115,2,'1786721560-TEST',1,332,2,164,1122,-372,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1116,2,'1786721560-TEST',1,333,1,911,-187,-343,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1117,2,'1786721560-TEST',1,334,2,1506,1902,-252,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1118,2,'1786721560-TEST',1,335,1,26,842,-390,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1119,2,'1786721560-TEST',1,336,2,-258,1207,-398,476.08,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1120,2,'1786721560-TEST',1,322,2,1048,938,-364,481.02,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1121,2,'1786721560-TEST',1,323,1,-724,-2084,-588,481.02,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1122,2,'1786721560-TEST',1,324,2,-255,1356,-264,481.02,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1123,2,'1786721560-TEST',1,325,2,1017,905,-364,481.02,'2026-08-14 16:45:10','2026-08-14 16:45:10');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1124,2,'1786721560-TEST',1,326,1,-12,685,-408,481.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1125,2,'1786721560-TEST',1,327,1,-824,913,-404,481.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1126,2,'1786721560-TEST',1,329,1,-740,-2051,-554,481.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1127,2,'1786721560-TEST',1,330,1,-1265,-178,-372,481.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1128,2,'1786721560-TEST',1,331,2,2731,3015,-500,481.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1129,2,'1786721560-TEST',1,332,2,62,820,-372,481.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1130,2,'1786721560-TEST',1,333,1,911,-187,-343,481.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1131,2,'1786721560-TEST',1,334,2,921,1234,-265,481.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1132,2,'1786721560-TEST',1,336,2,-625,1202,-414,481.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1133,2,'1786721560-TEST',1,322,2,1104,939,-364,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1134,2,'1786721560-TEST',1,323,1,-533,-1432,-492,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1135,2,'1786721560-TEST',1,324,2,-255,1356,-264,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1136,2,'1786721560-TEST',1,325,2,1046,900,-364,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1137,2,'1786721560-TEST',1,326,1,12,815,-390,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1138,2,'1786721560-TEST',1,329,1,-764,-1249,-508,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1139,2,'1786721560-TEST',1,330,1,-1243,299,-390,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1140,2,'1786721560-TEST',1,331,2,2565,2046,-380,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1141,2,'1786721560-TEST',1,333,1,1082,-52,-518,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1142,2,'1786721560-TEST',1,334,2,150,1196,-372,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1143,2,'1786721560-TEST',1,336,2,-638,1129,-414,486.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1144,2,'1786721560-TEST',1,322,2,1475,1504,-252,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1145,2,'1786721560-TEST',1,323,1,-504,-1002,-316,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1146,2,'1786721560-TEST',1,324,2,-298,1353,-234,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1147,2,'1786721560-TEST',1,325,2,1052,900,-364,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1148,2,'1786721560-TEST',1,326,1,59,762,-372,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1149,2,'1786721560-TEST',1,329,1,-1172,-823,-364,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1150,2,'1786721560-TEST',1,331,2,2201,1428,-220,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1151,2,'1786721560-TEST',1,333,1,1296,-61,-518,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1152,2,'1786721560-TEST',1,334,2,-634,1041,-397,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1153,2,'1786721560-TEST',1,336,2,-679,924,-404,491.08,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1154,2,'1786721560-TEST',1,321,1,-10,-2357,-588,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1155,2,'1786721560-TEST',1,322,2,1731,1762,-270,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1156,2,'1786721560-TEST',1,323,1,-505,-1002,-350,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1157,2,'1786721560-TEST',1,324,2,-96,1169,-372,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1158,2,'1786721560-TEST',1,325,2,1419,1376,-252,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1159,2,'1786721560-TEST',1,327,1,53,-2266,-588,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1160,2,'1786721560-TEST',1,328,2,2689,2822,-500,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1161,2,'1786721560-TEST',1,329,1,-1651,-378,-362,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1162,2,'1786721560-TEST',1,330,1,-698,-2279,-588,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1163,2,'1786721560-TEST',1,331,2,1816,920,-280,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1164,2,'1786721560-TEST',1,332,2,2477,2875,-500,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1165,2,'1786721560-TEST',1,333,1,877,304,-518,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1166,2,'1786721560-TEST',1,334,2,-708,944,-404,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1167,2,'1786721560-TEST',1,335,1,-750,-2235,-600,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1168,2,'1786721560-TEST',1,336,2,-695,912,-404,496.02,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1169,2,'1786721560-TEST',1,321,1,23,-1539,-489,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1170,2,'1786721560-TEST',1,322,2,1731,1762,-270,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1171,2,'1786721560-TEST',1,323,1,-504,-1002,-343,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1172,2,'1786721560-TEST',1,324,2,-404,1156,-404,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1173,2,'1786721560-TEST',1,325,2,1247,1468,-270,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1174,2,'1786721560-TEST',1,327,1,19,-1473,-474,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1175,2,'1786721560-TEST',1,328,2,2425,1937,-380,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1176,2,'1786721560-TEST',1,329,1,-1736,-490,-364,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1177,2,'1786721560-TEST',1,330,1,-592,-1514,-510,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1178,2,'1786721560-TEST',1,331,2,1670,508,-260,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1179,2,'1786721560-TEST',1,332,2,1796,2754,-500,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1180,2,'1786721560-TEST',1,333,1,615,597,-484,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1181,2,'1786721560-TEST',1,334,2,-1032,592,-374,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1182,2,'1786721560-TEST',1,335,1,-753,-2057,-588,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1183,2,'1786721560-TEST',1,336,2,-598,930,-422,501.05,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1184,2,'1786721560-TEST',1,321,1,117,-753,-447,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1185,2,'1786721560-TEST',1,322,2,1375,1201,-265,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1186,2,'1786721560-TEST',1,323,1,-519,-1037,-324,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1187,2,'1786721560-TEST',1,324,2,-638,997,-404,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1188,2,'1786721560-TEST',1,325,2,1312,1495,-252,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1189,2,'1786721560-TEST',1,327,1,152,-697,-433,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1190,2,'1786721560-TEST',1,328,2,2039,1388,-220,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1191,2,'1786721560-TEST',1,329,1,-1736,-490,-382,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1192,2,'1786721560-TEST',1,330,1,-505,-1010,-378,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1193,2,'1786721560-TEST',1,331,2,1670,508,-260,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1194,2,'1786721560-TEST',1,332,2,1535,1967,-252,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1195,2,'1786721560-TEST',1,333,1,131,706,-444,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1196,2,'1786721560-TEST',1,334,2,-1078,592,-392,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1197,2,'1786721560-TEST',1,335,1,-510,-1325,-502,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1198,2,'1786721560-TEST',1,336,2,-599,881,-409,506.09,'2026-08-14 16:45:11','2026-08-14 16:45:11');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1199,2,'1786721560-TEST',1,321,1,29,-121,-412,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1200,2,'1786721560-TEST',1,322,2,1557,354,-372,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1201,2,'1786721560-TEST',1,323,1,-505,-987,-310,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1202,2,'1786721560-TEST',1,324,2,-714,1215,-380,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1203,2,'1786721560-TEST',1,325,2,1389,1509,-236,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1204,2,'1786721560-TEST',1,326,1,-100,-2530,-588,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1205,2,'1786721560-TEST',1,327,1,48,-47,-420,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1206,2,'1786721560-TEST',1,328,2,1363,1676,-252,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1207,2,'1786721560-TEST',1,329,1,-1678,-412,-346,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1208,2,'1786721560-TEST',1,330,1,-504,-965,-274,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1209,2,'1786721560-TEST',1,331,2,1384,798,-372,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1210,2,'1786721560-TEST',1,332,2,1386,1206,-262,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1211,2,'1786721560-TEST',1,333,1,44,1133,-372,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1212,2,'1786721560-TEST',1,334,2,-1099,592,-354,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1213,2,'1786721560-TEST',1,335,1,-505,-1002,-348,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1214,2,'1786721560-TEST',1,336,2,-586,1375,-396,511.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1215,2,'1786721560-TEST',1,321,1,472,48,-390,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1216,2,'1786721560-TEST',1,322,2,1761,-236,-366,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1217,2,'1786721560-TEST',1,323,1,-535,-535,-360,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1218,2,'1786721560-TEST',1,324,2,-701,1164,-398,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1219,2,'1786721560-TEST',1,325,2,1374,1075,-324,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1220,2,'1786721560-TEST',1,326,1,-724,-2075,-588,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1221,2,'1786721560-TEST',1,327,1,435,-336,-372,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1222,2,'1786721560-TEST',1,328,2,731,1558,-230,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1223,2,'1786721560-TEST',1,329,1,-1279,-539,-372,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1224,2,'1786721560-TEST',1,330,1,-487,-403,-372,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1225,2,'1786721560-TEST',1,331,2,1386,1043,-336,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1226,2,'1786721560-TEST',1,332,2,1406,727,-372,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1227,2,'1786721560-TEST',1,333,1,-195,1148,-381,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1228,2,'1786721560-TEST',1,334,2,-904,895,-422,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1229,2,'1786721560-TEST',1,335,1,-502,-1002,-350,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1230,2,'1786721560-TEST',1,336,2,-624,1438,-374,516.06,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1231,2,'1786721560-TEST',1,321,1,472,48,-390,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1232,2,'1786721560-TEST',1,322,2,1776,-381,-494,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1233,2,'1786721560-TEST',1,323,1,-188,205,-404,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1234,2,'1786721560-TEST',1,324,2,-714,1231,-380,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1235,2,'1786721560-TEST',1,325,2,1528,389,-372,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1236,2,'1786721560-TEST',1,326,1,-511,-1337,-501,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1237,2,'1786721560-TEST',1,327,1,719,-334,-372,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1238,2,'1786721560-TEST',1,328,2,581,1678,-364,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1239,2,'1786721560-TEST',1,329,1,-545,-750,-332,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1240,2,'1786721560-TEST',1,330,1,-230,236,-404,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1241,2,'1786721560-TEST',1,331,2,1072,1484,-258,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1242,2,'1786721560-TEST',1,332,2,1771,-42,-356,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1243,2,'1786721560-TEST',1,334,2,-1101,853,-422,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1244,2,'1786721560-TEST',1,335,1,-504,-1002,-319,521.09,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1245,2,'1786721560-TEST',1,321,1,163,-58,-401,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1246,2,'1786721560-TEST',1,322,2,1771,-372,-394,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1247,2,'1786721560-TEST',1,323,1,-618,628,-404,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1248,2,'1786721560-TEST',1,324,2,-31,1168,-372,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1249,2,'1786721560-TEST',1,325,2,1606,-184,-356,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1250,2,'1786721560-TEST',1,326,1,-504,-1002,-333,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1251,2,'1786721560-TEST',1,327,1,808,-210,-363,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1252,2,'1786721560-TEST',1,328,2,533,1609,-360,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1253,2,'1786721560-TEST',1,329,1,-167,-104,-420,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1254,2,'1786721560-TEST',1,330,1,-672,793,-392,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1255,2,'1786721560-TEST',1,331,2,850,1211,-286,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1256,2,'1786721560-TEST',1,335,1,-505,-939,-350,526.02,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1257,2,'1786721560-TEST',1,321,1,330,-453,-412,531.05,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1258,2,'1786721560-TEST',1,322,2,1651,268,-372,531.05,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1259,2,'1786721560-TEST',1,323,1,-669,761,-404,531.05,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1260,2,'1786721560-TEST',1,324,2,-361,1155,-404,531.05,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1261,2,'1786721560-TEST',1,325,2,1175,-269,-336,531.05,'2026-08-14 16:45:12','2026-08-14 16:45:12');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1262,2,'1786721560-TEST',1,326,1,-511,-1020,-393,531.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1263,2,'1786721560-TEST',1,328,2,484,1154,-332,531.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1264,2,'1786721560-TEST',1,329,1,385,-294,-372,531.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1265,2,'1786721560-TEST',1,331,2,859,1223,-285,531.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1266,2,'1786721560-TEST',1,333,1,-642,-2344,-588,531.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1267,2,'1786721560-TEST',1,335,1,-578,-888,-332,531.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1268,2,'1786721560-TEST',1,321,1,566,-453,-268,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1269,2,'1786721560-TEST',1,322,2,1581,186,-352,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1270,2,'1786721560-TEST',1,324,2,-565,1051,-396,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1271,2,'1786721560-TEST',1,326,1,-504,-1002,-329,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1272,2,'1786721560-TEST',1,328,2,886,1230,-284,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1273,2,'1786721560-TEST',1,329,1,534,-328,-372,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1274,2,'1786721560-TEST',1,331,2,-26,1181,-372,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1275,2,'1786721560-TEST',1,332,2,2274,2929,-508,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1276,2,'1786721560-TEST',1,333,1,-652,-1596,-531,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1277,2,'1786721560-TEST',1,334,2,2164,2933,-508,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1278,2,'1786721560-TEST',1,335,1,-217,-142,-380,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1279,2,'1786721560-TEST',1,336,2,2475,3384,-462,536.09,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1280,2,'1786721560-TEST',1,321,1,656,-564,-268,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1281,2,'1786721560-TEST',1,323,1,29,-2613,-588,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1282,2,'1786721560-TEST',1,324,2,-879,598,-375,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1283,2,'1786721560-TEST',1,326,1,-506,-1101,-419,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1284,2,'1786721560-TEST',1,327,1,-152,-2524,-588,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1285,2,'1786721560-TEST',1,328,2,684,1222,-296,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1286,2,'1786721560-TEST',1,329,1,884,111,-500,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1287,2,'1786721560-TEST',1,330,1,-439,-2433,-588,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1288,2,'1786721560-TEST',1,331,2,-665,953,-404,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1289,2,'1786721560-TEST',1,332,2,1449,2615,-500,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1290,2,'1786721560-TEST',1,333,1,-505,-1034,-445,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1291,2,'1786721560-TEST',1,334,2,1541,2401,-435,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1292,2,'1786721560-TEST',1,335,1,-521,-2480,-588,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1293,2,'1786721560-TEST',1,336,2,2580,2880,-500,541.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1294,2,'1786721560-TEST',1,321,1,656,-564,-268,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1295,2,'1786721560-TEST',1,323,1,68,-1775,-545,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1296,2,'1786721560-TEST',1,324,2,-1044,601,-393,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1297,2,'1786721560-TEST',1,326,1,-504,-1002,-335,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1298,2,'1786721560-TEST',1,327,1,86,-1810,-553,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1299,2,'1786721560-TEST',1,328,2,-316,1153,-404,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1300,2,'1786721560-TEST',1,329,1,878,370,-517,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1301,2,'1786721560-TEST',1,330,1,-722,-1798,-582,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1302,2,'1786721560-TEST',1,331,2,-246,1198,-413,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1303,2,'1786721560-TEST',1,332,2,1042,2217,-492,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1304,2,'1786721560-TEST',1,333,1,-547,-657,-344,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1305,2,'1786721560-TEST',1,334,2,1477,1592,-252,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1306,2,'1786721560-TEST',1,335,1,-725,-1617,-536,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1307,2,'1786721560-TEST',1,336,2,2571,2057,-380,546.05,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1308,2,'1786721560-TEST',1,321,1,637,-588,-268,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1309,2,'1786721560-TEST',1,322,2,2411,2860,-500,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1310,2,'1786721560-TEST',1,323,1,64,-981,-384,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1311,2,'1786721560-TEST',1,324,2,-1123,593,-392,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1312,2,'1786721560-TEST',1,325,2,2320,2869,-500,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1313,2,'1786721560-TEST',1,326,1,-504,-1002,-328,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1314,2,'1786721560-TEST',1,327,1,57,-1026,-399,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1315,2,'1786721560-TEST',1,328,2,-844,642,-382,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1316,2,'1786721560-TEST',1,329,1,373,718,-484,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1317,2,'1786721560-TEST',1,330,1,-504,-1070,-509,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1318,2,'1786721560-TEST',1,331,2,-246,1198,-413,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1319,2,'1786721560-TEST',1,332,2,458,2078,-413,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1320,2,'1786721560-TEST',1,333,1,-154,10,-420,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1321,2,'1786721560-TEST',1,334,2,1264,847,-372,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1322,2,'1786721560-TEST',1,335,1,-859,-959,-469,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1323,2,'1786721560-TEST',1,336,2,2188,1441,-220,551.08,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1324,2,'1786721560-TEST',1,321,1,844,-760,-500,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1325,2,'1786721560-TEST',1,322,2,1741,2725,-500,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1326,2,'1786721560-TEST',1,323,1,197,-275,-412,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1327,2,'1786721560-TEST',1,324,2,-1040,642,-399,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1328,2,'1786721560-TEST',1,325,2,1567,2636,-500,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1329,2,'1786721560-TEST',1,326,1,-505,-1002,-339,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1330,2,'1786721560-TEST',1,327,1,199,-317,-412,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1331,2,'1786721560-TEST',1,328,2,-878,592,-374,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1332,2,'1786721560-TEST',1,329,1,165,873,-372,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1333,2,'1786721560-TEST',1,330,1,-505,-1009,-375,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1334,2,'1786721560-TEST',1,331,2,190,1012,-372,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1335,2,'1786721560-TEST',1,332,2,349,1411,-360,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1336,2,'1786721560-TEST',1,333,1,-9,632,-410,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1337,2,'1786721560-TEST',1,334,2,935,849,-382,556.01,'2026-08-14 16:45:13','2026-08-14 16:45:13');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1338,2,'1786721560-TEST',1,335,1,-615,-819,-332,556.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1339,2,'1786721560-TEST',1,336,2,1667,1062,-320,556.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1340,2,'1786721560-TEST',1,321,1,1599,-977,-502,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1341,2,'1786721560-TEST',1,322,2,1526,1918,-252,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1342,2,'1786721560-TEST',1,323,1,196,-393,-430,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1343,2,'1786721560-TEST',1,324,2,-600,591,-404,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1344,2,'1786721560-TEST',1,325,2,1042,2218,-492,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1345,2,'1786721560-TEST',1,326,1,-545,-625,-348,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1346,2,'1786721560-TEST',1,328,2,-1032,592,-392,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1347,2,'1786721560-TEST',1,330,1,-506,-1002,-343,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1348,2,'1786721560-TEST',1,331,2,599,804,-372,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1349,2,'1786721560-TEST',1,332,2,273,886,-390,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1350,2,'1786721560-TEST',1,333,1,-3,789,-390,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1351,2,'1786721560-TEST',1,334,2,904,850,-382,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1352,2,'1786721560-TEST',1,335,1,-263,-184,-372,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1353,2,'1786721560-TEST',1,336,2,1211,862,-364,561.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1354,2,'1786721560-TEST',1,321,1,1757,-631,-494,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1355,2,'1786721560-TEST',1,322,2,982,1375,-262,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1356,2,'1786721560-TEST',1,323,1,148,-208,-412,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1357,2,'1786721560-TEST',1,324,2,-410,410,-404,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1358,2,'1786721560-TEST',1,325,2,474,2030,-399,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1359,2,'1786721560-TEST',1,326,1,-153,11,-420,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1360,2,'1786721560-TEST',1,328,2,-1042,592,-392,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1361,2,'1786721560-TEST',1,330,1,-505,-1048,-468,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1362,2,'1786721560-TEST',1,331,2,861,839,-390,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1363,2,'1786721560-TEST',1,333,1,0,808,-390,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1364,2,'1786721560-TEST',1,334,2,1075,917,-364,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1365,2,'1786721560-TEST',1,335,1,-147,75,-420,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1366,2,'1786721560-TEST',1,336,2,986,823,-382,566.08,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1367,2,'1786721560-TEST',1,321,1,1774,-412,-494,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1368,2,'1786721560-TEST',1,322,2,859,1223,-285,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1369,2,'1786721560-TEST',1,323,1,-315,314,-404,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1370,2,'1786721560-TEST',1,325,2,236,1433,-360,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1371,2,'1786721560-TEST',1,326,1,-392,278,-404,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1372,2,'1786721560-TEST',1,327,1,32,-2720,-575,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1373,2,'1786721560-TEST',1,328,2,-1139,592,-374,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1374,2,'1786721560-TEST',1,329,1,-288,-2528,-583,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1375,2,'1786721560-TEST',1,330,1,-507,-1002,-321,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1376,2,'1786721560-TEST',1,333,1,0,808,-390,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1377,2,'1786721560-TEST',1,334,2,1435,1429,-252,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1378,2,'1786721560-TEST',1,335,1,-371,310,-404,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1379,2,'1786721560-TEST',1,336,2,986,823,-382,571.01,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1380,2,'1786721560-TEST',1,321,1,1761,-42,-356,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1381,2,'1786721560-TEST',1,322,2,598,1215,-312,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1382,2,'1786721560-TEST',1,323,1,-510,421,-422,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1383,2,'1786721560-TEST',1,324,2,2752,3120,-482,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1384,2,'1786721560-TEST',1,325,2,194,1005,-372,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1385,2,'1786721560-TEST',1,326,1,-392,278,-404,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1386,2,'1786721560-TEST',1,327,1,-674,-2317,-588,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1387,2,'1786721560-TEST',1,328,2,-1197,852,-314,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1388,2,'1786721560-TEST',1,329,1,88,-1841,-560,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1389,2,'1786721560-TEST',1,330,1,-504,-1002,-342,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1390,2,'1786721560-TEST',1,331,2,2560,3119,-482,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1391,2,'1786721560-TEST',1,332,2,2064,3504,-474,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1392,2,'1786721560-TEST',1,333,1,23,836,-364,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1393,2,'1786721560-TEST',1,334,2,979,1324,-262,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1394,2,'1786721560-TEST',1,335,1,-371,310,-404,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1395,2,'1786721560-TEST',1,336,2,2064,3696,-474,576.04,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1396,2,'1786721560-TEST',1,321,1,1538,677,-333,581.07,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1397,2,'1786721560-TEST',1,322,2,-12,1644,-276,581.07,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1398,2,'1786721560-TEST',1,323,1,-510,421,-422,581.07,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1399,2,'1786721560-TEST',1,324,2,2248,2956,-508,581.07,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1400,2,'1786721560-TEST',1,325,2,99,829,-372,581.07,'2026-08-14 16:45:14','2026-08-14 16:45:14');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1401,2,'1786721560-TEST',1,326,1,-659,764,-401,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1402,2,'1786721560-TEST',1,327,1,-634,-1570,-525,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1403,2,'1786721560-TEST',1,328,2,-1318,1025,-224,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1404,2,'1786721560-TEST',1,329,1,30,-1048,-407,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1405,2,'1786721560-TEST',1,330,1,-512,-1032,-430,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1406,2,'1786721560-TEST',1,331,2,2696,2283,-394,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1407,2,'1786721560-TEST',1,332,2,1704,2916,-508,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1408,2,'1786721560-TEST',1,334,2,94,1194,-372,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1409,2,'1786721560-TEST',1,335,1,-63,61,-420,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1410,2,'1786721560-TEST',1,336,2,1805,3195,-480,581.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1411,2,'1786721560-TEST',1,321,1,1764,670,-278,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1412,2,'1786721560-TEST',1,322,2,-131,1694,-276,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1413,2,'1786721560-TEST',1,323,1,-189,191,-404,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1414,2,'1786721560-TEST',1,324,2,1499,2620,-500,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1415,2,'1786721560-TEST',1,325,2,-24,797,-370,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1416,2,'1786721560-TEST',1,327,1,-505,-1026,-404,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1417,2,'1786721560-TEST',1,328,2,-1276,869,-192,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1418,2,'1786721560-TEST',1,329,1,267,-337,-412,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1419,2,'1786721560-TEST',1,330,1,-504,-1002,-336,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1420,2,'1786721560-TEST',1,331,2,2196,1732,-321,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1421,2,'1786721560-TEST',1,332,2,1541,2130,-299,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1422,2,'1786721560-TEST',1,334,2,-571,1236,-396,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1423,2,'1786721560-TEST',1,335,1,434,-327,-372,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1424,2,'1786721560-TEST',1,336,2,1359,2537,-500,586,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1425,2,'1786721560-TEST',1,321,1,1814,517,-260,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1426,2,'1786721560-TEST',1,322,2,242,1246,-365,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1427,2,'1786721560-TEST',1,324,2,977,2218,-492,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1428,2,'1786721560-TEST',1,325,2,-8,622,-410,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1429,2,'1786721560-TEST',1,327,1,-504,-1002,-320,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1430,2,'1786721560-TEST',1,328,2,-939,860,-404,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1431,2,'1786721560-TEST',1,329,1,20,-120,-430,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1432,2,'1786721560-TEST',1,330,1,-541,-632,-347,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1433,2,'1786721560-TEST',1,331,2,1959,1082,-320,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1434,2,'1786721560-TEST',1,332,2,1681,1406,-252,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1435,2,'1786721560-TEST',1,335,1,1153,-260,-334,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1436,2,'1786721560-TEST',1,336,2,820,2229,-492,591.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1437,2,'1786721560-TEST',1,322,2,627,799,-372,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1438,2,'1786721560-TEST',1,323,1,-286,-2511,-588,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1439,2,'1786721560-TEST',1,324,2,476,2000,-390,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1440,2,'1786721560-TEST',1,325,2,-23,8,-420,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1441,2,'1786721560-TEST',1,326,1,92,-2108,-588,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1442,2,'1786721560-TEST',1,327,1,-504,-1026,-410,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1443,2,'1786721560-TEST',1,328,2,-1185,583,-372,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1444,2,'1786721560-TEST',1,329,1,20,-120,-430,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1445,2,'1786721560-TEST',1,330,1,-206,-131,-422,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1446,2,'1786721560-TEST',1,331,2,1567,730,-279,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1447,2,'1786721560-TEST',1,332,2,2013,1103,-338,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1448,2,'1786721560-TEST',1,333,1,-755,-2197,-644,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1449,2,'1786721560-TEST',1,335,1,521,-347,-372,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1450,2,'1786721560-TEST',1,336,2,392,1827,-364,596.07,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1451,2,'1786721560-TEST',1,322,2,869,840,-390,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1452,2,'1786721560-TEST',1,323,1,-765,-2074,-580,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1453,2,'1786721560-TEST',1,324,2,312,1346,-364,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1454,2,'1786721560-TEST',1,326,1,11,-1344,-505,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1455,2,'1786721560-TEST',1,327,1,-505,-1002,-312,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1456,2,'1786721560-TEST',1,328,2,-784,544,-382,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1457,2,'1786721560-TEST',1,329,1,-561,564,-404,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1458,2,'1786721560-TEST',1,330,1,265,-78,-380,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1459,2,'1786721560-TEST',1,331,2,1577,516,-345,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1460,2,'1786721560-TEST',1,332,2,2039,1041,-338,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1461,2,'1786721560-TEST',1,333,1,-755,-1411,-494,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1462,2,'1786721560-TEST',1,335,1,188,6,-396,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1463,2,'1786721560-TEST',1,336,2,-134,1700,-276,601,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1464,2,'1786721560-TEST',1,321,1,32,-2719,-575,606.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1465,2,'1786721560-TEST',1,322,2,470,802,-372,606.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1466,2,'1786721560-TEST',1,323,1,-664,-1614,-536,606.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1467,2,'1786721560-TEST',1,324,2,57,790,-372,606.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1468,2,'1786721560-TEST',1,325,2,2673,2634,-479,606.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1469,2,'1786721560-TEST',1,326,1,192,-627,-412,606.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1470,2,'1786721560-TEST',1,327,1,-505,-1005,-348,606.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1471,2,'1786721560-TEST',1,328,2,-784,544,-382,606.03,'2026-08-14 16:45:15','2026-08-14 16:45:15');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1472,2,'1786721560-TEST',1,329,1,-658,768,-400,606.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1473,2,'1786721560-TEST',1,330,1,953,-271,-332,606.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1474,2,'1786721560-TEST',1,331,2,1584,486,-390,606.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1475,2,'1786721560-TEST',1,332,2,2039,1041,-338,606.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1476,2,'1786721560-TEST',1,333,1,-1056,-976,-364,606.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1477,2,'1786721560-TEST',1,334,2,2327,2864,-500,606.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1478,2,'1786721560-TEST',1,335,1,-382,265,-396,606.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1479,2,'1786721560-TEST',1,336,2,-248,1552,-276,606.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1480,2,'1786721560-TEST',1,321,1,-707,-2290,-588,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1481,2,'1786721560-TEST',1,322,2,-278,1148,-403,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1482,2,'1786721560-TEST',1,323,1,-505,-1038,-441,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1483,2,'1786721560-TEST',1,324,2,611,618,-484,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1484,2,'1786721560-TEST',1,325,2,2425,1928,-380,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1485,2,'1786721560-TEST',1,326,1,-110,-60,-420,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1486,2,'1786721560-TEST',1,327,1,-504,-1002,-350,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1487,2,'1786721560-TEST',1,328,2,-960,477,-364,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1488,2,'1786721560-TEST',1,329,1,-658,768,-400,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1489,2,'1786721560-TEST',1,330,1,1719,-173,-356,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1490,2,'1786721560-TEST',1,331,2,1584,486,-390,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1491,2,'1786721560-TEST',1,332,2,1583,748,-276,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1492,2,'1786721560-TEST',1,333,1,-1264,-70,-372,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1493,2,'1786721560-TEST',1,334,2,1550,2631,-500,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1494,2,'1786721560-TEST',1,335,1,-300,305,-404,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1495,2,'1786721560-TEST',1,336,2,-248,1552,-276,611.07,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1496,2,'1786721560-TEST',1,321,1,-736,-1541,-517,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1497,2,'1786721560-TEST',1,322,2,-728,1744,-396,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1498,2,'1786721560-TEST',1,323,1,-502,-1002,-327,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1499,2,'1786721560-TEST',1,324,2,875,355,-518,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1500,2,'1786721560-TEST',1,325,2,2163,1271,-256,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1501,2,'1786721560-TEST',1,326,1,-552,-660,-343,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1502,2,'1786721560-TEST',1,327,1,-508,-1005,-364,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1503,2,'1786721560-TEST',1,329,1,-658,768,-400,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1504,2,'1786721560-TEST',1,331,2,1584,486,-390,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1505,2,'1786721560-TEST',1,332,2,1534,387,-372,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1506,2,'1786721560-TEST',1,333,1,-1288,-100,-390,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1507,2,'1786721560-TEST',1,334,2,1111,2220,-492,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1508,2,'1786721560-TEST',1,335,1,-652,736,-404,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1509,2,'1786721560-TEST',1,336,2,117,1427,-364,616,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1510,2,'1786721560-TEST',1,322,2,-1392,1447,-373,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1511,2,'1786721560-TEST',1,323,1,-408,-316,-372,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1512,2,'1786721560-TEST',1,324,2,716,-45,-440,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1513,2,'1786721560-TEST',1,325,2,1608,1032,-320,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1514,2,'1786721560-TEST',1,326,1,-1107,-845,-382,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1515,2,'1786721560-TEST',1,327,1,-511,-1002,-330,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1516,2,'1786721560-TEST',1,329,1,-658,768,-400,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1517,2,'1786721560-TEST',1,331,2,1584,486,-390,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1518,2,'1786721560-TEST',1,332,2,1528,-187,-356,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1519,2,'1786721560-TEST',1,333,1,-1288,-100,-390,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1520,2,'1786721560-TEST',1,334,2,474,2059,-407,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1521,2,'1786721560-TEST',1,335,1,-652,736,-404,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
INSERT INTO `ktp_position_samples` (`id`, `server_id`, `match_id`, `half`, `player_id`, `team`, `pos_x`, `pos_y`, `pos_z`, `game_time`, `event_time`, `created_at`) VALUES (1522,2,'1786721560-TEST',1,336,2,85,822,-372,621.03,'2026-08-14 16:45:16','2026-08-14 16:45:16');
/*!40000 ALTER TABLE `ktp_position_samples` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_spike_daily`
--

DROP TABLE IF EXISTS `ktp_spike_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_spike_daily` (
  `day` date NOT NULL,
  `fingerprint` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `server_endpoint` varchar(48) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phase` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `magnitude_bucket` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `count` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`day`,`fingerprint`,`server_endpoint`),
  KEY `idx_fp` (`fingerprint`),
  KEY `idx_day_bucket` (`day`,`magnitude_bucket`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_spike_daily`
--

LOCK TABLES `ktp_spike_daily` WRITE;
/*!40000 ALTER TABLE `ktp_spike_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `ktp_spike_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_spike_signatures`
--

DROP TABLE IF EXISTS `ktp_spike_signatures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_spike_signatures` (
  `fingerprint` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phase` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `magnitude_bucket` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_seen` timestamp NOT NULL,
  `last_seen` timestamp NOT NULL,
  `count` int NOT NULL DEFAULT '0',
  `sample_endpoint` varchar(48) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sample_line` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `posted_alert` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fingerprint`),
  KEY `idx_last_seen` (`last_seen`),
  KEY `idx_phase_bucket` (`phase`,`magnitude_bucket`),
  KEY `idx_posted_alert` (`posted_alert`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_spike_signatures`
--

LOCK TABLES `ktp_spike_signatures` WRITE;
/*!40000 ALTER TABLE `ktp_spike_signatures` DISABLE KEYS */;
/*!40000 ALTER TABLE `ktp_spike_signatures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_telemetry_baselines`
--

DROP TABLE IF EXISTS `ktp_telemetry_baselines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_telemetry_baselines` (
  `server_endpoint` varchar(48) NOT NULL,
  `day` date NOT NULL,
  `fps_p50_today` float NOT NULL,
  `fps_p50_mean` float DEFAULT NULL,
  `fps_p50_stddev` float DEFAULT NULL,
  `fps_p50_baseline` float DEFAULT NULL,
  `spike_total_today` int NOT NULL,
  `spike_total_mean` float DEFAULT NULL,
  `spike_total_stddev` float DEFAULT NULL,
  `spike_total_baseline` float DEFAULT NULL,
  `warn_fps` tinyint NOT NULL DEFAULT '0',
  `warn_spikes` tinyint NOT NULL DEFAULT '0',
  `posted_to_discord` tinyint NOT NULL DEFAULT '0',
  `computed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`server_endpoint`,`day`),
  KEY `idx_day` (`day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_telemetry_baselines`
--

LOCK TABLES `ktp_telemetry_baselines` WRITE;
/*!40000 ALTER TABLE `ktp_telemetry_baselines` DISABLE KEYS */;
/*!40000 ALTER TABLE `ktp_telemetry_baselines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_telemetry_metrics`
--

DROP TABLE IF EXISTS `ktp_telemetry_metrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_telemetry_metrics` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `server_endpoint` varchar(48) NOT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `window_start` timestamp NULL DEFAULT NULL,
  `window_end` timestamp NULL DEFAULT NULL,
  `fps_p50` float DEFAULT NULL,
  `fps_p95` float DEFAULT NULL,
  `fps_p99` float DEFAULT NULL,
  `fps_stddev` float DEFAULT NULL,
  `fps_min` float DEFAULT NULL,
  `fps_max` float DEFAULT NULL,
  `fps_sample_count` int DEFAULT '0',
  `spike_phys` int NOT NULL DEFAULT '0',
  `spike_read` int NOT NULL DEFAULT '0',
  `spike_steam` int NOT NULL DEFAULT '0',
  `spike_send` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_server_recorded` (`server_endpoint`,`recorded_at`),
  KEY `idx_recorded` (`recorded_at`)
) ENGINE=InnoDB AUTO_INCREMENT=690894 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Phase 8.2: per-cycle FPS/spike aggregates from KTP_PROFILE/KTP_SPIKE log lines';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_telemetry_metrics`
--

LOCK TABLES `ktp_telemetry_metrics` WRITE;
/*!40000 ALTER TABLE `ktp_telemetry_metrics` DISABLE KEYS */;
/*!40000 ALTER TABLE `ktp_telemetry_metrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ktp_telemetry_watermarks`
--

DROP TABLE IF EXISTS `ktp_telemetry_watermarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ktp_telemetry_watermarks` (
  `server_endpoint` varchar(48) NOT NULL,
  `last_seen_ts` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`server_endpoint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='Phase 8.2: per-server last-parsed log timestamp (dedup across cycles)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ktp_telemetry_watermarks`
--

LOCK TABLES `ktp_telemetry_watermarks` WRITE;
/*!40000 ALTER TABLE `ktp_telemetry_watermarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `ktp_telemetry_watermarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_reports`
--

DROP TABLE IF EXISTS `support_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_reports` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `intake_id` char(12) NOT NULL,
  `category` varchar(32) NOT NULL,
  `channel` varchar(16) NOT NULL,
  `server_label` varchar(32) DEFAULT NULL,
  `body` varchar(2000) NOT NULL,
  `handle` varchar(64) DEFAULT NULL,
  `ip_hash` char(32) NOT NULL,
  `relayed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_support_reports_intake` (`intake_id`),
  KEY `ix_support_reports_created` (`created_at`),
  KEY `ix_support_reports_unrelayed` (`relayed`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_reports`
--

LOCK TABLES `support_reports` WRITE;
/*!40000 ALTER TABLE `support_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_reports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_schema_migrations`
--

DROP TABLE IF EXISTS `support_schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_schema_migrations` (
  `version` varchar(64) NOT NULL,
  `applied_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_schema_migrations`
--

LOCK TABLES `support_schema_migrations` WRITE;
/*!40000 ALTER TABLE `support_schema_migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `level` varchar(8) NOT NULL DEFAULT 'cl',
  `group_name` varchar(32) NOT NULL DEFAULT 'ktp_admin',
  `steam_id` varchar(32) NOT NULL,
  `display_name` varchar(64) NOT NULL,
  `requested_by` varchar(32) NOT NULL,
  `requested_note` varchar(500) DEFAULT NULL,
  `status` varchar(16) NOT NULL DEFAULT 'submitted',
  `season` smallint unsigned DEFAULT NULL,
  `decided_by` varchar(32) DEFAULT NULL,
  `applied_by` varchar(32) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `ix_support_tickets_status` (`status`),
  KEY `ix_support_tickets_expiry` (`group_name`,`status`,`season`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_tickets`
--

LOCK TABLES `support_tickets` WRITE;
/*!40000 ALTER TABLE `support_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_tickets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-14 16:45:21
